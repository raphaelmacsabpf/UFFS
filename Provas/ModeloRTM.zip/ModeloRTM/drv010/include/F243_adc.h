/* ==================================================================================
File name:        F243_ADC.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
This file defines handy constants for object initializations and
contains prototypes for the functions in F243ADC1.ASM and F243ADC2.ASM
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __F243_ADC_H__
#define __F243_ADC_H__

#include "..\include\F243BMSK.H"

/*-----------------------------------------------------------------------------
Define the structure of the ADCGEN
-----------------------------------------------------------------------------*/

typedef struct {


   int c1_gain; /* Gain control for channel 1[Q13] */
   int c2_gain; /* Gain control for channel 2[Q13] */
   int c3_gain; /* Gain control for channel 3[Q13] */
   int c4_gain; /* Gain control for channel 4[Q13] */

   int c1_out;  /* Conversion result for channel 1[Q15]*/
   int c2_out;  /* Conversion result for channel 2[Q15]*/
   int c3_out;  /* Conversion result for channel 3[Q15]*/
   int c4_out;  /* Conversion result for channel 4[Q15]*/

   int a4_ch_sel; /* ADC channel select variable[Q0] */

   int (*init)();                           /* Initialization func pointer  */
   int (*update)();                         /* Update function              */
   } ADCVALS;

/*-----------------------------------------------------------------------------
Define a ADCVALS_handle
-----------------------------------------------------------------------------*/

typedef ADCVALS  *ADCVALS_handle;


/*------------------------------------------------------------------------------
Default Initializers for the F243 ADCVALS Object
------------------------------------------------------------------------------*/

#define F243_ADC_DEFAULTS { 0x1fff,  \
                            0x1fff,  \
                            0x1fff,  \
                            0x1fff,  \
                            0x0,     \
                            0x0,     \
                            0x0,     \
                            0x0,     \
                            0x5432,  \
                            (int (*)(int))F243_ADC_Init,  \
                            (int (*)(int))F243_ADC_Update \
                          }

#define ADC_DEFAULTS F243_ADC_DEFAULTS

#define ADCTRL1_INIT_STATE  FREE_RUN_FLAG+SOFT_STOP_FLAG+ADCIMSTART+ADC2EN + \
                            ADC1EN+ADCINTFLAG 
#define ADCTRL2_INIT_STATE  ADCPSCALE_4


/*----------------------------------------------------------------------------
 Function prototypes
 ----------------------------------------------------------------------------*/

void F243_ADC_Init(ADCVALS_handle);
void F243_ADC_Update(ADCVALS_handle);


#endif     /*__F243_ADC_H__ */

