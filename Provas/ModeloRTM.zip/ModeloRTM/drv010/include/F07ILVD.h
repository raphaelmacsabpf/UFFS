/* =====================================================================================================================
File name:        F07ILVD.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description:  
Header file for F07ILVD1.C and F07ILVD2.ASM
All these three files to gether implement a 
Special Function ADC Driver. 
This ADC Driver measures three channels on the timer underflow 
event. This is intended for implementing two current measurement
and DC-bus voltage measurement for a inverter.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __F2407_ILG_DCBUS_H__
#define __F2407_ILG_DCBUS_H__

#include "..\include\F2407BMSK.H"

#ifndef NULL
#define NULL 0
#endif

/*-----------------------------------------------------------------------------
Define the structure of the ILEG2DCBUSMEAS Object
-----------------------------------------------------------------------------*/

typedef struct { int Imeas_a_gain;    /* Parameter: gain for Ia (Q13) */
                 int Imeas_a_offset;  /* Parameter: offset for Ia (Q15) */
                 int Imeas_a;         /* Output: measured Ia (Q15) */
                 int Imeas_b_gain;    /* Parameter: gain for Ib (Q13) */
                 int Imeas_b_offset;  /* Parameter: offset for Ib (Q15) */
                 int Imeas_b;         /* Output: measured Ib (Q15) */
                 int Vdc_meas_gain;   /* Parameter: gain for Vdc (Q13) */
                 int Vdc_meas_offset; /* Parameter: offset for Vdc (Q15) */
                 int Vdc_meas;        /* Output: measured Vdc (Q15) */
				 int Imeas_c;		  /* Output: computed Ic (Q15) */	
                 int Ch_sel;          /* Parameter: ADC channel selection */
                 int (*init)();       /* Pointer to the init function */
                 int (*read)();       /* Pointer to the read function */
               } ILEG2DCBUSMEAS;

/*-----------------------------------------------------------------------------
 Note 1 : It is necessary to call the init function to change the ADC 
            register settings, for the change in the channel setting for 
            Ch_sel setting changes to take effect.
            The read function will not detect or act upon this change.
-----------------------------------------------------------------------------*/
/* Default Initializer for the ILEG2DCBUSMEAS Object */

#define F2407_ILEG2_DCBUS_MEAS_DEFAULTS { 0x1FFF,0x0000,0x0000,             \
                                          0x1FFF,0x0000,0x0000,             \
                                          0x1FFF,0x0000,0x0000,             \
                                          0x0000,0x0D32,                    \
                                          (int (*)(int))F2407_ileg2_dcbus_drv_init, \
                                          (int (*)(int))F2407_ileg2_dcbus_drv_read  \
                                         }

#define ILEG2DCBUSMEAS_DEFAULTS F2407_ILEG2_DCBUS_MEAS_DEFAULTS 


#define CALIBRATION_CONSTANT 0

#define ADCTRL1_INIT_STATE  ADC_FREE_RUN_FLAG+ ADC_SOFT_STOP_FLAG + \
                            ADC_ACQ_PS_1 + ADC_CPS_1

/* #define ADCTRL1_INIT_STATE  ADC_SOFT_STOP_FLAG + ADC_ACQ_PS_2 + \
                            ADC_CPS_1 + ADC_SEQ_CASC     */
   
#define ADCTRL2_INIT_STATE  ADC_INT_FLAG_SEQ1  + ADC_EVA_SOC_SEQ1 + \
                            ADC_INT_FLAG_SEQ2
   

void F2407_ileg2_dcbus_drv_init(ILEG2DCBUSMEAS *);
void F2407_ileg2_dcbus_drv_read(ILEG2DCBUSMEAS *);

#endif /* __F2407_ILG_DCBUS_H__*/
