/* =====================================================================================================================
File name:        EVMDAC.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
Interface header file for the F24X/F240x EVM DAC interface(s).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef	__F24X_EVM_DAC_
#define __F24X_EVM_DAC_
#include <TARGET.H>

typedef struct {
	int *qptr0;	/* Pointer to source data output on DAC channel 0 */
	int *qptr1;	/* Pointer to source data output on DAC channel 1 */
	int *qptr2;	/* Pointer to source data output on DAC channel 2 */
	int *qptr3;	/* Pointer to source data output on DAC channel 3 */
	int scale;
	int (*update)(); 
	} EVMDAC ;       

#define EVMDAC_DEFAULTS { (int *)0x300, \
                          (int *)0x300, \
                          (int *)0x300, \
                          (int *)0x300, \
                          2000,         \
                          (int (*)(int))F24X_EVM_DAC_Update }


void F24X_EVM_DAC_Update(EVMDAC *);

#ifdef TARGET
#if  ((TARGET!=F240)&(TARGET!=F243)&(TARGET!=F2407))
#error EVMDAC.H: Unsupported Target !
#endif 
#endif
                                                                               
#endif
	
