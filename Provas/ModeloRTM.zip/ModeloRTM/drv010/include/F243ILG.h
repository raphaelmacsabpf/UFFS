/* ==================================================================================
File name:        F243ILG.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
Header file for F243ILG1.C and F243ILG2.ASM
All these three files to gether implement a 
Special Function ADC Driver. 
This ADC Driver measures two channels on the timer underflow 
event. This is intended for implementing current measurement
for a inverter.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __F243_ILG_H__
#define __F243_ILG_H__

#include "..\include\F243BMSK.H"

/*-----------------------------------------------------------------------------
Define the structure of the ILEG2MEAS Object
-----------------------------------------------------------------------------*/

typedef struct {      int gain_a;       /* Channel A gain :      Q12 : Input */
                      int offset_a;     /* Channel A offset      Q12 : Input */
                      int out_a;        /* Channel A measurement Q15:  Output*/
                      int gain_b;       /* Channel B gain :      Q12 : Input */
                      int offset_b;     /* Channel B offset      Q12 : Input */
                      int out_b;        /* Channel B measurement Q15:  Output*/
                      int ch_a;         /* Channel A ADC channel Q0:see NOTE1*/
                      int ch_b;         /* Channel B ADC channel Q0:see NOTE1*/
                      int (*init)();    /* Pointer to the init function      */
                      int (*read)();    /* Pointer to the read function      */
               } ILEG2MEAS ;                                             

/*-----------------------------------------------------------------------------
 Note 1 : It is necessary to call the init function to change the ADC 
            register settings, for the change in the channel setting for 
            either the channel A or B setting changes to take effect.
            The read function will not detect or act upon this change.
-----------------------------------------------------------------------------*/
/* Default Initializer for the ILEG2MEAS Object */

#define F243_ILEG2MEAS_DEFAULTS   {     0x1000,0x0,0x0,                   \
                                        0x1000,0x0,0x0,                   \
                                        0,4,                              \
                                        (int (*)(int))F243_leg2_drv_init, \
                                        (int (*)(int))F243_leg2_drv_read  \
                                  }

#define ILEG2MEAS_DEFAULTS F243_ILEG2MEAS_DEFAULTS

#define ADCTRL1_INIT_STATE  FREE_RUN_FLAG+SOFT_STOP_FLAG+ADCIMSTART+ADC2EN+ADC1EN 
#define ADCTRL2_INIT_STATE  ADCEVSOC+ADCPSCALE_1


void F243_leg2_drv_init(ILEG2MEAS *);
void F243_leg2_drv_read(ILEG2MEAS *);



#endif /* __F243_ILG_H__*/
