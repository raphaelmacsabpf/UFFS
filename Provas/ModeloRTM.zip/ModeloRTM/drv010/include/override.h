/* ==================================================================================
File name:        OVERRIDE.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
Each c-source file for drivers functions MUST include this file
AFTER including ALL other header files.


This file is intended for users to edit and add-in their individual 
configurations.
      
An example:

The F243_PWM.H defines the constant  ACTR_INIT_STATE to


#define ACTR_INIT_STATE ( COMPARE1_AH + \
                          COMPARE2_AL + \
                          COMPARE3_AH + \
                          COMPARE4_AL + \
                          COMPARE5_AH + \
                          COMPARE6_AL )                
                          
Let's say you want to change this to set pwm polarities to  C1 - Active low,
C2 - Active hi and so on, for some project which will be compiled with 
the compiler defined symbol PROJECT_7  

The recommended method for changing the setting is as follows:
 
#ifdef PROJECT_7

#undef ACTR_INIT_STATE

#define ACTR_INIT_STATE ( COMPARE1_AL + \
                          COMPARE2_AH + \
                          COMPARE3_AL + \
                          COMPARE4_AH + \
                          COMPARE5_AL + \
                          COMPARE6_AH )                

#endif 


AFTER Doing this it is NECESSARY to re-compile the driver - with a symbol defined
and update the libraries. To do this run the buildlib batch file - or 
another batch file containing the build command for the module that should
be up-dated.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */
