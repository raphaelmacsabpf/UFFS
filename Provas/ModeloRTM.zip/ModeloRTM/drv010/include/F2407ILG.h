/* ==================================================================================
File name:        F2407ILG.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
Header file for F2407ILG1.C and F2407ILG2.ASM
All these three files to gether implement a 
Special Function ADC Driver. 
This ADC Driver measures two channels on the timer underflow 
event. This is intended for implementing current measurement
for a inverter.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __F2407_ILG_H__
#define __F2407_ILG_H__

#include "..\include\F2407BMSK.H"

#ifndef NULL
#define NULL 0
#endif

/*-----------------------------------------------------------------------------
Define the structure of the ILEG2MEAS Object
-----------------------------------------------------------------------------*/

typedef struct {      int gain_a;       /* Channel A gain :      Q12 : Input */
                      int offset_a;     /* Channel A offset      Q12 : Input */
                      int out_a;        /* Channel A measurement Q15:  Output*/
                      int gain_b;       /* Channel B gain :      Q12 : Input */
                      int offset_b;     /* Channel B offset      Q12 : Input */
                      int out_b;        /* Channel B measurement Q15:  Output*/
                      int ch_a;         /* Channel A ADC channel Q0:see NOTE1*/
                      int ch_b;         /* Channel B ADC channel Q0:see NOTE1*/
                      int (*init)();    /* Pointer to the init function      */
                      int (*read)();    /* Pointer to the read function      */
               } ILEG2MEAS ;                                             

/*-----------------------------------------------------------------------------
 Note 1 : It is necessary to call the init function to change the ADC 
            register settings, for the change in the channel setting for 
            either the channel A or B setting changes to take effect.
            The read function will not detect or act upon this change.
-----------------------------------------------------------------------------*/
/* Default Initializer for the ILEG2MEAS Object */

#define F2407_ILEG2MEAS_DEFAULTS   {    0x1000,0x0,0x0,                   \
                                        0x1000,0x0,0x0,                   \
                                        2,3,                              \
                                        (int (*)(int))F2407_leg2_drv_init, \
                                        (int (*)(int))F2407_leg2_drv_read  \
                                  }

#define ILEG2MEAS_DEFAULTS F2407_ILEG2MEAS_DEFAULTS


#define CALIBRATION_CONSTANT 0

#define ADCTRL1_INIT_STATE  ADC_FREE_RUN_FLAG+ ADC_SOFT_STOP_FLAG + \
                            ADC_ACQ_PS_1 + ADC_CPS_1
 

#define ADCTRL2_INIT_STATE  ADC_INT_FLAG_SEQ1  + ADC_EVA_SOC_SEQ1 + \
                            ADC_INT_FLAG_SEQ2


void F2407_leg2_drv_init(ILEG2MEAS *);
void F2407_leg2_drv_read(ILEG2MEAS *);

#endif /* __F2407_ILG_H__*/
