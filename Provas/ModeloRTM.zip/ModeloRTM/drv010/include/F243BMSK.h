/* ==================================================================================
File name:        F243BMSK.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
Header file containing handy bitmasks for setting up register values.
This file defines the bitmasks for F243.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef  __F243_BMSK_H__
#define  __F243_BMSK_H__

/*------------------------------------------------------------------------------
  F243 Register TxCON
------------------------------------------------------------------------------*/
#define FREE_RUN_FLAG               0x8000
#define SOFT_STOP_FLAG              0x4000
                                      
#define TIMER_STOP                  0x0000
#define TIMER_CONT_UPDN             0x0800
#define TIMER_CONT_UP               0x1000
#define TIMER_DIR_UPDN              0x1800

#define TIMER_CLK_PRESCALE_X_1      0x0000
#define TIMER_CLK_PRESCALE_X_2      0x0100
#define TIMER_CLK_PRESCALE_X_4      0x0200
#define TIMER_CLK_PRESCALE_X_8  	0x0300
#define TIMER_CLK_PRESCALE_X_16  	0x0400
#define TIMER_CLK_PRESCALE_X_32  	0x0500
#define TIMER_CLK_PRESCALE_X_64  	0x0600
#define TIMER_CLK_PRESCALE_X_128 	0x0700

#define TIMER_ENABLE_BY_OWN		    0x0000
#define TIMER_ENABLE_BY_T1      	0x0080

#define TIMER_ENABLE            	0x0040
#define TIMER_DISABLE           	0x0000

#define TIMER_CLOCK_SRC_INTERNAL  	0x0000
#define TIMER_CLOCK_SRC_EXTERNAL  	0x0010
#define TIMER_CLOCK_SRC_QEP       	0x0030

#define TIMER_COMPARE_LD_ON_ZERO   	0x0000
#define TIMER_COMPARE_LD_ON_ZERO_OR_PRD 0x0004
#define TIMER_COMPARE_LD_IMMEDIATE 	0x0008

#define TIMER_ENABLE_COMPARE        0x0002
#define TIMER_SELECT_T1_PERIOD      0x0001

/*------------------------------------------------------------------------------
F243 Register ACTR 0x7413 BIT FIELD MASKS
------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------
Space Vector Direction Commands
------------------------------------------------------------------------------*/
#define SV_DIRECTION_CW             0x8000
#define SV_DIRECTION_CCW            0x0000

/*------------------------------------------------------------------------------
Space Vector Generation Vectors
------------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*/
#define SPACE_VECTOR_0		        0x0000
#define SPACE_VECTOR_1		        0x1000
#define SPACE_VECTOR_2		        0x2000
#define SPACE_VECTOR_3		        0x3000
#define SPACE_VECTOR_4		        0x4000
#define SPACE_VECTOR_5		        0x5000
#define SPACE_VECTOR_6		        0x6000
#define SPACE_VECTOR_7		        0x7000


/*------------------------------------------------------------------------------
 Compare action definitions
------------------------------------------------------------------------------*/
#define COMPARE6_FL		        0x0000
#define COMPARE6_AL		        0x0400
#define COMPARE6_AH		        0x0800
#define COMPARE6_FH		        0x0c00
/*----------------------------------------------------------------------------*/
#define COMPARE5_FL		        0x0000
#define COMPARE5_AL		        0x0100
#define COMPARE5_AH		        0x0200
#define COMPARE5_FH		        0x0300
/*----------------------------------------------------------------------------*/
#define COMPARE4_FL		        0x0000
#define COMPARE4_AL		        0x0040
#define COMPARE4_AH		        0x0080
#define COMPARE4_FH		        0x00c0
/*----------------------------------------------------------------------------*/
#define COMPARE3_FL		        0x0000
#define COMPARE3_AL		        0x0010
#define COMPARE3_AH		        0x0020
#define COMPARE3_FH		        0x0030
/*----------------------------------------------------------------------------*/
#define COMPARE2_FL		        0x0000
#define COMPARE2_AL		        0x0004
#define COMPARE2_AH		        0x0008
#define COMPARE2_FH		        0x000c
/*----------------------------------------------------------------------------*/
#define COMPARE1_FL		        0x0000
#define COMPARE1_AL		        0x0001
#define COMPARE1_AH		        0x0002
#define COMPARE1_FH		        0x0003
/*----------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
  F243 Register COMCON
------------------------------------------------------------------------------*/
#define CMPR_ENABLE			0x8000
#define CMPR_LD_ON_ZERO         	0x0000
#define CMPR_LD_ON_ZERO_OR_PRD  	0x2000
#define CMPR_LD_IMMEDIATE       	0x4000
#define SVENABLE                	0x1000
#define SVDISABLE               	0x0000
#define ACTR_LD_ON_ZERO         	0x0000
#define ACTR_LD_ON_ZERO_OR_PRD  	0x0400
#define ACTR_LD_IMMEDIATE       	0x0800
#define FCOMPOE                 	0x0100     

/*------------------------------------------------------------------------------
F243 Register DBTCON
------------------------------------------------------------------------------*/
#define DBT_VAL_0	        0x0000
#define DBT_VAL_1	        0x0100
#define DBT_VAL_2               0x0200
#define DBT_VAL_3               0x0300
#define DBT_VAL_4               0x0400
#define DBT_VAL_5               0x0500
#define DBT_VAL_6               0x0600
#define DBT_VAL_7               0x0700
#define DBT_VAL_8               0x0800
#define DBT_VAL_9               0x0900
#define DBT_VAL_10              0x0a00
#define DBT_VAL_11              0x0b00
#define DBT_VAL_12              0x0c00
#define DBT_VAL_13              0x0d00
#define DBT_VAL_14              0x0e00
#define DBT_VAL_15              0x0f00

#define EDBT3_DIS               0x0000
#define EDBT3_EN                0x0080
#define EDBT2_DIS               0x0000
#define EDBT2_EN                0x0040
#define EDBT1_DIS               0x0000
#define EDBT1_EN                0x0020

#define DBTPS_X32               0x0014
#define DBTPS_X16               0x0010
#define DBTPS_X8                0x000C
#define DBTPS_X4                0x0008
#define DBTPS_X2                0x0004
#define DBTPS_X1                0x0000


/*------------------------------------------------------------------------------
F243 Register ADCTRL1
------------------------------------------------------------------------------*/
#define FREE_RUN_FLAG           0x8000
#define SOFT_STOP_FLAG          0x4000
#define ADCIMSTART		0x2000
#define ADC2EN			0x1000
#define ADC1EN			0x0800
#define ADCCONRUN		0x0400
#define ADCINTEN		0x0200
#define ADCINTFLAG		0x0100
#define ADCEOC			0x0080

#define ADC2CHSEL_0             0x0000
#define ADC2CHSEL_1             0x0010
#define ADC2CHSEL_2             0x0020
#define ADC2CHSEL_3             0x0030
#define ADC2CHSEL_4             0x0040
#define ADC2CHSEL_5             0x0050
#define ADC2CHSEL_6             0x0060
#define ADC2CHSEL_7             0x0070

#define ADC1CHSEL_0             0x0000
#define ADC1CHSEL_1             0x0002
#define ADC1CHSEL_2             0x0004
#define ADC1CHSEL_3             0x0006
#define ADC1CHSEL_4             0x0008
#define ADC1CHSEL_5             0x000a
#define ADC1CHSEL_6             0x000c
#define ADC1CHSEL_7             0x000e

#define ADCSOC			0x0001

/*----------------------------------------------------------------------------*/
/* F243 Register ADCTRL2                                                      */
/*----------------------------------------------------------------------------*/

#define IM                      0x4000
#define EVSOCP                  0x2000
#define EXTSOCP                 0x1000

#define INTPRI                  0x0800
#define ADCEVSOC                0x0400
#define ADCEXTSOC               0x0200

#define ADCFIFO2_MASK           0x00c0
#define ADCFIFO1_MASK           0x0018

#define ADCPSCALE_1             0x0000
#define ADCPSCALE_2             0x0001
#define ADCPSCALE_4             0x0002
#define ADCPSCALE_8             0x0003
#define ADCPSCALE_12            0x0004
#define ADCPSCALE_16            0x0005
#define ADCPSCALE_24            0x0006
#define ADCPSCALE_32            0x0007

#endif  /* __F243_BMSK_H__ */
/* EOF */




                                	
