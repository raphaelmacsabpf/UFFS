/* ==================================================================================
File name:        F2407PWM.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
Header file containing data type and object definitions and 
initializers. Also contains prototypes for the functions in F2407_PWM?.C.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __F2407_PWM_H__
#define __F2407_PWM_H__
#include "..\include\F2407BMSK.H"

/*----------------------------------------------------------------------------
Initialization constant for the F2407 Timer TxCON for PWM Generation. 
Sets up the timer to run free upon emulation suspend, continuous up-down mode
prescaler 1, timer enabled.
----------------------------------------------------------------------------*/
#define PWM_INIT_STATE  (FREE_RUN_FLAG +         \
                        TIMER_CONT_UPDN +        \
                        TIMER_CLK_PRESCALE_X_1 + \
                        TIMER_ENABLE_BY_OWN    + \
                        TIMER_ENABLE)
/*----------------------------------------------------------------------------
Initialization constant for the F2407 ACTRx register for PWM Generation. 
Sets up PWM polarities.
----------------------------------------------------------------------------*/
/*#define ACTR_INIT_STATE ( COMPARE1_FL + \
                          COMPARE2_FL + \
                          COMPARE3_FL + \
                          COMPARE4_FL + \
                          COMPARE5_FL + \
                          COMPARE6_FL )

/*#define ACTR_INIT_STATE ( COMPARE1_AH + \
                          COMPARE2_AL + \
                          COMPARE3_FH + \
                          COMPARE4_FH + \
                          COMPARE5_FH + \
                          COMPARE6_FH )
*/
#define ACTR_INIT_STATE ( COMPARE1_AH + \
                          COMPARE2_AL + \
                          COMPARE3_AH + \
                          COMPARE4_AL + \
                          COMPARE5_AH + \
                          COMPARE6_AL )


/*----------------------------------------------------------------------------
Initialization constant for the F2407 DBTCONx register for PWM Generation. 
Sets up the dead band for PWM and sets up dead band values.
----------------------------------------------------------------------------*/
#define DBTCON_INIT_STATE ( DBT_VAL_10 +  \
                            EDBT3_EN   +  \
                            EDBT2_EN   +  \
                            EDBT1_EN   +  \
                            DBTPS_X4 )
/*-----------------------------------------------------------------------------
Define the structure of the PWM Driver Object 
-----------------------------------------------------------------------------*/
typedef struct {   
                                   
        int period_max;        /* PWM Period in CPU clock cycles.  Q0-Input  */
        int mfunc_p;           /* Period scaler. Q15 - Input                 */
        int mfunc_c1;          /* PWM 1&2 Duty cycle ratio. Q15, Input       */
        int mfunc_c2;          /* PWM 3&4 Duty cycle ratio. Q15, Input       */
        int mfunc_c3;          /* PWM 5&6 Duty cycle ratio. Q15, Input       */
        int (*init)();         /* Pointer to the init function               */
        int (*update)();       /* Pointer to the update function             */
        } PWMGEN ;    

/*-----------------------------------------------------------------------------
Define a PWMGEN_handle
-----------------------------------------------------------------------------*/
typedef PWMGEN *PWMGEN_handle;





/*------------------------------------------------------------------------------
Default Initializers for the F2407 PWMGEN Object 
------------------------------------------------------------------------------*/
#define F2407_EV1_FC_PWM_GEN {1500,   \
                              0x7fff, \
                              0x4000, \
                              0x4000, \
                              0x4000, \
                             (int (*)(int))F2407_EV1_PWM_Init,  \
                             (int (*)(int))F2407_EV1_PWM_Update \
                             }

#define F2407_EV2_FC_PWM_GEN {1500,   \
                              0x7fff, \
                              0x4000, \
                              0x4000, \
                              0x4000, \
                             (int (*)(int))F2407_EV2_PWM_Init,  \
                             (int (*)(int))F2407_EV2_PWM_Update \
                             }

#define PWMGEN_DEFAULTS F2407_EV1_FC_PWM_GEN

/*------------------------------------------------------------------------------
 Prototypes for the functions in F2407_PWM1.C , F2407_PWM2.ASM
------------------------------------------------------------------------------*/
int F2407_EV1_PWM_Init(PWMGEN *);
int F2407_EV1_PWM_Update(PWMGEN *);
int F2407_EV2_PWM_Init(PWMGEN *);
int F2407_EV2_PWM_Update(PWMGEN *);

#endif  /*__F2407_PWM_H__*/

