/* ==================================================================================
File name:        WATCHDOG.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description:   
Front end header file for the Watchdog driver interface(s).
This header file includes the correct header file for the 
target defined by the Main source file. 
The main source file defines the target device by means of the 
#define TARGET XXXX Statement.
Choices currently accepted are F24X and F24XX.
Depending on this choice the correct header file is included in by this
file.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __WATCHDOG_H__
#define __WATCHDOG_H__
#include <TARGET.H>

#if ((TARGET==F240)|(TARGET==F243)|(TARGET==F2407))
#include <F24X_WD.H> 
#endif /* TARGET == F24X/F240X*/
 
#ifdef TARGET
#if  ((TARGET!=F240)&(TARGET!=F243)&(TARGET!=F2407))
#error WATCHDOG.H: Unsupported Target !
#endif 
#endif


#ifndef TARGET 
#error  Critical: A target must be defined !!
#endif  /* TARGET */          

#endif  /* __PWMGEN_H__ */


