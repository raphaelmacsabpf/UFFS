/* ==================================================================================
File name:        ADC_16CH.H                     
                    
Author:	Sidelmo M. Silva

Description:  


This file defines handy constants for object initializations and
contains prototypes for the functions in ADC_16CH.C.

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 09-04-2004	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __ADC_16CH_H__
#define __ADC_16CH_H__

#include "..\include\F2407BMSK.H"

#ifndef NULL
#define NULL 0
#endif

/*-----------------------------------------------------------------------------
Define the structure of the ADC_16CH
-----------------------------------------------------------------------------*/


typedef struct { int ch0;   /* Conversion result for channel 0 [Q15]*/
                 int ch1;   /* Conversion result for channel 1 [Q15]*/
                 int ch2;   /* Conversion result for channel 2 [Q15]*/
                 int ch3;   /* Conversion result for channel 3 [Q15]*/
                 int ch4;   /* Conversion result for channel 4 [Q15]*/
                 int ch5;   /* Conversion result for channel 5 [Q15]*/
                 int ch6;   /* Conversion result for channel 6 [Q15]*/
                 int ch7;   /* Conversion result for channel 7 [Q15]*/
                 int ch8;   /* Conversion result for channel 8 [Q15]*/
                 int ch9;   /* Conversion result for channel 9 [Q15]*/
                 int ch10;  /* Conversion result for channel 10 [Q15]*/
                 int ch11;  /* Conversion result for channel 11 [Q15]*/
                 int ch12;  /* Conversion result for channel 12 [Q15]*/
                 int ch13;  /* Conversion result for channel 13 [Q15]*/
                 int ch14;  /* Conversion result for channel 14 [Q15]*/
                 int ch15;  /* Conversion result for channel 15 [Q15]*/
                 int offset0;  /* Conversion result for channel 0 [Q15]*/
                 int offset1;  /* Conversion result for channel 1 [Q15]*/
                 int offset2;  /* Conversion result for channel 2 [Q15]*/
                 int offset3;  /* Conversion result for channel 3 [Q15]*/
                 int offset4;  /* Conversion result for channel 4 [Q15]*/
                 int offset5;  /* Conversion result for channel 5 [Q15]*/
                 int offset6;  /* Conversion result for channel 6 [Q15]*/
                 int offset7;  /* Conversion result for channel 7 [Q15]*/
                 int offset8;  /* Conversion result for channel 8 [Q15]*/
                 int offset9;  /* Conversion result for channel 9 [Q15]*/
                 int offset10; /* Conversion result for channel 10 [Q15]*/
                 int offset11; /* Conversion result for channel 11 [Q15]*/
                 int offset12; /* Conversion result for channel 12 [Q15]*/
                 int offset13; /* Conversion result for channel 13 [Q15]*/
                 int offset14; /* Conversion result for channel 14 [Q15]*/
                 int offset15; /* Conversion result for channel 15 [Q15]*/
                 int ch_sel_1; /* ADC channel select variable[Q0] */
                 int ch_sel_2; /* ADC channel select variable[Q0] */
                 int ch_sel_3; /* ADC channel select variable[Q0] */
                 int ch_sel_4; /* ADC channel select variable[Q0] */
                 int (*init)();                           /* Initialization func pointer  */
                 int (*update)();                         /* Update function              */
               } ADC16CH;


/*------------------------------------------------------------------------------
Default Initializers for the ADC16CH Object
------------------------------------------------------------------------------*/

#define ADC_16CH_DEFAULTS { 0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x3210,\
                            0x7654,\
                            0xBA98,\
                            0xFEDC,\
                            (int (*)(int))ADC_16CH_Init, \
                            (int (*)(int))ADC_16CH_Update \
                           }




#define CALIBRATION_CONSTANT 0

#define ADCTRL1_INIT_STATE  ADC_SOFT_STOP_FLAG + ADC_SEQ_CASC + \
                            ADC_ACQ_PS_16 + ADC_CPS_2

#define ADCTRL2_INIT_STATE  ADC_INT_FLAG_SEQ1  + ADC_SOC_SEQ1 + \
                            ADC_INT_FLAG_SEQ2
   
/*----------------------------------------------------------------------------
 Function prototypes
 ----------------------------------------------------------------------------*/

void ADC_16CH_Init(ADC16CH *p);
void ADC_16CH_Update(ADC16CH *p);


#endif     /*__ADC_16CH_H__ */

