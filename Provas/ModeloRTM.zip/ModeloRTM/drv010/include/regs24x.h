/* ==================================================================================
File name:        regs24x.h                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description:   F24x register definitions.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __REGS24X_H__
#define __REGS24X_H__


/* C2xx core registers */
#define IMR             *((volatile int *)0x0004)              /* Interrupt Mask Register                               */
#define GREG            *((volatile int *)0x0005)              /* Global memory allocation Register 			*/
#define IFR             *((volatile int *)0x0006)              /* Interrupt Flag Register                               */
                                          
/* System configuration and interrupt registers*/
                                    
#define SYSCR		*((volatile int *)0x7018)              /* System Module Control Register. X240  only.		*/
#define SYSSR           *((volatile int *)0x701A)              /* System Module Status Register. X240 only.		*/
#define SYSIVR   	*((volatile int *)0x701E)              /* System Interrupt Vector Register. X240 only.		*/
#define SCSR 		*((volatile int *)0x7018)              /* System Control & System Status Reg. X241/2/3 only.	*/
#define DIN   		*((volatile int *)0x701C)              /* Device Identification Register.                       */
#define PIVR  		*((volatile int *)0x701E)              /* Peripheral Interrupt Vector Reg. X241/2/3 only.	*/
#define PIRQR0 		*((volatile int *)0x7010)              /* Peripheral Interrupt Request Reg 0. X241/2/3 only.	*/
#define PIRQR1   	*((volatile int *)0x7011)              /* Peripheral Interrupt Request Reg 1. X241/2/3 only.	*/
                               
/* PLL configuration registers*/

#define CKCR0        	*((volatile int *)0x702a)              /* PLL Clock Control Register 0. X240 only.*/


/* External interrupt configuration registers */
#define XINT1CR  	*((volatile int *)7070h)              	    /* Int1 (type A) Control reg for X240 only.         */
                                                                /* External interrupt 1 config reg for X241/2/3 only. 	*/ 
#define NMICR      	*((volatile int *)0x7072)              /* Non maskable Int (type A) Control reg. X240 only.  	*/
#define XINT2CR240      *((volatile int *)0x7078)              /* Int2 (type C) Control reg. X240 only.              	*/
#define XINT2CR241      *((volatile int *)0x7071)              /* External interrupt 2 config. X241/2/3 only.        	*/
#define XINT3CR  	*((volatile int *)0x707A)              /* Int3 (type C) Control reg. X240 only.                 */
                                                                                                  	
/* Digital I/O registers                                                                          	*/
#define OCRA            *((volatile int *)0x7090)              /* Output Control Reg A                                     */
#define MCRA            *((volatile int *)0x7090)              /* Output Control Reg A                                     */
#define OCRB            *((volatile int *)0x7092)              /* Output Control Reg B                                     */
#define MCRB            *((volatile int *)0x7092)              /* Output Control Reg B                                     */
#define ISRA            *((volatile int *)0x7094)              /*Input Status Reg A. X240 only                             */
#define ISRB            *((volatile int *)0x7096)              /*Input Status Reg B. X240 only                             */
#define PADATDIR        *((volatile int *)0x7098)              /* I/O port A Data & Direction reg.                         */
#define PBDATDIR        *((volatile int *)0x709A)              /* I/O port B Data & Direction reg.                         */
#define PCDATDIR        *((volatile int *)0x709C)              /* I/O port C Data & Direction reg.                         */
#define PDDATDIR        *((volatile int *)0x709E)              /* I/O port D Data & Direction reg.                         */
                                                                                                  	
/* Watchdog (WD) registers
#define WDCNTR          *((volatile int *)0x7023)              /* WD Counter reg                                           */
#define WDKEY           *((volatile int *)0x7025)              /* WD Key reg                                               */
#define WDCR            *((volatile int *)0x7029)              /* WD Control reg                                           */
                                   
/* Real Time Interrupt registers                                                                        */
#define RTICNTR         *((volatile int *)0x7021)              /* RTI counter reg. X240 only.                              */
#define RTICR           *((volatile int *)0x7027)              /* RTI control reg. X240 only.                              */
                                        
/* ADC registers                                                                                        */
#define ADCTRL1         *((volatile int *)0x7032)              /* ADC Control Reg1                                   	*/
#define ADC_CNTL1       *((volatile int *)0X7032)  			   /* ADC CONTROL reg 1  */
#define ADCTRL2         *((volatile int *)0x7034)              /* ADC Control Reg2                                   	*/
#define ADC_CNTL2       *((volatile int *)0X7034)  		       /* ADC CONTROL reg 2  */
#define ADCFIFO1        *((volatile int *)0x7036)              /* ADC DATA REG FIFO for ADC1                         	*/
#define ADC_FIFO1       *((volatile int *)0X7036)  	 		   /* ADC FIFO data reg 1*/
#define ADCFIFO2        *((volatile int *)0x7038)              /* ADC DATA REG FIFO for ADC2                         	*/
#define ADC_FIFO2       *((volatile int *)0X7038)               /* ADC FIFO data reg 2*/

                                  
/* SPI registers                                                                                  	*/
#define SPICCR          *((volatile int *)0x7040)              /* SPI Config Control Reg                                   */
#define SPICTL          *((volatile int *)0x7041)              /* SPI Operation Control Reg                                */
#define SPISTS          *((volatile int *)0x7042)              /* SPI Status Reg                                           */
#define SPIBRR          *((volatile int *)0x7044)             /* SPI Baud rate control reg                                 */
#define SPIRXEMU        *((volatile int *)0x7046)              /* SPI Emulation buffer reg                           	*/
#define SPIRXBUF        *((volatile int *)0x7047)              /* SPI Serial receive buffer reg                      	*/
#define SPITXBUF        *((volatile int *)0x7048)              /* SPI Serial transmit buffer reg                     	*/
#define SPIDAT          *((volatile int *)0x7049)              /* SPI Serial data reg                                      */
#define SPIPC1          *((volatile int *)0x704D)              /* SPI Port Control Register 1. X240 only.                  */
#define SPIPC2          *((volatile int *)0x704E)              /* SPI Port Control Register 2. X240 only.                  */
#define SPIPRI          *((volatile int *)0x704F)              /* SPI Priority control reg                                 */
                                              
/* SCI registers                                                                                  	*/
#define SCICCR          *((volatile int *)0x7050)              /* SCI Communication control reg                            */
#define SCICTL1         *((volatile int *)0x7051)              /* SCI Control reg1                                         */
#define SCIHBAUD        *((volatile int *)0x7052)              /* SCI Baud Rate MSbyte reg                           	*/
#define SCILBAUD        *((volatile int *)0x7053)              /* SCI Baud Rate LSbyte reg                           	*/
#define SCICTL2         *((volatile int *)0x7054)              /* SCI Control reg2                                         */
#define SCIRXST         *((volatile int *)0x7055)              /* SCI Receiver Status reg                                  */
#define SCIRXEMU        *((volatile int *)0x7056)              /* SCI Emulation Data Buffer reg                      	*/
#define SCIRXBUF        *((volatile int *)0x7057)              /* SCI Receiver Data buffer reg                       	*/
#define SCITXBUF        *((volatile int *)0x7059)              /* SCI Transmit Data buffer reg                       	*/
#define SCIPC2          *((volatile int *)0x705E)              /* SCI Port Control reg2 (X240 only)                        */
#define SCIPRI          *((volatile int *)0x705F)              /* SCI Priority control reg                                 */
                                    
/* Event Manager (EV) registers */
                                                   
#define GPTCON          *((volatile int *)0x7400)              /* GP Timer control register.                               */
#define T1CNT           *((volatile int *)0x7401)              /* GP Timer 1 counter register.                       	*/
#define T1CMPR          *((volatile int *)0x7402)              /* GP Timer 1 compare register.                             */
#define T1PR            *((volatile int *)0x7403)              /* GP Timer 1 period register.                        	*/
#define T1PER           *((volatile int *)0x7403)              /* GP Timer 1 period register.                        	*/
#define T1CON           *((volatile int *)0x7404)              /* GP Timer 1 control register.                       	*/
#define T2CNT           *((volatile int *)0x7405)              /* GP Timer 2 counter register.                       	*/
#define T2CMPR          *((volatile int *)0x7406)              /* GP Timer 2 compare register.                             */
#define T2PR            *((volatile int *)0x7407)              /* GP Timer 2 period register.                        	*/
#define T2PER           *((volatile int *)0x7407)              /* GP Timer 2 period register.                        	*/
#define T2CON           *((volatile int *)0x7408)              /* GP Timer 2 control register.                       	*/
#define T3CNT           *((volatile int *)0x7409)              /* GP Timer 3 counter register. X240 only.            	*/
#define T3CMPR          *((volatile int *)0x740A)              /* GP Timer 3 compare register.  X240 only.                 */
#define T3PR            *((volatile int *)0x740B)              /* GP Timer 3 period register.  X240 only.            	*/
#define T3PER           *((volatile int *)0x740B)              /* GP Timer 3 period register.  X240 only.            	*/
#define T3CON           *((volatile int *)0x740C)              /* GP Timer 3 control register. X240 only.            	*/
                                 
#define COMCON          *((volatile int *)0x7411)              /* Compare control register. 				*/
#define ACTR            *((volatile int *)0x7413)              /* Full compare action control register.			*/
#define SACTR           *((volatile int *)0x7414)              /* Simple compare action control register.			*/ 
#define DBTCON          *((volatile int *)0x7415)              /* Dead-band timer control register. 			*/
                               
#define CMPR1           *((volatile int *)0x7417)              /* Full compare unit compare register1. 			*/
#define CMPR2           *((volatile int *)0x7418)              /* Full compare unit compare register2.			*/
#define CMPR3           *((volatile int *)0x7419)              /* Full compare unit compare register3.			*/
                              
#define SCMPR1          *((volatile int *)0x741A)              /* Simple compare unit compare register1. X240 only.	*/
#define SCMPR2          *((volatile int *)0x741B)              /* Simple compare unit compare register2. X240 only.	*/
#define SCMPR3          *((volatile int *)0x741C)              /* Simple compare unit compare register3. X240 only.	*/
                                  
#define CAPCON          *((volatile int *)0x7420)              /* Capture control register. 				*/
#define CAPFIFO         *((volatile int *)0x7422)              /* Capture FIFO status register. 				*/
			
#define CAP1FIFO        *((volatile int *)0x7423)              /* Capture Channel 1 FIFO Top                               */
#define CAP2FIFO        *((volatile int *)0x7424)              /* Capture Channel 2 FIFO Top				*/
#define CAP3FIFO        *((volatile int *)0x7425)              /* Capture Channel 3 FIFO Top				*/
#define CAP4FIFO        *((volatile int *)0x7426)              /* Capture Channel 4 FIFO Top. X240 only.			*/
#define EVIMRA          *((volatile int *)0x742C)              /* Group A Interrupt Mask Register				*/
#define IMRA            *((volatile int *)0X742C)              /* Group A Int Mask */
#define EVIMRB          *((volatile int *)0x742D)              /* Group B Interrupt Mask Register				*/
#define IMRB            *((volatile int *)0X742D)              /* Group B Int Mask */
#define EVIMRC          *((volatile int *)0x742E)              /* Group C Interrupt Mask Register				*/
#define IMRC            *((volatile int *)0X742E)              /* Group C Int Mask */
#define EVIFRA          *((volatile int *)0x742F)              /* Group A Interrupt Flag Register 				*/
#define IFRA            *((volatile int *)0X742F)              /*Group A Int Flag */
#define EVIFRB          *((volatile int *)0x7430)              /* Group B Interrupt Flag Register				*/
#define IFRB            *((volatile int *)0X7430)              /* Group B Int Flag  */
#define EVIFRC          *((volatile int *)0x7431)              /* Group C Interrupt Flag Register				*/
#define IFRC            *((volatile int *)0X7431)              /* Group C Int Flag */
#define EVIVRA         	*((volatile int *)0x7432)              /* Group A Int. Vector Register. X240 only.			*/
#define EVIVRB          *((volatile int *)0x7433)              /* Group B Int. Vector Register. X240 only.			*/
#define EVIVRC          *((volatile int *)0x7434)              /* Group C Int. Vector Register. X240 only.			*/

/* CAN(SCC) registers. X241/2/3 only.*/
#define CANMDER         *((volatile int *)0x7100)              /* CAN Mailbox Direction/Enable reg				*/
#define CANTCR          *((volatile int *)0x7101)              /* CAN Transmission Control Reg				*/
#define CANRCR          *((volatile int *)0x7102)              /* CAN Recieve COntrol Reg					*/
#define CANMCR          *((volatile int *)0x7103)              /* CAN Master Control Reg					*/
#define CANBCR2         *((volatile int *)0x7104)              /* CAN Bit COnfig Reg 2					*/
#define CANBCR1         *((volatile int *)0x7105)              /* CAN Bit Config Reg 1					*/
#define CANESR          *((volatile int *)0x7106)              /* CAN Error Status Reg					*/
#define CANGSR          *((volatile int *)0x7107)              /* CAN Global Status Reg					*/
#define CANCEC          *((volatile int *)0x7108)              /* CAN Trans and Rcv Err counters				*/
#define CANIFR          *((volatile int *)0x7109)              /* CAN Interrupt Flag Registers 				*/
#define CANIMR          *((volatile int *)0x710a)              /* CAN Interrupt Mask Registers				*/
#define CANLAM0H        *((volatile int *)0x710b)              /* CAN Local Acceptance Mask MBx0/1				*/
#define CANLAM0L        *((volatile int *)0x710c)              /* CAN Local Acceptance Mask MBx0/1				*/
#define CANLAM1H        *((volatile int *)0x710d)              /* CAN Local Acceptance Mask MBx2/3				*/
#define CANLAM1L        *((volatile int *)0x710e)              /* CAN Local Acceptance Mask MBx2/3				*/
#define CANMSGID0L      *((volatile int *)0x7200)              /* CAN Message ID for mailbox 0 (lower 16 bits) 		*/
#define CANMSGID0H      *((volatile int *)0x7201)              /* CAN Message ID for mailbox 0 (upper 16 bits) 		*/
#define CANMSGCTRL0     *((volatile int *)0x7202)              /* CAN RTR and DLC 						*/
#define CANMBX0A        *((volatile int *)0x7204)              /* CAN 2 of 8 bytes of Mailbox 0 				*/
#define CANMBX0B        *((volatile int *)0x7205)              /* CAN 2 of 8 bytes of Mailbox 0 				*/
#define CANMBX0C        *((volatile int *)0x7206)              /* CAN 2 of 8 bytes of Mailbox 0 				*/
#define CANMBX0D        *((volatile int *)0x7207)              /* CAN 2 of 8 bytes of Mailbox 0 				*/
#define CANMSGID1L      *((volatile int *)0x7208)              /* CAN Message ID for mailbox 1 (lower 16 bits) 		*/
#define CANMSGID1H      *((volatile int *)0x7209)              /* CAN Message ID for mailbox 1 (upper 16 bits) 		*/
#define CANMSGCTRL1     *((volatile int *)0x720A)              /* CAN RTR and DLC 						*/
#define CANMBX1A        *((volatile int *)0x720C)              /* CAN 2 of 8 bytes of Mailbox 1 				*/
#define CANMBX1B        *((volatile int *)0x720D)              /* CAN 2 of 8 bytes of Mailbox 1 				*/
#define CANMBX1C        *((volatile int *)0x720E)              /* CAN 2 of 8 bytes of Mailbox 1 				*/
#define CANMBX1D        *((volatile int *)0x720F)              /* CAN 2 of 8 bytes of Mailbox 1 				*/
#define CANMSGID2L      *((volatile int *)0x7210)              /* CAN Message ID for mailbox 2 (lower 16 bits) 		*/
#define CANMSGID2H      *((volatile int *)0x7211)              /* CAN Message ID for mailbox 2 (upper 16 bits) 		*/
#define CANMSGCTRL2     *((volatile int *)0x7212)              /* CAN RTR and DLC 						*/
#define CANMBX2A        *((volatile int *)0x7214)              /* CAN 2 of 8 bytes of Mailbox 2 				*/
#define CANMBX2B        *((volatile int *)0x7215)              /* CAN 2 of 8 bytes of Mailbox 2 				*/
#define CANMBX2C        *((volatile int *)0x7216)              /* CAN 2 of 8 bytes of Mailbox 2 				*/
#define CANMBX2D        *((volatile int *)0x7217)              /* CAN 2 of 8 bytes of Mailbox 2 				*/
#define CANMSGID3L      *((volatile int *)0x7218)              /* CAN Message ID for mailbox 3 (lower 16 bits) 		*/
#define CANMSGID3H      *((volatile int *)0x7219)              /* CAN Message ID for mailbox 3 (upper 16 bits) 		*/
#define CANMSGCTRL3     *((volatile int *)0x721A)              /* CAN RTR and DLC 						*/
#define CANMBX3A        *((volatile int *)0x721C)              /* CAN 2 of 8 bytes of Mailbox 3 				*/
#define CANMBX3B        *((volatile int *)0x721D)              /* CAN 2 of 8 bytes of Mailbox 3 				*/
#define CANMBX3C        *((volatile int *)0x721E)              /* CAN 2 of 8 bytes of Mailbox 3 				*/
#define CANMBX3D        *((volatile int *)0x721F)              /* CAN 2 of 8 bytes of Mailbox 3 				*/
#define CANMSGID4L      *((volatile int *)0x7220)              /* CAN Message ID for mailbox 4 (lower 16 bits) 		*/
#define CANMSGID4H      *((volatile int *)0x7221)              /* CAN Message ID for mailbox 4 (upper 16 bits) 		*/
#define CANMSGCTRL4     *((volatile int *)0x7222)              /* CAN RTR and DLC 						*/
#define CANMBX4A        *((volatile int *)0x7224)              /* CAN 2 of 8 bytes of Mailbox 4 				*/
#define CANMBX4B        *((volatile int *)0x7225)              /* CAN 2 of 8 bytes of Mailbox 4 				*/
#define CANMBX4C        *((volatile int *)0x7226)              /* CAN 2 of 8 bytes of Mailbox 4 				*/
#define CANMBX4D        *((volatile int *)0x7227)              /* CAN 2 of 8 bytes of Mailbox 4 				*/
#define CANMSGID5L      *((volatile int *)0x7228)              /* CAN Message ID for mailbox 5 (lower 16 bits) 		*/
#define CANMSGID5H      *((volatile int *)0x7229)              /* CAN Message ID for mailbox 5 (upper 16 bits) 		*/
#define CANMSGCTRL5     *((volatile int *)0x722A)              /* CAN RTR and DLC 						*/
#define CANMBX5A        *((volatile int *)0x722C)              /* CAN 2 of 8 bytes of Mailbox 5 				*/
#define CANMBX5B        *((volatile int *)0x722D)              /* CAN 2 of 8 bytes of Mailbox 5 				*/
#define CANMBX5C        *((volatile int *)0x722E)              /* CAN 2 of 8 bytes of Mailbox 5 				*/



/*--------------------------------------------------------------------------*/
/* Bit codes for Test bit instruction (BIT) (15 Loads bit 0 into TC)        */
/*--------------------------------------------------------------------------*/
#define BIT15           0x0000              /* Bit Code for 15              */
#define BIT14           0x0001              /* Bit Code for 14*/
#define BIT13           0x0002              /* Bit Code for 13*/
#define BIT12           0x0003              /* Bit Code for 12*/
#define BIT11           0x0004              /* Bit Code for 11*/
#define BIT10           0x0005              /* Bit Code for 10*/
#define BIT9            0x0006              /* Bit Code for 9*/
#define BIT8            0x0007              /* Bit Code for 8*/
#define BIT7            0x0008              /* Bit Code for 7*/
#define BIT6            0x0009              /* Bit Code for 6*/
#define BIT5            0x000A              /* Bit Code for 5*/
#define BIT4            0x000B              /* Bit Code for 4*/
#define BIT3            0x000C              /* Bit Code for 3*/
#define BIT2            0x000D              /* Bit Code for 2*/
#define BIT1            0x000E              /* Bit Code for 1*/
#define BIT0            0x000F              /* Bit Code for 0*/

/*
--------------------------------------------------------------------------
Test mode on and off constants
--------------------------------------------------------------------------
*/

#define ABRPT           *((volatile int *)0x01f)               /* Analysis BreakPoint Register*/
#define PSA_ON          *((volatile int *)0x03A1)              /* Turn PSA and FEEDB on*/
#define PSA_FB_OFF      *((volatile int *)0x0121)              /* Turn PSA and FEEDB off*/

/*--------------------------------------------------------------------------*/
/* I/O space mapped registers						    */
/*--------------------------------------------------------------------------*/
/* Wait-State Generator Control Reg */

#define WSGR	portffff
ioport unsigned portffff;
ioport unsigned port0;
ioport unsigned port1;
ioport unsigned port2;
ioport unsigned port3;
ioport unsigned port4;  

#define DAC0	port0
#define DAC1	port1
#define DAC2	port2
#define DAC3	port3
#define DACL	port4





#endif
