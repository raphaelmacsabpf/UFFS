/* ==================================================================================
File name:        F2407BLDCPWM.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:  
This file defines handy constants for object initializations and
contains prototypes for the functions in F2407BLDCPWM1.C and F2407BLDCPWM2.ASM
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __F2407_BLDCPWM_H__
#define __F2407_BLDCPWM_H__

#include "..\include\F2407BMSK.H"

/*----------------------------------------------------------------------------
Initialization constant for the F2407 Timer TxCON for PWM Generation. 
----------------------------------------------------------------------------*/
#define PWM_INIT_STATE  (FREE_RUN_FLAG +       \
                        TIMER_CONT_UP +        \
                        TIMER_CLK_PRESCALE_X_1 + \
                        TIMER_ENABLE)

/*-----------------------------------------------------------------------------
Define the structure of  BLDC3_PWM_DRV
-----------------------------------------------------------------------------*/

typedef struct {

   int cmtn_ptr_bd; /* Commutation(or switching) state pointer input[Q0] */
   int mfunc_p;     /* Duty ratio of the PWM outputs[Q15]                */
   int period_max;  /* Maximum period                                    */
   int d_func;      /* PWM period modulation input[Q15]                  */

   int (*init)();   /* Function pointer to INIT function             */
   int (*update)(); /* Function pointer to UPDATE function           */
   } PWMGEN;

/*-----------------------------------------------------------------------------
Define a PWMGEN_handle
-----------------------------------------------------------------------------*/

typedef PWMGEN  *PWMGEN_handle;

/*------------------------------------------------------------------------------
Default Initializers for the F2407 PWMGEN Object
------------------------------------------------------------------------------*/

#define F2407_PWMGEN_DEFAULTS       {0x0,    \
                                     0x7fff, \
                                     0x07d0, \
                                     0x0 ,   \
                                     (int (*)(int))F2407_BLDC_PWM_Init,      \
                                     (int (*)(int))F2407_BLDC_PWM_Update     \
                                    }

#define PWMGEN_DEFAULTS F2407_PWMGEN_DEFAULTS

/*------------------------------------------------------------------------------
 Prototypes for the functions in F2407BLDCPWM1.C , F2407BLDCPWM2.ASM
------------------------------------------------------------------------------*/

int F2407_BLDC_PWM_Init(PWMGEN_handle);
int F2407_BLDC_PWM_Update(PWMGEN_handle);


#endif     /* __F2407_BLDCPWM_H__ */




