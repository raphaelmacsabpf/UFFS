/* =====================================================================================================================
File name:        CAPTURE.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description:
Front end header file for the PWM Generation Units.
This header file includes the correct header file for the 
target defined by the target header file.
       
Choices currently accepted are F243 F2407.
     
Depending on this choice the correct header file is included in by this file.                                   
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
----------------------------------------------------------------------------------- */
        
#ifndef __CAPTURE_H__
#define __CAPTURE_H__  
#include <TARGET.H>


#if  (TARGET == F240 ) 
#error Implementation not ported to the F240

#elif  ( TARGET == F243 ) 
#include <F243_CAP.H>    

#elif  ( TARGET == F2407 )
#include <F2407CAP.H>            

#endif /* TARGET == F2407 */

#ifdef TARGET
#if  ((TARGET!=F240)&(TARGET!=F243)&(TARGET!=F2407))
#error CAPTURE.H: Unsupported Target !
#endif 
#endif


        
        
#endif  /* __CAPTURE_H__ */

  




