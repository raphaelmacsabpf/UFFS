; ==================================================================================
; File name:        x240x.h                     
;                    
; Originator:	Digital Control Systems Group
;			Texas Instruments
;
; Description:   
; X240x Peripheral Registers + other useful definitions
; =====================================================================================
; History:
; -------------------------------------------------------------------------------------
;  9-15-2000	Release	Rev 1.0                                                  
; ------------------------------------------------------------------------------------

; 24xx core registers
IMR			.set 0004h	; Interrupt Mask Register
GREG    	.set 0005h  ; Global memory allocation Register
IFR			.set 0006h	; Interrupt Flag Register

; System configuration and interrupt registers
PIRQR0		.set 7010h	; Periph Interrupt Request Reg 0.
PIRQR1		.set 7011h	; Periph Interrupt Request Reg 1. 
PIRQR2		.set 7012h	; Periph Interrupt Request Reg 2. 
PIACKR0		.set 7014h	; Periph Interrupt Acknowledge Reg 0.
PIACKR1		.set 7015h	; Periph Interrupt Acknowledge Reg 1.
PIACKR2		.set 7016h	; Periph Interrupt Acknowledge Reg 2.
SCSR1		.set 7018h	; System Control &  Status Reg. 1  (x240x only)
SSCR        .set 7018h  ; System Status & Control reg (x241/2/3 only)
SCSR        .set 7018h  ; System Status & Control reg (x241/2/3 only)
SYSCR		.set 7018h  ; System Control (x240 only)	
SCSR2		.set 7019h	; System Control &  Status Reg. 2  (x240x only)
SYSSR       .set 701Ah  ; System Status (x240 only)
DINR		.set 701Ch	; Device Identification Register.
DIN     	.set 701Ch 	; Device Identification Register
PIVR		.set 701Eh	; Peripheral Interrupt Vector Reg.
SYSIVR      .set 701Eh 	; System Int Vector (x240 only) 

;Watch-Dog(WD) / Real Time Int(RTI) / Phase Lock Loop(PLL) Registers
RTI_CNTR    .set 7021h  ; RTI Counter reg
RTICNTR     .set 7021h  ; RTI Counter reg (x240 only)
WD_CNTR     .set 7023h  ; WD Counter reg
WDCNTR		.set 7023h	; WD Counter reg
WD_KEY  	.set 7025h  ; WD Key reg
WDKEY       .set 7025h  ; WD Key reg
RTI_CNTL    .set 7027h  ; RTI Control reg
RTICR     	.set 7027h  ; RTI Control reg (x240 only)
WD_CNTL     .set 7029h  ; WD Control reg
WDCR        .set 7029h  ; WD Control reg
CKCR0       .set 702Ah  ; PLL Clock Control 0 (X240 only)
PLL_CNTL1   .set 702Bh  ; PLL control reg 1
CKCR1       .set 702Ch  ; PLL Clock Control 1 (X240 only)
PLL_CNTL2   .set 702Dh  ; PLL control reg 2

; SPI registers
SPICCR		.set 7040h	; SPI Config Control Reg
SPI_CCR     .set 7040h  ; SPI Config Control Reg 1
SPICTL		.set 7041h	; SPI Operation Control Reg
SPI_CTL     .set 7041h  ; SPI Operation Control Reg 2
SPISTS		.set 7042h	; SPI Status Reg
SPI_STS     .set 7042h  ; SPI Status Reg
SPIBRR		.set 7044h	; SPI Baud rate control reg
SPI_BRR     .set 7044h  ; SPI Baud rate control reg
SPIRXEMU	.set 7046h	; SPI Emulation buffer reg
SPI_EMU     .set 7046h  ; SPI Emulation buffer reg
SPIRXBUF	.set 7047h	; SPI Serial receive buffer reg
SPI_BUF     .set 7047h  ; SPI Serial Input buffer reg
SPITXBUF	.set 7048h	; SPI Serial transmit buffer reg
SPIDAT		.set 7049h	; SPI Serial data reg
SPI_DAT     .set 7049h  ; SPI Serial Data reg
SPIPC1      .set 704Dh  ; SPI Port control reg1
SPI_PC1     .set 704Dh  ; SPI Port control reg1
SPIPC2      .set 704Eh  ; SPI Port control reg2
SPI_PC2     .set 704Eh  ; SPI Port control reg2
SPIPRI		.set 704Fh	; SPI Priority control reg
SPI_PRI     .set 704Fh  ; SPI Priority control reg


; SCI registers
SCICCR		.set 7050h	; SCI Communication control reg
SCI_CCNTL   .set 7050h  ; SCI Comms Control Reg
SCICTL1		.set 7051h	; SCI Control reg1
SCI_CNTL1   .set 7051h  ; SCI Control Reg 1
SCIHBAUD	.set 7052h	; SCI Baud Rate MSbyte reg
SCI_HBAUD   .set 7052h  ; SCI Baud rate control
SCILBAUD	.set 7053h	; SCI Baud Rate LSbyte reg
SCI_LBAUD   .set 7053h  ; SCI Baud rate control
SCICTL2		.set 7054h	; SCI Control reg2
SCI_CNTL2   .set 7054h  ; SCI Control Reg 2
SCIRXST		.set 7055h	; SCI Receiver Status reg
SCI_RX_STAT .set 7055h  ; SCI Receive status reg
SCIRXEMU	.set 7056h	; SCI Emulation Data Buffer reg
SCI_RX_EMU  .set 7056h  ; SCI EMU data buffer
SCIRXBUF	.set 7057h	; SCI Receiver Data buffer reg
SCI_RX_BUF  .set 7057h  ; SCI Receive data buffer
SCITXBUF	.set 7059h	; SCI Transmit Data buffer reg
SCI_TX_BUF  .set 7059h  ; SCI Transmit data buffer
SCI_PORT_C1 .set 705Dh  ; SCI Port control reg1
SCI_PORT_C2 .set 705Eh  ; SCI Port control reg2
SCIPC2 		.set 705Eh  ; SCI Port control reg2 (x240 only)
SCI_PRI     .set 705Fh  ; SCI Priority control reg
SCIPRI		.set 705Fh	; SCI Priority control reg


; External interrupt configuration registers
XINT1CR240  .set 7070h  ; Int1 (type A) config (X240 only)
XINT1CR		.set 7070h	; Ext. interrupt 1 config reg for X241/2/3 only.
XINT1_CNTL  .set 7070h  ; Int1 (type A) Control reg
XINT2CR		.set 7071h	; External interrupt 2 config. X241/2/3 only.
XINT2CR241	.set 7071h	; External interrupt 2 config. X241/2/3 only.
NMICR       .set 7072h  ; NMI (type A) config (X240 only)
NMI_CNTL    .set 7072h  ; Non maskable Int (type A) Control reg
XINT2CR240  .set 7078h  ; Int2 (type C) config (X240 only)
XINT2_CNTL  .set 7078h  ; Int2 (type C) Control reg
XINT3CR240  .set 707Ah  ; Int3 (type C) config (X240 only)
XINT3_CNTL  .set 707Ah  ; Int3 (type C) Control reg
XINT3CR		.set 707Ah	; Ext. interrupt 1 config reg for X240 only.

; Digital I/O registers
MCRA		.set 7090h	; Output Control Reg A
OCRA        .set 7090h  ; Output Control A
MCRB		.set 7092h	; Output Control Reg B
OCRB        .set 7092h  ; Output Control B
MCRC		.set 7094h	; Output Control Reg C
OCRC        .set 7094h  ; Output control C (X240x only)
ISRA        .set 7094h  ; Input Status A (X240 only)
IPSRA       .set 7094h  ; Input Status Reg A
ISRB        .set 7096h  ; Input Status B (X240 only)
IPSRB       .set 7096h  ; Input Status Reg B
PADATDIR	.set 7098h	; I/O port A Data & Direction reg.
PBDATDIR	.set 709Ah	; I/O port B Data & Direction reg.
PCDATDIR	.set 709Ch	; I/O port C Data & Direction reg.
PDDATDIR	.set 709Eh	; I/O port D Data & Direction reg.
PEDATDIR	.set 7095h	; I/O port E Data & Direction reg.
PFDATDIR	.set 7096h	; I/O port F Data & Direction reg.

; Analog-to-Digital Converter(ADC) registers - x240x
ADCTRL1		.set 70A0h	; ADC Control Reg1
ADCL_CNTL1  .set 70A0h  ; ADC Control reg 1
ADCTRL2		.set 70A1h	; ADC Control Reg2
ADCL_CNTL2  .set 70A1h  ; ADC Control reg 2
MAXCONV		.set 70A2h	; Maximum conversion channels register
CHSELSEQ1	.set 70A3h	; Channel select Sequencing control register 1
CHSELSEQ2	.set 70A4h	; Channel select Sequencing control register 2
CHSELSEQ3	.set 70A5h	; Channel select Sequencing control register 3
CHSELSEQ4	.set 70A6h	; Channel select Sequencing control register 4
AUTO_SEQ_SR	.set 70A7h	; Auto-sequence status register
RESULT0		.set 70A8h	; Conversion result buffer register 0	
ADC_RESULT0	.set 70A8h	; Conversion result buffer register 0
RESULT1		.set 70A9h	; Conversion result buffer register 1	
ADC_RESULT1	.set 70A9h	; Conversion result buffer register 1
RESULT2		.set 70AAh	; Conversion result buffer register 2	
ADC_RESULT2	.set 70AAh	; Conversion result buffer register 2
RESULT3		.set 70ABh	; Conversion result buffer register 3	
ADC_RESULT3	.set 70ABh	; Conversion result buffer register 3
RESULT4		.set 70ACh	; Conversion result buffer register 4	
ADC_RESULT4	.set 70ACh	; Conversion result buffer register 4
RESULT5		.set 70ADh	; Conversion result buffer register 5	
ADC_RESULT5	.set 70ADh	; Conversion result buffer register 5
RESULT6		.set 70AEh	; Conversion result buffer register 6	
ADC_RESULT6	.set 70AEh	; Conversion result buffer register 6
RESULT7		.set 70AFh	; Conversion result buffer register 7	
ADC_RESULT7	.set 70AFh	; Conversion result buffer register 7
RESULT8		.set 70B0h	; Conversion result buffer register 8	
ADC_RESULT8	.set 70B0h	; Conversion result buffer register 8
RESULT9		.set 70B1h	; Conversion result buffer register 9	
RESULT10	.set 70B2h	; Conversion result buffer register 10	
ADC_RESULT10 .set 70B2h	; Conversion result buffer register 10
RESULT11	 .set 70B3h	; Conversion result buffer register 11
ADC_RESULT11 .set 70B3h	; Conversion result buffer register 11
RESULT12	 .set 70B4h	; Conversion result buffer register 12
ADC_RESULT12 .set 70B4h	; Conversion result buffer register 12
RESULT13	 .set 70B5h	; Conversion result buffer register 13
ADC_RESULT13 .set 70B5h	; Conversion result buffer register 13
RESULT14	 .set 70B6h	; Conversion result buffer register 14
ADC_RESULT14 .set 70B6h	; Conversion result buffer register 14
RESULT15	 .set 70B7h	; Conversion result buffer register 15
ADC_RESULT15 .set 70B7h	; Conversion result buffer register 15
CALIBRATION	 .set 70B8h	; Calib result, used to correct subsequent conversions

; CAN(SCC) registers. 
CANMDER		.set 7100h	; CAN Mailbox Direction/Enable reg
CANTCR		.set 7101h	; CAN Transmission Control Reg
CANRCR		.set 7102h	; CAN Recieve COntrol Reg
CANMCR		.set 7103h	; CAN Master Control Reg
CANBCR2		.set 7104h	; CAN Bit COnfig Reg 2
CANBCR1		.set 7105h	; CAN Bit Config Reg 1
CANESR		.set 7106h	; CAN Error Status Reg
CANGSR		.set 7107h	; CAN Global Status Reg
CANCEC		.set 7108h	; CAN Trans and Rcv Err counters
CANIFR		.set 7109h	; CAN Interrupt Flag Registers 
CANIMR		.set 710Ah	; CAN Interrupt Mask Registers
CANLAM0H	.set 710Bh	; CAN Local Acceptance Mask MBx0/1
CANLAM0L	.set 710Ch	; CAN Local Acceptance Mask MBx0/1
CANLAM1H	.set 710Dh	; CAN Local Acceptance Mask MBx2/3
CANLAM1L	.set 710Eh	; CAN Local Acceptance Mask MBx2/3

CANMSGID0L	.set 7200h	; CAN Message ID for mailbox 0 (lower 16 bits)	
CANMSGID0H	.set 7201h	; CAN Message ID for mailbox 0 (upper 16 bits)	
CANMSGCTRL0	.set 7202h	; CAN RTR and DLC	
CANMBX0A	.set 7204h	; CAN 2 of 8 bytes of Mailbox 0	
CANMBX0B	.set 7205h	; CAN 2 of 8 bytes of Mailbox 0	
CANMBX0C	.set 7206h	; CAN 2 of 8 bytes of Mailbox 0	
CANMBX0D	.set 7207h	; CAN 2 of 8 bytes of Mailbox 0	
CANMSGID1L	.set 7208h	; CAN Message ID for mailbox 1 (lower 16 bits)	
CANMSGID1H	.set 7209h	; CAN Message ID for mailbox 1 (upper 16 bits)	
CANMSGCTRL1	.set 720Ah	; CAN RTR and DLC	
CANMBX1A	.set 720Ch	; CAN 2 of 8 bytes of Mailbox 1	
CANMBX1B	.set 720Dh	; CAN 2 of 8 bytes of Mailbox 1	
CANMBX1C	.set 720Eh	; CAN 2 of 8 bytes of Mailbox 1	
CANMBX1D	.set 720Fh	; CAN 2 of 8 bytes of Mailbox 1	
CANMSGID2L	.set 7210h	; CAN Message ID for mailbox 2 (lower 16 bits)	
CANMSGID2H	.set 7211h	; CAN Message ID for mailbox 2 (upper 16 bits)	
CANMSGCTRL2	.set 7212h	; CAN RTR and DLC	
CANMBX2A	.set 7214h	; CAN 2 of 8 bytes of Mailbox 2	
CANMBX2B	.set 7215h	; CAN 2 of 8 bytes of Mailbox 2	
CANMBX2C	.set 7216h	; CAN 2 of 8 bytes of Mailbox 2	
CANMBX2D	.set 7217h	; CAN 2 of 8 bytes of Mailbox 2	
CANMSGID3L	.set 7218h	; CAN Message ID for mailbox 3 (lower 16 bits)	
CANMSGID3H	.set 7219h	; CAN Message ID for mailbox 3 (upper 16 bits)	
CANMSGCTRL3	.set 721Ah	; CAN RTR and DLC	
CANMBX3A	.set 721Ch	; CAN 2 of 8 bytes of Mailbox 3	
CANMBX3B	.set 721Dh	; CAN 2 of 8 bytes of Mailbox 3	
CANMBX3C	.set 721Eh	; CAN 2 of 8 bytes of Mailbox 3	
CANMBX3D	.set 721Fh	; CAN 2 of 8 bytes of Mailbox 3	
CANMSGID4L	.set 7220h	; CAN Message ID for mailbox 4 (lower 16 bits)	
CANMSGID4H	.set 7221h	; CAN Message ID for mailbox 4 (upper 16 bits)	
CANMSGCTRL4	.set 7222h	; CAN RTR and DLC	
CANMBX4A	.set 7224h	; CAN 2 of 8 bytes of Mailbox 4	
CANMBX4B	.set 7225h	; CAN 2 of 8 bytes of Mailbox 4	
CANMBX4C	.set 7226h	; CAN 2 of 8 bytes of Mailbox 4	
CANMBX4D	.set 7227h	; CAN 2 of 8 bytes of Mailbox 4	
CANMSGID5L	.set 7228h	; CAN Message ID for mailbox 5 (lower 16 bits)	
CANMSGID5H	.set 7229h	; CAN Message ID for mailbox 5 (upper 16 bits)	
CANMSGCTRL5	.set 722Ah	; CAN RTR and DLC	
CANMBX5A	.set 722Ch	; CAN 2 of 8 bytes of Mailbox 5	
CANMBX5B	.set 722Dh	; CAN 2 of 8 bytes of Mailbox 5	
CANMBX5C	.set 722Eh	; CAN 2 of 8 bytes of Mailbox 5	

; Event Manager A  (EVA) registers 
GPTCONA		.set 7400h	; GP Timer control register A . 
GPTCON  	.set 7400h  ; General Timer Control
T1CNT		.set 7401h	; GP Timer 1 counter register. 
T1CMPR		.set 7402h	; GP Timer 1 compare register. 
T1CMP       .set 7402h  ; T1 Compare Value
T1PR		.set 7403h	; GP Timer 1 period register. 
T1PER       .set 7403h  ; T1 Period
T1CON		.set 7404h	; GP Timer 1 control register. 
T2CNT		.set 7405h	; GP Timer 2 counter register. 
T2CMPR		.set 7406h	; GP Timer 2 compare register. 
T2CMP       .set 7406h  ; T2 Compare Value
T2PR		.set 7407h	; GP Timer 2 period register. 
T2PER       .set 7407h  ; T2 Period
T2CON		.set 7408h	; GP Timer 2 control register. 

COMCONA		.set 7411h	; Compare control register A.
COMCON      .set 7411h  ; Compare Control
ACTRA		.set 7413h	; Full compare action control register A.
ACTR        .set 7413h  ; Compare Output Action Control (240 Only)
SACTR       .set 7414h  ; S Comp Output Action Control (240 Only)
DBTCONA		.set 7415h	; Dead-band timer control register A. 
DBTCON      .set 7415h  ; Dead Band Control

CMPR1		.set 7417h	; Full compare unit compare register1 A. 
CMPR2		.set 7418h	; Full compare unit compare register2 A.
CMPR3		.set 7419h	; Full compare unit compare register3 A.

SCMPR1  	.set 741Ah  ; S Comp Value 1 (240 Only)
SCMPR2  	.set 741Bh  ; S Comp Value 2 (240 Only)
SCMPR3  	.set 741Ch  ; S Comp Value 3 (240 Only)


CAPCONA		.set 7420h	; Capture control register A. 
CAPCON  	.set 7420h  ; Capture Control
CAPFIFOA 	.set 7422h	; Capture FIFO status register A. 
CAPFIFO     .set 7422h  ; Capture FIFO1-3/4 Status
			
CAP1FIFO	.set 7423h	; Capture Channel 1 FIFO Top 
FIFO1       .set 7423h  ; Capture 1 FIFO Top
CAP2FIFO	.set 7424h	; Capture Channel 2 FIFO Top 
FIFO2       .set 7424h  ; Capture 2 FIFO Top
CAP3FIFO	.set 7425h	; Capture Channel 3 FIFO Top 
FIFO3       .set 7425h  ; Capture 3 FIFO Top
FIFO4       .set 7426h  ; Capture 4 FIFO Top (240 Only)

CAP1FBOT	.set 7427h	; Bottom reg. pf capture FIFO stack 1 A
FIFOBT1 	.set 7427h  ; Capture 1 FIFO Bottom (240x only)
CAP2FBOT	.set 7428h	; Bottom reg. pf capture FIFO stack 2 A
FIFOBT2 	.set 7428h  ; Capture 2 FIFO Bottom (240x only)
CAP3FBOT	.set 7429h	; Bottom reg. pf capture FIFO stack 3 A
FIFOBT3     .set 7429h  ; Capture 3 FIFO Bottom (240x only)

EVAIMRA		.set 742Ch	; Group A Interrupt Mask Register A
EVIMRA  	.set 742Ch  ; Group A Int Mask
IMRA        .set 742Ch  ; Group A Int Mask
EVAIMRB		.set 742Dh	; Group B Interrupt Mask Register A
EVIMRB  	.set 742Dh  ; Group B Int Mask
IMRB        .set 742Dh  ; Group B Int Mask
EVAIMRC		.set 742Eh	; Group C Interrupt Mask Register A
EVIMRC  	.set 742Eh  ; Group C Int Mask
IMRC        .set 742Eh  ; Group C Int Mask

EVAIFRA		.set 742Fh	; Group A Interrupt Flag Register A
EVIFRA  	.set 742Fh  ; Group A Int Flag
IFRA        .set 742Fh  ; Group A Int Flag
EVAIFRB		.set 7430h	; Group B Interrupt Flag Register A
EVIFRB  	.set 7430h  ; Group B Int Flag
IFRB        .set 7430h  ; Group B Int Flag
EVAIFRC		.set 7431h	; Group C Interrupt Flag Register A
EVIFRC  	.set 7431h  ; Group C Int Flag
IFRC        .set 7431h  ; Group C Int Flag

EVIVRA  	.set 7432h  ; Group A Int ID (x240 only)
IVRA        .set 7432h  ; Group A Int ID (x240 only)
EVIVRB  	.set 7433h  ; Group B Int ID (x240 only)
IVRB        .set 7433h  ; Group B Int ID (x240 only)
EVIVRC  	.set 7434h  ; Group C Int ID (x240 only)
IVRC        .set 7434h  ; Group C Int ID (x240 only)

; Event Manager B (EVB) Registers (240x Only) 
GPTCONB		.set 7500h	; GP Timer control register B . 
T3CNT		.set 7501h	; GP Timer 3 counter register. 
T3CNTB  	.set 7501h  ; T1 Counter
T3CMPR		.set 7502h	; GP Timer 3 compare register. 
T3CMPB  	.set 7502h  ; T1 Comp Value
T3PR		.set 7503h	; GP Timer 3 period register. 
T3PERB  	.set 7503h  ; T1 Period
T3CON		.set 7504h	; GP Timer 3 control register. 
T3CONB  	.set 7504h  ; T1 Control
T4CNT		.set 7505h	; GP Timer 4 counter register. 
T4CNTB  	.set 7505h  ; T2 Counter
T4CMPR		.set 7506h	; GP Timer 4 compare register. 
T4CMPB  	.set 7506h  ; T2 Comp Value
T4PR		.set 7507h	; GP Timer 4 period register. 
T4PERB  	.set 7507h  ; T2 Period
T4CON		.set 7508h	; GP Timer 4 control register. 
T4CONB  	.set 7508h  ; T2 Control

COMCONB		.set 7511h	; Compare control register B.
ACTRB		.set 7513h	; Full compare action control register B.
DBTCONB		.set 7515h	; Dead-band timer control register B. 

CMPR4		.set 7517h	; Full compare unit compare register1 B. 
CMPR4B  	.set 7517h  ; Comp Value 4
CMPR5		.set 7518h	; Full compare unit compare register2 B.
CMPR5B  	.set 7518h  ; Comp Value 5
CMPR6		.set 7519h	; Full compare unit compare register3 B.
CMPR6B  	.set 7519h  ; Comp Value 6

CAPCONB		.set 7520h	; Capture control register B. 
CAPFIFOB 	.set 7522h	; Capture FIFO status register B. 
			
CAP4FIFO	.set 7523h	; Capture Channel 1 FIFO Top B
FIFO4B  	.set 7523h  ; Capture 4 FIFO Top
CAP5FIFO	.set 7524h	; Capture Channel 2 FIFO Top B
FIFO5B  	.set 7524h  ; Capture 5 FIFO Top
CAP6FIFO	.set 7525h	; Capture Channel 3 FIFO Top B
FIFO6B  	.set 7525h  ; Capture 6 FIFO Top

CAP4FBOT	.set 7527h	; Bottom reg. pf capture FIFO stack 1 B
FIFOBT4B    .set 7527h  ; Capture 4 FIFO Bottom
CAP5FBOT	.set 7528h	; Bottom reg. pf capture FIFO stack 2 B
FIFOBT5B    .set 7528h  ; Capture 5 FIFO Bottom
CAP6FBOT	.set 7529h	; Bottom reg. pf capture FIFO stack 3 B
FIFOBT6B    .set 7529h  ; Capture 6 FIFO Bottom

EVBIMRA		.set 752Ch	; Group A Interrupt Mask Register B
IMRAB       .set 752Ch  ; Group A Int Mask
EVBIMRB		.set 752Dh	; Group B Interrupt Mask Register B
IMRBB       .set 752Dh  ; Group B Int Mask
EVBIMRC		.set 752Eh	; Group C Interrupt Mask Register B
IMRCB       .set 752Eh  ; Group C Int Mask

EVBIFRA		.set 752Fh	; Group A Interrupt Flag Register B
IFRAB       .set 752Fh  ; Group A Int Flag
EVBIFRB		.set 7530h	; Group B Interrupt Flag Register B
IFRBB       .set 7530h  ; Group B Int Flag
EVBIFRC		.set 7531h	; Group C Interrupt Flag Register B
IFRCB       .set 7531h  ; Group C Int Flag

;-------------------------------------------------------------
; I/O space mapped registers
;-------------------------------------------------------------
WSGR		.set 0FFFFh	; Wait-State Generator Control Reg
FCMR		.set 0FF0Fh	; Flash control mode register

;-----------------------------------------------------------------------------
; Constant defines
;-----------------------------------------------------------------------------
B0_SADDR    .set  0200h ; Block B0 start address
B0_EADDR    .set  02FFh ; Block B0 end address
B1_SADDR    .set  0300h ; Block B1 start address
B1_EADDR    .set  03FFh ; Block B1 end address
B2_SADDR    .set  0060h ; Block B2 start address
B2_EADDR    .set  007Fh ; Block B2 end address

;External Data Space Registers
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXTDATA 	.set  8000h

;--------------------------------------------------------------
; Bit codes for Test bit instruction (BIT) (15 Loads bit 0 into TC)
;-------------------------------------------------------------
BIT15		.set 0000h	; Bit Code for 15
BIT14		.set 0001h	; Bit Code for 14
BIT13		.set 0002h	; Bit Code for 13
BIT12		.set 0003h	; Bit Code for 12
BIT11		.set 0004h	; Bit Code for 11
BIT10		.set 0005h	; Bit Code for 10
BIT9		.set 0006h	; Bit Code for 9
BIT8		.set 0007h	; Bit Code for 8
BIT7		.set 0008h	; Bit Code for 7
BIT6		.set 0009h	; Bit Code for 6
BIT5		.set 000Ah	; Bit Code for 5
BIT4		.set 000Bh	; Bit Code for 4
BIT3		.set 000Ch	; Bit Code for 3
BIT2		.set 000Dh	; Bit Code for 2
BIT1		.set 000Eh	; Bit Code for 1
BIT0		.set 000Fh	; Bit Code for 0

;--------------------------------------------------------------------------
;Test mode on and off constants
;--------------------------------------------------------------------------
ABRPT   	.set 001fh  ; Analysis BreakPoint Register
PSA_ON	   	.set 03A1h	; Turn PSA and FEEDB on
PSA_FB_OFF 	.set 0121h  ; Turn PSA and FEEDB off

wd_rst_1    .set 0055h  ; watchdog timer reset string
wd_rst_2    .set 00AAh  ; watchdog timer reset string

