/* ==================================================================================
File name:       F24xWDOG.c
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains the source for the Watchdog drivers.     
For the function prototypes include the file watchdog.h in your build. 
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F24x_WD_ResetCounter |       Y   |  Y  |  Y   |   Y    |   Y    |   Y      */
/* F24x_WD_Disable      |       Y   |  Y  |  Y   |   Y    |   Y    |   Y      */
/*                      |           |     |      |        |        |          */
/*                      |           |     |      |        |        |          */
/*                      |           |     |      |        |        |          */
/*                      |           |     |      |        |        |          */
/*                      |           |     |      |        |        |          */
/*----------------------------------------------------------------------------*/

#include "..\include\regs24x.h"


void F24x_WD_ResetCounter(void)
{
        WDKEY=0x5555;                  /* Reset WDog   */
        WDKEY=0xaaaa;
}

void F24x_WD_Disable(void)
{
        WDCR=0x006f;                /* Write Control Register to Disable Watchdog */
}

