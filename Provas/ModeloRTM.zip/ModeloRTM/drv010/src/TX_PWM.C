/* ==================================================================================
File name:        TX_PWM.H                     
                    
Autor:	Sidelmo Magalh�es Silva

Descri��o:  

Header file containing data type and object definitions and 
initializers. Also contains prototypes for the functions in TX_PWM.C.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 29-04-2003	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */
/*
//typedef struct { int period_max;        /* PWM Period in CPU clock cycles.  Q0-Input  
//                 int mfunc_c;           /* PWM Duty cycle ratio. Q15, Input       
//                 int (*init)();         /* Pointer to the init function             
//                 int (*update)();       /* Pointer to the update function           
//               } TXPWMGEN ;    
//
*/

#include "..\include\regs240x.h" 
#include "..\include\TX_PWM.H"




int T1_PWM_init(TXPWMGEN *p) 
{       
        SCSR1 |= 0x0004;                       /* Turn EVA Clocks on            */
        T1PR = p->period_max;                  /* Init Timer 1 period Register  */
        T1CON  = TXPWM_INIT_STATE;             /* Asymmetrical Operation         */
        
        GPTCONA |= GPTCONA_T1_INIT_STATE;                

        T1CMPR = p->period_max;
        
        MCRA = MCRA | 0x1000;                /* Set up the T1PWM pin to primary functions.*/

        return(0);

}

int T2_PWM_init(TXPWMGEN *p) 
{       
        SCSR1 |= 0x0004;                       /* Turn EVA Clocks on            */
        T2PR = p->period_max;                  /* Init Timer 1 period Register  */
        T2CON  = TXPWM_INIT_STATE;             /* Asymmetrical Operation         */
        
        GPTCONA |= GPTCONA_T2_INIT_STATE;                

        T1CMPR = p->period_max;
        
        MCRA = MCRA | 0x2000;                /* Set up the T2PWM pin to primary functions.*/

        return(0);

}

int T3_PWM_init(TXPWMGEN *p) 
{       
        SCSR1 |= 0x0008;                       /* Turn EVB Clocks on            */
        T3PR = p->period_max;                  /* Init Timer 3 period Register  */
        T3CON  = TXPWM_INIT_STATE;             /* Asymmetrical Operation         */
        
        GPTCONB |= GPTCONB_T3_INIT_STATE;                

        T3CMPR = p->period_max;
                
        MCRC = MCRC | 0x0400;                /* Set up the T3PWM pin to primary functions.*/

        return(0);

}

int T4_PWM_init(TXPWMGEN *p) 
{       
        SCSR1 |= 0x0008;                       /* Turn EVB Clocks on            */
        T4PR = p->period_max;                  /* Init Timer 4 period Register  */
        T4CON  = TXPWM_INIT_STATE;             /* Asymmetrical Operation         */
        
        GPTCONB |= GPTCONB_T4_INIT_STATE;                

        T4CMPR = p->period_max;
        
        MCRC = MCRC | 0x0800;                /* Set up the T4PWM pin to primary functions.*/

        return(0);

}

/*====================================================================================*/
/*====================================================================================*/


int T1_PWM_update(TXPWMGEN *p) 
{       
        T1CMPR = p->mfunc_c;
        return(0);
} 

int T2_PWM_update(TXPWMGEN *p) 
{       
        T2CMPR = p->mfunc_c;
        return(0);
}


int T3_PWM_update(TXPWMGEN *p) 
{       
        T3CMPR = p->mfunc_c;
        return(0);
} 

int T4_PWM_update(TXPWMGEN *p) 
{       
        T4CMPR = p->mfunc_c;
        return(0);
}

