/* ==================================================================================
File name:       F243ADC1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the ADC driver initialization for the F243.
Applicability of these functions is indicated in the Table 1                  
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*================================================================================  */
/*                           T A B L E      1                                       */
/*================================================================================  */
/*     Function Name    |    Applicability                                          */
/*================================================================================  */
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407         */
/*                      |           |     |      |        |        |                */
/* F243_ADC_Init        |        Y  |  Y  |  Y   |        |        |                */
/*================================================================================  */
/*================================================================================  */
/* Routine Name: ADC Init Routine        Routine Type: C Callable                   */
/*                                                                                  */
/* Description:                                                                     */
/* C prototype : void F243_ADC_Init(ADCVALS *p)  Though the structure members       */
/* are not used in the code for consistency structure pointer is passed.            */
/* History  created July 27,2000                                                    */
/*================================================================================  */

#include "..\include\regs24x.h"
#include "..\include\F243_ADC.h"
#include "..\include\override.h"


void inline F243_ADC_Init(ADCVALS *p)
{
        ADCTRL2=ADCTRL2_INIT_STATE;
        ADCTRL1=ADCTRL1_INIT_STATE;
        ADCTRL1=ADCTRL1+((p->a4_ch_sel)&ADC2CHSEL_7)+(((p->a4_ch_sel)<<1)&ADC1CHSEL_7);

}            

