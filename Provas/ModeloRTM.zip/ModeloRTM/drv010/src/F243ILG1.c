/* ==================================================================================
File name:       F243ILG1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the Two leg current measurement on the 'F243'.
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F243_leg2_drv_init   |           |  Y  |  Y   |        |        |          */
/*----------------------------------------------------------------------------*/
/*
// typedef struct {      int gain_a,
//                       int offset_a,
//                       int out_a,
//                       int gain_b,
//                       int offset_b,
//                       int out_b,
//                       int ch_a,
//                       int ch_b,
//                       int (*init)(),
//                       int (*read)(); 
//               } ILEG2MEAS ;
*/

#include "..\include\regs24x.h"
#include "..\include\F243ILG.h"
#include "..\include\override.h"

void inline F243_leg2_drv_init(ILEG2MEAS *p)
{
        GPTCON=((GPTCON&0xfcff)|0x80);
        ADCTRL2=ADCTRL2_INIT_STATE;
        ADCTRL1=ADCTRL1_INIT_STATE+(((p->ch_b)<<4)&ADC2CHSEL_7)+(((p->ch_a)<<1)&ADC1CHSEL_7);
}            

