/* ==================================================================================
File name:        ADC_8CH1.C                     
                    
Autor: Sidelmo Magalh�es Silva

Descri��o: 

Impelmenta o a fun��o de inicializa��o para a classe ADC8CH.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 28-04-2003	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#include "..\include\regs240x.h"
#include "..\include\ADC_8CH.H"
#include "..\include\override.h"


void inline ADC_8CH_Init(ADC8CH *p)
{

        SCSR1 = SCSR1 | 0x0080;                 /* Turn on the clocks to the ADC module*/
        
        CALIBRATION = CALIBRATION_CONSTANT;
      
        ADCTRL1 = ADC_RESET_FLAG;             /* Reset the ADC Module    */
        ADCTRL1 = ADCTRL1_INIT_STATE;         /* Set up ADCTRL1 register */
      	ADCTRL2 = ADCTRL2_INIT_STATE;         /* Set up ADCTRL2 register */
        MAXCONV = 7;                          /* Specify eight conversions  */

        CHSELSEQ1 = p->ch_sel_1_4;       	   /* Configure channel selection */ 
        CHSELSEQ2 = p->ch_sel_5_8;       	   /* Configure channel selection */ 
}            
       


