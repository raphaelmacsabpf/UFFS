/* ==================================================================================
File name:       ADC_16CH.C
                    
Author: Sidelmo M. Silva	

Description:                                   

Description:  


This file source for ADC initialization and update.

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 09-03-2004	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */
/*
typedef struct { 
//				int PortA;					/* Variavel de Entrada: Valor dos Bits da portA 
//				int PortB;					/* Variavel de Entrada: Valor dos Bits da portB                   
//				int PortC;					/* Variavel de Entrada: Valor dos Bits da portC 
//				int PortD;					/* Variavel de Entrada: Valor dos Bits da portD 
//				int PortE;					/* Variavel de Entrada: Valor dos Bits da portE 
//				int (*init)();              /* Initialization func pointer  
//              int (*update)();            /* Update function              
//               } IOPORT;

=====================================================================================
*/

#include "..\include\regs240x.h"
#include "..\include\ADC_16CH.h"
#include "..\include\override.h"


void inline ADC_16CH_Init(ADC16CH *p)
{

        SCSR1 = SCSR1 | 0x0080;               /* Turn on the clocks to the ADC module*/
        CALIBRATION = CALIBRATION_CONSTANT;
      
        ADCTRL1 = ADC_RESET_FLAG;             /* Reset the ADC Module    */
        ADCTRL1 = ADCTRL1_INIT_STATE;         /* Set up ADCTRL1 register */
      	ADCTRL2 = ADCTRL2_INIT_STATE;         /* Set up ADCTRL2 register */
        MAXCONV = 15;                         /* Specify sixteen conversions  */

        CHSELSEQ1 = p->ch_sel_1;       	      /* Configure channel selection */ 
        CHSELSEQ2 = p->ch_sel_2;       	      /* Configure channel selection */ 
        CHSELSEQ3 = p->ch_sel_3;       	      /* Configure channel selection */ 
        CHSELSEQ4 = p->ch_sel_4;       	      /* Configure channel selection */ 
        
}            
       
void ADC_16CH_Update(ADC16CH *p)
{

   p->ch0  = RESULT0;
   p->ch1  = RESULT1;
   p->ch2  = RESULT2;
   p->ch3  = RESULT3;
   p->ch4  = RESULT4;
   p->ch5  = RESULT5;
   p->ch6  = RESULT6;
   p->ch7  = RESULT7;
   p->ch8  = RESULT8;
   p->ch9  = RESULT9;
   p->ch10 = RESULT10;
   p->ch11 = RESULT11;
   p->ch12 = RESULT12;
   p->ch13 = RESULT13;
   p->ch14 = RESULT14;
   p->ch15 = RESULT15;

   p->ch0   = p->ch0  - 0x7FFF;
   p->ch1   = p->ch1  - 0x7FFF;
   p->ch2   = p->ch2  - 0x7FFF;
   p->ch3   = p->ch3  - 0x7FFF;
   p->ch4   = p->ch4  - 0x7FFF;
   p->ch5   = p->ch5  - 0x7FFF;
   p->ch6   = p->ch6  - 0x7FFF;
   p->ch7   = p->ch7  - 0x7FFF;
   p->ch8   = p->ch8  - 0x7FFF;
   p->ch9   = p->ch9  - 0x7FFF;
   p->ch10  = p->ch10 - 0x7FFF;
   p->ch11  = p->ch11 - 0x7FFF;
   p->ch12  = p->ch12 - 0x7FFF;
   p->ch13  = p->ch13 - 0x7FFF;
   p->ch14  = p->ch14 - 0x7FFF;
   p->ch15  = p->ch15 - 0x7FFF;

   p->ch0   = p->ch0  - p->offset0;
   p->ch1   = p->ch1  - p->offset1;
   p->ch2   = p->ch2  - p->offset2;
   p->ch3   = p->ch3  - p->offset3;
   p->ch4   = p->ch4  - p->offset4;
   p->ch5   = p->ch5  - p->offset5;
   p->ch6   = p->ch6  - p->offset6;
   p->ch7   = p->ch7  - p->offset7;
   p->ch8   = p->ch8  - p->offset8;
   p->ch9   = p->ch9  - p->offset9;
   p->ch10  = p->ch10 - p->offset10;
   p->ch11  = p->ch11 - p->offset11;
   p->ch12  = p->ch12 - p->offset12;
   p->ch13  = p->ch13 - p->offset13;
   p->ch14  = p->ch14 - p->offset14;
   p->ch15  = p->ch15 - p->offset15;
 
/*                       Inicia a pr�xima conversao                            */      

   ADCTRL1 = ADCTRL1_INIT_STATE;         /* Set up ADCTRL1 register      */
   ADCTRL2 = ADCTRL2_INIT_STATE;         /* Set up ADCTRL2 register      */
   MAXCONV = 15;                         /* Specify sixteen conversions  */

   CHSELSEQ1 = p->ch_sel_1;       	      /* Configure channel selection */ 
   CHSELSEQ2 = p->ch_sel_2;       	      /* Configure channel selection */ 
   CHSELSEQ3 = p->ch_sel_3;       	      /* Configure channel selection */ 
   CHSELSEQ4 = p->ch_sel_4;       	      /* Configure channel selection */ 
   
}

