/* ==================================================================================
File name:       F2407ILG1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the Two leg current measurement on the F2407 
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F2407_leg2_drv_init  |           |     |      |    Y   |    Y   |    Y     */
/*----------------------------------------------------------------------------*/
/*
// typedef struct {      int gain_a,
//                       int offset_a,
//                       int out_a,
//                       int gain_b,
//                       int offset_b,
//                       int out_b,
//                       int ch_a,
//                       int ch_b,
//                       int (*init)(),
//                       int (*read)(); 
//               } ILEG2MEAS ;
*/

#include "..\include\regs240x.h"
#include "..\include\F2407ILG.h"
#include "..\include\override.h"
#include "..\include\F2407BMSK.H"


void inline F2407_leg2_drv_init(ILEG2MEAS *p)
{

        SCSR1=SCSR1|0x0080;                 /* Turn on the clocks to the ADC module*/
        CALIBRATION=CALIBRATION_CONSTANT;

        GPTCONA=((GPTCONA&0xfe7f)|0x0080);   /* Set up EV Trigger              */
        ADCTRL1=ADC_RESET_FLAG;             /* Reset the ADC Module           */
        ADCTRL1=ADCTRL1_INIT_STATE;         /* Set up ADCTRL1 and 2 registers */
        ADCTRL2=ADCTRL2_INIT_STATE;
        MAXCONV=1;                          /* Specify two conversions        */


        CHSELSEQ1=((p->ch_b)<<4)+(  p->ch_a ) ;

        



}            



