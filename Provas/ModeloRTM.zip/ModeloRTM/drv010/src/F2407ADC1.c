/* ==================================================================================
File name:       F2407ADC1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the ADC driver initialization                  
for the F2407.  
Applicability of these functions is indicated in the Table 1               		
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*================================================================================ */
/*                           T A B L E      1                                      */
/*================================================================================ */
/*     Function Name   |    Applicability                                          */
/*================================================================================ */
/*                     |      F240 | F241| F243 | LF2402 | LF2406 | LF2407         */
/*                     |           |     |      |        |        |                */
/* F2407_ADC_Init      |           |     |      |        |        |     Y          */
/*================================================================================ */
/*================================================================================ */
/* Routine Name: ADC Init Routine        Routine Type: C Callable                  */
/*                                                                                 */
/* Description:                                                                    */
/* C prototype : void F2407_ADC_Init(ADCVALS *p)  Though the structure members     */
/* are not used in the code for consistency structure pointer is passed.           */
/* History  created August 21,2000                                                 */
/*================================================================================ */

#include "..\include\regs240x.h"
#include "..\include\F2407ADC.h"
#include "..\include\override.h"


void inline F2407_ADC_Init(ADCVALS *p)
{

        SCSR1=SCSR1|0x0080;                 /* Turn on the clocks to the ADC module*/
        CALIBRATION=CALIBRATION_CONSTANT;
      
        ADCTRL1=ADC_RESET_FLAG;             /* Reset the ADC Module    */
        ADCTRL1=ADCTRL1_INIT_STATE;         /* Set up ADCTRL1 register */
      	ADCTRL2=ADCTRL2_INIT_STATE;         /* Set up ADCTRL2 register */
        MAXCONV=3;                          /* Specify four conversions  */

        CHSELSEQ1=p->a4_ch_sel;       	   /* Configure channel selection */ 
}            
       


