/* ==================================================================================
File name:       F243CAP1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the Capture Event Units on the TMS320F243
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F243_PWM_Init        |           |  Y  |  Y   |        |        |          */
/*----------------------------------------------------------------------------*/
#include "..\include\regs24x.h"
#include "..\include\F243_CAP.h"
#include "..\include\override.h"

/* Note that for the changes to constants in the header file to take effect,
   THIS file must be re-compiled, AND any libs updated with the new obj.
   However to just change the definitions of ACTR for example, it can be done 
   anywhere in 'c' or asm code.
   For example 
                ACTR=NEW_VALUE;

*/

void  F243_CAP_Init(CAPTURE_handle p)
{
         CAPCON=CAP_INIT_STATE;           /* Set up capture units */
        T2CON= TIMER_INIT_STATE;         /* Set up capture timer */
        T2PR=0x7fff;

        OCRA=OCRA|0x38;        /* Set up the capture pins to primary functions */

}    


int F243_CAP1_Read(CAPTURE_handle p)
{
        if((CAPFIFO&0x0100)!=0)
        {
        p->time_stamp=CAP1FIFO;
        return(0);
        } 
        else
        {
        return(1);
        }

}

