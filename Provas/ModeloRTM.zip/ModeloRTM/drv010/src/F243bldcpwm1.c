/* ==================================================================================
File name:       F243BLDCPWM1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the Full Compare PWM  driver initialization for the F243.                                                                     
Applicability of these functions is indicated in the Table 1                  
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*================================================================================   */
/*                           T A B L E      1                                        */
/*================================================================================   */
/*     Function Name    |    Applicability                                           */
/*================================================================================   */
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407          */
/*                      |           |     |      |        |        |                 */
/* F243_BLDC_PWM_Init   |        Y  |  Y  |  Y   |        |        |                 */
/*================================================================================   */
/*================================================================================   */
/* Routine Name: PWM Init Routine        Routine Type: C Callable                    */
/*                                                                                   */
/* Description:                                                                      */
/*                                                                                   */
/*                                                                                   */
/*  C prototype : int F243_BLDC_PWM_Init(PWMGEN *p) Though the structure members     */
/*  are not used in the code for consistency structure pointer is passed.            */
/*  History:  Created   July 28, 2000                                                */
/*================================================================================   */

#include "..\include\regs24x.h" 
#include "..\include\F243_BLDCPWM.h"
#include "..\include\override.h"


int F243_BLDC_PWM_Init(PWMGEN *p) 
{
        T1PR=p->period_max;                  /* Init Timer 1 period Register  */
        T1CON=PWM_INIT_STATE;                /* Init PWM Operation         */
    
        ACTR=0x0000;                
        GPTCON=0x0000;
        COMCON=0x8200;

        OCRA=OCRA|0x0fc0;                
        
        return(0);
}       
       
       