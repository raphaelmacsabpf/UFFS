/* ==================================================================================
File name:       miscsfns.c
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------------*/

#include "..\include\regs24x.h"
void inline disable_ints()
{
        asm("                setc        intm        ");        
}

void inline enable_ints()
{
        asm("                clrc        intm        ");
}
void enable_dmc1000(void)
{
/* Enable power on DMC_1000_EXPTL version */
/*  OCRA=OCRA&0xbfff;                           */
}

void enable_labdrive(void)
{
        PBDATDIR=((PBDATDIR|0x4000)&0xffbf);
        OCRB=OCRB&0xffdf;
        PCDATDIR=PCDATDIR|0x2020;
        PDDATDIR=(PDDATDIR|0x1000)&0xffef;

}

