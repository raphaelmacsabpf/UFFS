/* ==================================================================================
File name:       F243QEP1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the QEP Unit on the TMS320F243          
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F243_QEP_Init        |           |  Y  |  Y   |        |        |          */
/*----------------------------------------------------------------------------*/
#include "..\include\regs24x.h"
#include "..\include\F243_QEP.h"
#include "..\include\override.h"

/* Note that for the changes to constants in the header file to take effect,
   THIS file must be re-compiled, AND any libs updated with the new obj.
   However to just change the contents of ACTR for example, it can be done 
   anywhere in 'c' or asm code.
   For example 
        
        T2CON=NEW_VALUE;

*/

int inline F243_QEP_Init(QEP *p)
{
         CAPCON=CAP_INIT_STATE;           /* Set up capture units */
        T2CON= TIMER_INIT_STATE;         /* Set up capture timer */
        T2PR=0xffff;       
        EVIFRC=0xffff;                         /* Clear all IFRC flags */
        EVIMRC=0x4;                         /* Enable CAP3 Interrupt */
        OCRA=OCRA|0x38;        /* Set up the capture pins to primary functions */
}            

int inline F243_QEP_Index_Handle(QEP *p)
{
        p->pulse_count=T2CNT;
        T2CNT=0;
        p->index_flag=0xf;
        
        p->rev_counter+=p->QepDir;
        

        EVIFRC|=0x08;                   /* Clear IFRC flag for CAP3 INT */
        

}

