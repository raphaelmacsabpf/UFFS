/* ==================================================================================
File name:       F07ILVD1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the ADC driver initialization of two leg current 
and the DC-bus voltage measurement on the F2407
Applicability of these functions is indicated in the Table 1               		
=====================================================================================
History:
-------------------------------------------------------------------------------------
9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name         |    Applicability                               */
/*----------------------------------------------------------------------------*/
/*                           | F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                           |      |     |      |        |        |          */
/* F2407_ileg2_dcbus_drv_init|      |     |      |    Y   |    Y   |    Y     */
/*----------------------------------------------------------------------------*/
/*
//
// typedef struct {  int Imeas_a_gain;    /* Parameter: gain for Ia (Q13) 
//                   int Imeas_a_offset;  /* Parameter: offset for Ia (Q15)
//                   int Imeas_a;         /* Output: measured Ia (Q15)
//                   int Imeas_b_gain;    /* Parameter: gain for Ib (Q13)
//                   int Imeas_b_offset;  /* Parameter: offset for Ib (Q15)
//                   int Imeas_b;         /* Output: measured Ib (Q15)
//                   int Vdc_meas_gain;   /* Parameter: gain for Vdc (Q13)
//                   int Vdc_meas_offset; /* Parameter: offset for Vdc (Q15)
//                   int Vdc_meas;        /* Output: measured Vdc (Q15)
//					 int Imeas_c;		  /* Output: computed Ic (Q15)	
//                   int Ch_sel;          /* Parameter: ADC channel selection
//                   int (*init)();       /* Pointer to the init function
//                   int (*read)();       /* Pointer to the read function
//                } ILEG2DCBUSMEAS;
*/

#include "..\include\regs240x.h"
#include "..\include\F07ILVD.h"
#include "..\include\override.h"
#include "..\include\F2407BMSK.H"

void inline F2407_ileg2_dcbus_drv_init(ILEG2DCBUSMEAS *p)
{

        SCSR1=SCSR1|0x0080;                 /* Turn on the clocks to the ADC module*/
        CALIBRATION=CALIBRATION_CONSTANT;

        GPTCONA=((GPTCONA&0xfe7f)|0x0080);   /* Set up EV Trigger      */
        ADCTRL1=ADC_RESET_FLAG;             /* Reset the ADC Module    */
        ADCTRL1=ADCTRL1_INIT_STATE;         /* Set up ADCTRL1 register */
      	ADCTRL2=ADCTRL2_INIT_STATE;         /* Set up ADCTRL2 register */
        MAXCONV=2;                          /* Specify three conversions  */

        CHSELSEQ1=p->Ch_sel;       			/* Configure channel selection */ 
}            
