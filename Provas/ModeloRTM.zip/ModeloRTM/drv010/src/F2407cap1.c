/* ==================================================================================
File name:       F2407CAP1.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the Capture Event Units on the TMS320F2407 
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F243_PWM_Init        |           |     |      |   Y    |   Y    |    Y     */
/*----------------------------------------------------------------------------*/
#include "..\include\regs240x.h"
#include "..\include\F2407CAP.h"
#include "..\include\override.h"

/* Note that for the changes to constants in the header file to take effect,
   THIS file must be re-compiled, AND any libs updated with the new obj.
   However to just change the definitions of ACTR for example, it can be done 
   anywhere in 'c' or asm code.
   For example 
        ACTR=NEW_VALUE;

*/

void  F2407_EV1_CAP_Init(CAPTURE_handle p)
{
        SCSR1=SCSR1|0x0004;                /* Turn EVA Clocks on             */
        CAPCONA=CAP_INIT_STATE;            /* Set up capture units           */
        T2CON  =TIMER_INIT_STATE;          /* Set up capture timer           */
        T2PR=0x7fff;
        MCRA=MCRA|0x38;                    /* Set up the capture pins to 
                                              primary functions              */
}    

int F2407_EV1_CAP1_Read(CAPTURE_handle p)
{
        if((CAPFIFOA&0x0100)!=0)
        {
        p->time_stamp=CAP1FIFO;
        return(0);
        } 
        else
        {
        return(1);
        }

}

