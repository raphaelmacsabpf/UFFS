/* ==================================================================================
File name:       F2407PWM2.C
                    
Originator:	Digital Control Systems Group
			Texas Instruments
Description:                                   
This file contains source for the Full Compare PWM  drivers for the F2407
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name    |    Applicability                                    */
/*----------------------------------------------------------------------------*/
/*                      |      F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                      |           |     |      |        |        |          */
/* F2407_EV2_PWM_Init   |           |     |      |        |   Y    |    Y     */
/*----------------------------------------------------------------------------*/


#include "..\include\regs240x.h" 
#include "..\include\F2407PWM.h"
#include "..\include\override.h"

int F2407_EV2_PWM_Init(PWMGEN *p) 
{       SCSR1|=0x0008;                       /* Turn EVB Clocks on            */
        T3PR=p->period_max;                  /* Init Timer 3 period Register  */
        T3CON=PWM_INIT_STATE;                /* Symmetrical Operation         */
        DBTCONB=DBTCON_INIT_STATE;                                    
        ACTRB=ACTR_INIT_STATE;                

        COMCONB=0xa200;

        CMPR4=p->period_max;
        CMPR5=p->period_max;
        CMPR6=p->period_max;

        MCRC|=0x007e;                    /* Set up the full compare
                                                PWM pins to primary functions.*/

        return(0);

}


