/* =====================================================================================
File name:        TRANSDLY.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo TransDly (Transport Delay).
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  x_in;           /* Entrada: Sinal de entrada
//			 	   int  i_in;           /* Vari�vel interna: �ndice para o vetor relativo ao sinal de entrada
//		 	 	   int  i_out;          /* Vari�vel interna: �ndice para o vetor relativo ao sinal de sa�da 		
//				   int  x_out;          /* Sa�da: Sinal de sa�da
//				   int  vet[42];        /* Vari�vel Interna: Vetor de armazenamento
//		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o
//				 } ATRASO;	              
//
*/

#include "..\include\transdly.h"

void transdly_update(ATRASO *p)
{
    
    p->vet[p->i_in] = p->x_in;
    p->i_in++;
    if (p->i_in == 42)
       p->i_in = 0;

    p->i_out = p->i_in + 1;
    if (p->i_out == 42)
        p->i_out = 0;
   
    p->x_out = p->vet[p->i_out];



/*
    int a, b;
        
    p->vet[p->i_in] = p->x_in;
    p->i_in++;
    if (p->i_in == 42)
       p->i_in = 0;

    p->i_out = p->i_in + 1;
    if (p->i_out == 42)
        p->i_out = 0;
   
    a = (((long)32508 * (long)p->vet[p->i_out])>>16)*2;
    b = (((long)260 * (long)p->vet[p->i_in])>>16)*2;

    p->x_out = a + b;
*/   

   
}            
