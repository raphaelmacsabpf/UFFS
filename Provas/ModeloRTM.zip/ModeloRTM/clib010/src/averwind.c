/* =====================================================================================
File name:        AVERWIND               
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo AverWind (M�dia M�vel).
=====================================================================================
History:
-------------------------------------------------------------------------------------
02-06-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  x_in;           /* Entrada: Sinal de entrada 
//			 	   int  n;              /* Vari�vel interna: Log(2) do n�mero de pontos a serem utilizados 
//			 	   int  i_x;            /* Vari�vel interna: �ndice para o ponto atual
//				   int  x_out;          /* Sa�da: Sinal de sa�da 
//				   int  vet[16];         /* Vari�vel Interna: Vetor de armazenamento 
//		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o 
//				 } MEDIA;	              
//
*/

#include "..\include\averwind.h"

void averwind_update(MEDIA *p)
{
    
    int cont;
    long soma=0; 
    int num_pts;
    
    num_pts = 1 >> p->n;
    
    p->vet[p->i_x] = p->x_in;
    p->i_x++;
    if (p->i_x == num_pts)
       p->i_x = 0;

    for (cont = 0; cont < num_pts; cont++)
        soma = soma + (long)p->vet[cont];
    
    p->x_out = soma >> p->n;
 
}            
