/* =====================================================================================
File name:        DDiPSPWM.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo DDiPSIPWM (modulador PWM para DDiPS monof�sico).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  v_ref;        /* Entrada: Sinal de entrada (Q15) 
//			 	   int  v_dc2;          /* Entrada: Tens�o da metade superior do barramento CC (Q15) 
//		 	 	   int  v_dc1;          /* Entrada: Tens�o da metade inferior do barramento CC (Q15) 
//		 	 	   int  duty;           /* Sa�da: Ciclo de trabalho do PWM como fra��o do periodo do registrador (Q15) 
//				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o
//				 } DIPSPWM;	    
//
//
*/

#include "..\include\ddipspwm.h"



void ddipspwm_update(DIPSPWM *p)
{

    int aux1;
    int aux2;
    int v_dc;     /* Tens�o total do barramento CC */

    
    v_dc = p->v_dc1 + p->v_dc2;
    
    if (p->v_ref > p->v_dc2)
       p->v_ref = p->v_dc2; 
    
    aux1 = -p->v_dc1;

    if (p->v_ref <= aux1)
       p->v_ref = aux1; 
    
    aux2 = p->v_dc2 - p->v_ref;
    
    
    if (aux2 > v_dc)
       aux2 = v_dc;
    
    aux1 = ((long)aux2 << 15)/v_dc;
    
    if (aux1 < 0)
       p->duty = 0x7FFF;
    else
       p->duty = aux1;
    
    p->duty = p->duty - 0x4000;

}            
 
