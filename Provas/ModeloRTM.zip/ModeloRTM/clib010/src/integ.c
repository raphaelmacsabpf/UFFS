/* =====================================================================================
File name:        INTEG.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo Integ (Integral).
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  x_in;         /* Entrada: Sinal de entrada (Frequ�ncia) (Q15) fn = 754rad/s
//			 	   int  dt;             /* Par�metro: Tempo de amostragem (Q15)
//		 	 	   int  x_out;          /* Sa�da: Sinal de sa�da (�ngulo) (Q15) (-PI <-> PI = 8000h <-> 7FFFh)
//				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o
//				 } INTEGRAL;	    
//
//
*/

#include "..\include\integ.h"

void integ_update(INTEGRAL *p)
{

    int temp;
    int aux;
    
    /*
    temp = (((long)p->x_in * (long)p->dt)>>16)*2;
    p->x_out = p->x_out + temp;
    */
    
    temp = (((long)p->x_in * (long)p->dt)>>16)*2;
    aux = p->x_out + temp;
    if (aux < 0)
       aux = 0;
    
    p->x_out = aux;
     
}            
