/* ==================================================================================
File name:       IOPORT.C
                    
Author: Rodrigo Campana

Description:                                   

Description:  


This file source for IO ports initialization and update.

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 18-06-2004	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */
/*
typedef struct { 
//				int PortA;					/* Variavel de Entrada: Valor dos Bits da portA 
//				int PortB;					/* Variavel de Entrada: Valor dos Bits da portB                   
//				int PortC;					/* Variavel de Entrada: Valor dos Bits da portC 
//				int PortD;					/* Variavel de Entrada: Valor dos Bits da portD 
//				int PortE;					/* Variavel de Entrada: Valor dos Bits da portE 
//				int (*init)();              /* Initialization func pointer  
//              int (*update)();            /* Update function              
//               } IOPORT;

=====================================================================================
*/

#include "..\include\regs240x.h"
#include "..\include\IOPORT.h"
#include "..\include\override.h"


void inline IOPORT_Init(IOPORT *p)
{
/*** Setup shared I/O pins ***/
		    MCRA = 0x0FC0;                     /* group A pins */
		/*
		 bit 15        0:      0=IOPB7,     1=TCLKINA
		 bit 14        0:      0=IOPB6,     1=TDIRA
		 bit 13        0:      0=IOPB5,     1=T2PWM/T2CMP
		 bit 12        0:      0=IOPB4,     1=T1PWM/T1CMP
		 bit 11        1:      0=IOPB3,     1=PWM6
		 bit 10        1:      0=IOPB2,     1=PWM5
		 bit 9         1:      0=IOPB1,     1=PWM4
		 bit 8         1:      0=IOPB0,     1=PWM3
		 bit 7         1:      0=IOPA7,     1=PWM2
		 bit 6         1:      0=IOPA6,     1=PWM1
		 bit 5         0:      0=IOPA5,     1=CAP3
		 bit 4         0:      0=IOPA4,     1=CAP2/QEP2
		 bit 3         0:      0=IOPA3,     1=CAP1/QEP1
		 bit 2         0:      0=IOPA2,     1=XINT1
		 bit 1         0:      0=IOPA1,     1=SCIRXD
		 bit 0         0:      0=IOPA0,     1=SCITXD
		*/
		
		    MCRB = 0xFE00;                     /* group B pins */
		/*
		 bit 15        1:      0=reserved,  1=TMS2 (always write as 1)
		 bit 14        1:      0=reserved,  1=TMS  (always write as 1)
		 bit 13        1:      0=reserved,  1=TD0  (always write as 1)
		 bit 12        1:      0=reserved,  1=TDI  (always write as 1)
		 bit 11        1:      0=reserved,  1=TCK  (always write as 1)
		 bit 10        1:      0=reserved,  1=EMU1 (always write as 1)
		 bit 9         1:      0=reserved,  1=EMU0 (always write as 1)
		 bit 8         0:      0=IOPD0,     1=XINT2/ADCSOC
		 bit 7         0:      0=IOPC7,     1=CANRX
		 bit 6         0:      0=IOPC6,     1=CANTX
		 bit 5         0:      0=IOPC5,     1=SPISTE
		 bit 4         0:      0=IOPC4,     1=SPICLK
		 bit 3         0:      0=IOPC3,     1=SPISOMI
		 bit 2         0:      0=IOPC2,     1=SPISIMO
		 bit 1         0:      0=IOPC1,     1=BIO*
		 bit 0         0:      0=IOPC0,     1=W/R*
		*/
		
		    MCRC = 0x0000;                     /* group C pins */
		/*
		 bit 15        0:      reserved
		 bit 14        0:      0=IOPF6,     1=IOPF6
		 bit 13        0:      0=IOPF5,     1=TCLKINB
		 bit 12        0:      0=IOPF4,     1=TDIRB
		 bit 11        0:      0=IOPF3,     1=T4PWM/T4CMP
		 bit 10        0:      0=IOPF2,     1=T3PWM/T3CMP
		 bit 9         0:      0=IOPF1,     1=CAP6
		 bit 8         0:      0=IOPF0,     1=CAP5/QEP4
		 bit 7         0:      0=IOPE7,     1=CAP4/QEP3
		 bit 6         0:      0=IOPE6,     1=PWM12
		 bit 5         0:      0=IOPE5,     1=PWM11
		 bit 4         0:      0=IOPE4,     1=PWM10
		 bit 3         0:      0=IOPE3,     1=PWM9
		 bit 2         0:      0=IOPE2,     1=PWM8
		 bit 1         0:      0=IOPE1,     1=PWM7
		 bit 0         0:      0=IOPE0,     1=CLKOUT    
		*/
		 
	/* Funcao dos pinos da porta C
	   IOPC0 = Sa�da - medicao do tempo de processamento da interrupcao principal
	   IOPC7 = Sa�da - medicao do tempo de processamento do ADC
	   */
	    PCDATDIR = PCDATDIR | 0x8100;  
	    
	     
	
	/* Funcao dos pinos da porta E 
	   IOPE1 = Entrada - Falta fase terra sinalizada pelo inversor WEG
	   IOPE2 = Entrada - Sobretemperatura sinalizada pelo inversor WEG
	   IOPE3 = Saida - Controle do contactor do barramento CA - Nivel alto
	   IOPE4 = Saida - Controle do contactor do barramento CC - Nivel alto
	   IOPE5 = Saida - Bypass do resistor de precarga do barramento CC    
	   IOPE7 = Entrada - Chave auxiliar
	   */  
	    PEDATDIR = PEDATDIR | 0x3800;
	    asm(" NOP");  
	    PEDATDIR = PEDATDIR & 0xff00;
	             
	
	/* Funcao dos pinos da porta B 
	   IOPB4 = Saida - Controle do contactor do barramento CA - Nivel baixo
	   IOPB5 = Saida - Controle do contactor do barramento CC - Nivel baixo
	   IOPB6 = Entrada - Sinal de Desligar
	   IOPB7 = Entrada - Sinal de Ligar
	   */  
	    PBDATDIR = PBDATDIR | 0x3000;
	    asm(" NOP");  
	    PBDATDIR = PBDATDIR | 0x0030;
}            
       
void IOPORT_Update(IOPORT *p)
{
   
   
}


