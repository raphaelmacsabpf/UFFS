/* =====================================================================================
File name:        WHATCHDOG.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo WhatchDog.
=====================================================================================
History:
-------------------------------------------------------------------------------------
29-09-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct {int x_in;           /* Entrada: Tens�o da rede
//		 	 	   int  reset;          /* Sa�da: Sinal de reset para o PID do PLL
//                 int  cont;           /* Par�metro: contador 
//				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o
//				 } WTCHDOG;	    
//
//
*/

#include "..\include\whatchdog.h"

void whatchdog_update(WTCHDOG *p)
{

    if ((p->x_in > 1000) || (p->x_in < -1000))
       p->cont = 100;
    else
       p->cont = p->cont - 1;
    
    
    if (p->cont < 0)
       p->cont = 0;
    
    if (p->cont == 0)
       p->reset = 0x7FFF;
}            
