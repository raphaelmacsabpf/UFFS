/* =====================================================================================
File name:        SAGGEN3F.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo SagGen3F.
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { SAG1F  sag_a;        /* Instancia do gerador de sag monof�sico para fase A 	
//			 	     SAG1F  sag_b;        /* Instancia do gerador de sag monof�sico para fase B 	
//		 	 	     SAG1F  sag_c;        /* Instancia do gerador de sag monof�sico para fase C 	
//		  	  	     int  (*update)();	/* Ponteiro para fun��o de atualiza��o  
//				   } SAG3F;	              
//
*/




#include "..\include\saggen3f.h"


void saggen3f_update(SAG3F *p)
{
      p->sag_a.update((void *)&p->sag_a);
      p->sag_b.tempo = p->sag_a.tempo;
      p->sag_c.tempo = p->sag_a.tempo;
      p->sag_b.update((void *)&p->sag_b);
      p->sag_c.update((void *)&p->sag_c);
}            
