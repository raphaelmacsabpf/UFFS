/* ==============================================================================
System Name:  	DVR_LAI

File Name:		LPF_1ORDER_2.C

Description:  	This file contains source for the low-pass 
				first-order filter


Originator:		Laborat�rio de Aplica��es Industriais - UFMG

Target dependency:	x2407/x2812
To Select the target device see target.h file.
		
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 01-05-2003	Release	Rev 1.0
=================================================================================*/ 

#include <LPF_1ORDER.h>

void lpf_1order_init (LPF_1ORDER * p) {

		p->PeriodOverTimeCteHigh = (((long)p->T)<<15)/(p->tal);
}