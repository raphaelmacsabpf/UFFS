/* ==================================================================================
File name:       PLL_3F.C
                    
Originator:		Laborat�rio de Aplica��es Industriais
				Universidade Federal de Minas Gerais
			
Description:	This file contains source to implementation of the 
				three phase PLL block


=====================================================================================*/


#include <pid_reg1.h>
/*#include <clark.h>
#include <park.h>*/
#include <integrator.h>
#include <PLL_3F.h>

/*
typedef struct PLL_3F {
		int va;					/ phase A input voltage - Q.15 	
		int vb;					/ phase B input voltage - Q.15 	
		int vc;					/* phase C input voltage - Q.15 	
		int vd;					/* d-axis voltage - Q.15			
		int vq;					/* q-axis voltage - Q.15			
		int vd_ref;				/* reference d-axis voltage - Q.15	
		int w_ref;				/* reference radian frequency - Q.15
		int	theta;				/* input voltage vector angle - Q.15 output		
		int w;					/* input voltage vector frequency - Q.15 output	
		INTEGRATOR 	integ;		/* integrator block 				
		CLARKE 	clarke_obj;		/* Clarke transformation block 		
		triad2 stationery_cmds;
		triad2 rotating_cmds;
		PIDREG1	pid;			/* PID complensator block 			
		int	(*update)();		/* pointer to update function		
} PLL_3F;*/

void PLL_3F_Update(PLL_3F *p) {
/*-----------------------------------------------------------------------------
	Connect system inputs to Clark transformation block.
-----------------------------------------------------------------------------*/
		p->clarke_obj.a = p->va;
		p->clarke_obj.b = p->vb;
		p->clarke_obj.c = p->vc;
/*-----------------------------------------------------------------------------
	Perform the runtime tasks of the Clarke object.
-----------------------------------------------------------------------------*/
		p->clarke_obj.calc((void *)&p->clarke_obj);
		
/*-----------------------------------------------------------------------------
	Connect Clarke outputs to the Park transformation 
	block inputs.
-----------------------------------------------------------------------------*/
		p->stationery_cmds.a = p->clarke_obj.d_stat;
		p->stationery_cmds.b = p->clarke_obj.q_stat;
		p->stationery_cmds.c = (p->theta>>1)+16384;
/*-----------------------------------------------------------------------------
	Perform the runtime tasks of the Park object.
-----------------------------------------------------------------------------*/
		park( &(p->stationery_cmds) , &(p->rotating_cmds) );
		
/*-----------------------------------------------------------------------------
	Connect Park output to the PID Controller and 
	to the PLL_3F block outputs vd and vq.
-----------------------------------------------------------------------------*/
		p->pid.pid_ref_reg1 = p->vd_ref;		/* Vd_Reference  */
        p->pid.pid_fb_reg1 = p->rotating_cmds.a;   /* Feedbacks the rotating d_component */
        p->vd = p->rotating_cmds.a;
        p->vq = p->rotating_cmds.b;
/*-----------------------------------------------------------------------------
	Perform the runtime tasks of the PID 
	Controller object.
-----------------------------------------------------------------------------*/
        p->pid.calc((void *)&p->pid);       
    
/*-----------------------------------------------------------------------------
	Connect the PID Controller output to 
	the integrator input.
-----------------------------------------------------------------------------*/
        p->integ.in = p->w_ref + p->pid.pid_out_reg1; 
        p->integ.calc( &(p->integ) );
        p->theta = p->integ.out; 
        
}	/* End: PLL_3F_Update() */