/* =====================================================================================
File name:        detsag1f.c                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo DetSag1F (Detec��o de voltage sags monof�sicos).
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  v_in;         /* Entrada: Tens�o da rede (Q15)
//			 	   int  amplitude;      /* Par�metro: Amplitude de refer�ncia (Q15) 
//                 int  theta;          /* Entrada: �ngulo de refer�ncia (0 <-> 32767 = 0 <-> 2PI)
//			 	   int  tempo_sag;      /* Par�metro: Tempo m�nimo de compensa��o (ciclos de PWM) 
//			 	   int  sag_flag;       /* Sa�da: Flag indicativo da presen�a de dist�rbio 
//			 	   int  v_ref;          /* Vari�vel Interna: Tens�o de refer�ncia 
//			 	   int  v_out;          /* Tens�o de compensa��o 
//			 	   int  delta_sag;      /* Par�metro: Erro m�ximo de tens�o admitido 
//			 	   int  cont;           /* Vari�vel Interna: Contador para o tempo m�nimo de compensa��o 
//                 int  enable;         /* Entrada: Enable da gera��o de refer�ncias 
//                 int  trigger;        /* Vari�vel Interna: contador para n�mero m�nimo de trigger
//                 int  angulo;         /* Vari�vel Interna: �ngulo para corre��o da fase
//		 	 	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o 
//				 } DET_SAG_1F;	    
//
//
*/

#include "..\include\detsag1f.h"

void detsag1f_update(DET_SAG_1F *p)
{

    int v1;
    int v2;
    int aux;
    
    aux = p->theta - 0x2000;
    if (aux < 0)
       aux = aux + 0x7FFF;
    
    aux = qsine(aux);
    p->v_ref = (((long)p->amplitude * (long)aux)>>16)*2;
    
    v1 = p->v_ref + p->delta_sag;
    v2 = p->v_ref - p->delta_sag;

/*  ================================================================
    
    if ((p->v_in > v1) || (p->v_in < v2))
    {  
       if (p->enable == 0x7FFF)
       {
          p->sag_flag = 0x7FFF;
          p->cont = p->tempo_sag;
       }
    }

/*  ================================================================ */


/*  ================================================================ */
    if ((p->v_in > v1) || (p->v_in < v2))
    { 
       if  (p->trigger < 5)
          p->trigger++;
       else
          p->trigger = p->trigger; 
    }
    else
       p->trigger = 0x0000;


    if (p->trigger >= 5)
    {
       if (p->enable == 0x7FFF)
       {
          p->sag_flag = 0x7FFF;
          p->cont = p->tempo_sag;
       }
    }
 /* ================================================================ */        

    if (p->sag_flag == 0x7FFF) 
    {
       aux = p->theta - 0x2000 + p->angulo;
       if (aux < 0)
          aux = aux + 0x7FFF;
       aux = qsine(aux);
       v1 = (((long)p->amplitude * (long)aux)>>16)*2;

       p->cont--;
       if (p->enable == 0x7FFF)
          p->v_out = v1 - p->v_in;
       else          
          p->v_out = 0x0000;
    }
    else
       p->v_out = 0x0000;
/*    if (p->cont <= 0x0000)
       p->sag_flag = 0x0000;
*/
    if (p->cont <= 0x0000)
       p->sag_flag = 0x0000;


}            
