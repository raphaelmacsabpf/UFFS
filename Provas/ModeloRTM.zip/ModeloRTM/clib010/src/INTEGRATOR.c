/* =====================================================================================================================
File name:      INTEGRATOR.C                     
                    
Originator:		Laborat�rio de Aplica��es Industriais	
				Universidade Federal de Minas Gerais

Description:
Implementation of a integrator block

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 11-04-2003	Release	Rev 1.0                                                   
----------------------------------------------------------------------------------- */

#include "INTEGRATOR.H"


void integrator_calc(INTEGRATOR *p)
{
		p->out += (((long)p->in*(long)p->dt)>>16)*2;

}	/* end integrator_calc()*/


	