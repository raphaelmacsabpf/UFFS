/* =====================================================================================
File name:        MEDIA2               
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo Media2 (M�dia entre um n�mero e seu valor anterior).
=====================================================================================
History:
-------------------------------------------------------------------------------------
02-06-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  x_in;           /* Entrada: Sinal de entrada
//			 	   int  x_anterior;     /* Vari�vel interna: N�mero de pontos a serem utilizados
//				   int  x_out;          /* Sa�da: Sinal de sa�da 
//		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o
//				 } MEDIA2;	              
//
*/

#include "..\include\media2.h"

void media2_update(MEDIA2 *p)
{
    
    long soma=0; 
    
    soma = ((long)p->x_in + (long)p->x_anterior) >> 1;
    p->x_out = soma;
    p->x_anterior = p->x_out;
  
}            
