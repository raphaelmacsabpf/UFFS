/* ==============================================================================
System Name:  	DVR_LAI

File Name:		LPF_1ORDER_1.C

Description:  	This file contains source for the low-pass 
				first-order filter


Originator:		Laborat�rio de Aplica��es Industriais - UFMG

Target dependency:	x2407/x2812
To Select the target device see target.h file.
		
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 01-05-2003	Release	Rev 1.0
=================================================================================*/ 

#include <LPF_1ORDER.h>

void lpf_1order_calc (LPF_1ORDER * p) {
		        
        p->accumulator = p->PeriodOverTimeCteHigh*(p->in - p->out);
        p->aux = ((long)p->PeriodOverTimeCteLow*(long)(p->in - p->out))>>15;
        p->accumulator = p->accumulator + (unsigned long)p->aux;
        p->outLong += p->accumulator;
        p->out = p->outLong >> 16;
        /*p->aux =  ((long)p->in * (long)p->PeriodOverTimeCte)>>5;
		p->aux -= ((long)p->out * (long)p->PeriodOverTimeCte)>>5;
		p->out = p->aux + p->out;*/
		
		/*p->auxLong = (long)(p->in - p->out)*(long)PeriodOverTimeCte;
		if (p->aux > 32768 )
			p->aux = (int)(p->auxLong >> 15);
		else p->aux = (int)p->auxLong;
		p->out += p->aux;*/
		
}