/* =====================================================================================
File name:        PLLMONO.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo PLL monof�sico (PLLMONO).
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  v_alpha;          /* Entrada: Sinal de entrada (Q15) 
//			 	     int  theta;            /* Sa�da: �ngulo de sa�da (Q15) (-PI <-> PI = 0x8000h <-> 0x7FFFh) 
//		 	 	     int  wff;              /* Par�metro: Comando de freq��ncia de feedforward (Q15). fn = 754rad/s 
//                   int  watchdog;         /* Vari�vel interna: contador para o reset do PI para possibilitar ressincronismo automatico
//                   ATRASO atraso1;        /* Objeto atraso de transporte 
//                   park_in girante;       /* Estrutura de entrada para transformada de Park 
//                   park_out estacionario; /* Estrutura de sa�da para transformada de Park 
//                   PIDREG1 pid;           /* Objeto PID 
//                   INTEGRAL integ;        /* Objeto Integrador (para �ngulo) 
//				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o 
//				 } PLL1F;	              
//
*/

#include "..\include\pllmono.h"

void pllmono_update(PLL1F *p)
{

    p->atraso1.x_in = p->v_alpha;
    p->atraso1.update((void *)&p->atraso1); 	/* Gera��o da tens�o Vbeta */
    
    p->girante.a = p->v_alpha;                  /* Vari�veis de entrada para a fun��o Park */
    p->girante.b = p->atraso1.x_out;
    p->girante.th = p->theta;
    
    park(&p->girante, &p->estacionario);        /* Chamada da fun��o Park */
    
    p->pid.pid_ref_reg1 = 0;                    /* Sinal de refer�ncia do PID */
    p->pid.pid_fb_reg1 = p->estacionario.q;     /* Sinal de feedback para o PID */
    
    p->pid.calc((void *)&p->pid);               /* C�lculo do PID */
    
    if ((p->v_alpha > 2000) || (p->v_alpha < -2000))  /* Reset autom�tico do PLL */
       p->watchdog = 0x00A7;
    else
       p->watchdog--;
    
    if (p->watchdog <= 0)
    {
       p->watchdog = 0x00A7;
       p->pid.pid_out_reg1 = 0;
    }
    
    p->integ.x_in = p->wff + p->pid.pid_out_reg1;    /* Sinal de entrada para o integrador (VCO) */ 
    p->integ.update((void *)&p->integ);         
    
    p->theta = p->integ.x_out;                  /* Sa�da do integrador (Teta) */

}            
