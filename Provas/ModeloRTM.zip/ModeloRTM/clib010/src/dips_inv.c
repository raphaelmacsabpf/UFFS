/* =====================================================================================
File name:        DIPS_INV.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Descri��o:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo DIPS_INV (Comando do inversor do DDiPS monof�sico).
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  v_in;           /* Entrada: Sinal de entrada (Q15) 
//			 	   int  enable;           /* Entrada: Sinal de enable da compensa��o 
//			 	   int  v_out;            /* Sa�da: Tens�o de refer�ncia para compensa��o (Q15) 
//		 	 	   int  sag_flag;         /* Sa�da: Sinaliza��o da presen�a de dist�rbios 
//                 PLL1F pll;             /* Objeto  PLL monof�sico 
//                 POLE polo;             /* Objeto filtro de primeira ordem 
//                 INTEGRAL integ1;       /* Objeto integral (freq -> �ngulo) 
//                 DET_SAG_1F detecta;    /* Objeto detec��o de voltage sags
//				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o 
//				 } DIPSINV;	              
//
*/

#include "..\include\dips_inv.h"

void dips_inv_update(DIPSINV *p)
{

        p->pll.v_alpha = p->v_in;
        p->pll.update((void *)&p->pll); 
        
        
        p->polo.freeze = p->detecta.sag_flag;
        p->polo.x_in = p->pll.estacionario.d;
        p->polo.update((void *)&p->polo);


        if (p->polo.x_out < 0)
           p->detecta.amplitude = -p->polo.x_out;
        else                                     
           p->detecta.amplitude = p->polo.x_out;
        p->detecta.v_in = p->v_in;
        p->detecta.theta = p->pll.theta;
        p->detecta.enable = p->enable;
        p->detecta.update((void *)&p->detecta);
        
        p->v_out = p->detecta.v_out;
        p->sag_flag = p->detecta.sag_flag;
        

}            
