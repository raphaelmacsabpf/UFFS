/* =====================================================================================
File name:        DATA_LOG1.C                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description:                                 
This file contains source for initialization of DATA_LOG module
Applicability of these functions is indicated in the Table 1               
=====================================================================================
History:
-------------------------------------------------------------------------------------
9-15-2000	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*                           T A B L E      1                                 */
/*----------------------------------------------------------------------------*/
/*     Function Name         |    Applicability                               */
/*----------------------------------------------------------------------------*/
/*                           | F240 | F241| F243 | LF2402 | LF2406 | LF2407   */
/*                           |      |     |      |        |        |          */
/*     data_log_init         |  Y   |  Y  |  Y   |    Y   |    Y   |    Y     */
/*----------------------------------------------------------------------------*/
/*
//
//  typedef struct { int  *dlog_iptr1; 	/* Input: First input pointer (Q15) 
//			 	   int  *dlog_iptr2;	/* Input: Second input pointer (Q15)		
//		 	 	   int  trig_value;		/* Input: Trigger point (Q15) 		
//				   int  graph_ptr1;		/* Variable: First graph address pointer 
//				   int  graph_ptr2;  	/* Variable: Second graph address pointer 	
//				   int  dlog_skip_cntr;	/* Variable: Data log skip counter 			 
//				   int  dlog_cntr;		/* Variable: Data log counter
//		  	  	   int  task_ptr;		/* Variable: Task address pointer 
//		  	  	   int  dlog_prescale;  /* Parameter: Data log prescale 
//		  	  	   int  dlog_cntr_max;  /* Parameter: Maximum data buffer 
//		  	  	   int  dl_buffer1_adr; /* Parameter: Buffer starting address 1
//		  	  	   int  dl_buffer2_adr; /* Parameter: Buffer starting address 2    		  	  	   
//		  	  	   int  (*init)();      /* Pointer to init function
//		  	  	   int  (*update)();	/* Pointer to update function 
				 } DATALOG;	              
*/

#include "..\include\data_log.h"

void data_log_init(DATALOG *p)
{
	int *temp_add;
	
   	temp_add = &p->task_ptr+6; /* temp_add is pointing to the update function */
   	p->task_ptr = *temp_add+16;  	 /* initialize p.task_ptr to the #POS_TRIG_S1 */
}            
