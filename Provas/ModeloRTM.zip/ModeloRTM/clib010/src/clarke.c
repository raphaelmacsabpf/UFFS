/* ==============================================================================
System Name:  	DVR_LAI

File Name:		CLARKE.C

Description:  	Implementation of a Clarke Transformation.

Originator:		Laborat�rio de Aplica��es Industriais
				Universidade Federal de Minas Gerais

Target dependency:	x2407/x2812
To Select the target device see target.h file.
		
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 14-04-2003	Release	Rev 1.0
=================================================================================*/ 


#include "clarke.h"

void clarke_calc(CLARKE *p) {
/*-------------------------------------------------------------------------------------
	Declares interface variables for proper calling 
	of the clark() assembly function
-------------------------------------------------------------------------------------*/	
		struct { int a,b,c ; } clarke_in;
		struct { int a,b ; } clarke_out;

/*-------------------------------------------------------------------------------------
	Connects the terminal variables of the park block 
	to the interface variables
-------------------------------------------------------------------------------------*/
		clarke_in.a = p->a;
		clarke_in.b = p->b;
		clarke_in.c = p->c;
/*-------------------------------------------------------------------------------------
	Computes the park trasformation by the 
	park() C-callable assembly function
-------------------------------------------------------------------------------------*/
		clark(&clarke_in,&clarke_out);

		p->d_stat = clarke_out.a;
		p->q_stat = clarke_out.b;		
}	/* end clarke_calc() */		