/* =====================================================================================
File name:        POLEP.C                     
                    
Autor:	Sidelmo Magalh�es Silva

Description:
                                 
Este arquivo cont�m o c�digo fonte para atualiza��o
do m�dulo PoleP (P�lo simples).
=====================================================================================
History:
-------------------------------------------------------------------------------------
21-04-2003	Release	Rev 1.0                                                      */
/*----------------------------------------------------------------------------*/
/*
//  typedef struct { int  x_in;         /* Entrada: Sinal de entrada (Q15) 
//			 	   int  dt_ov_p_l;      /* Par�metro: Parte alta do tempo de amostragem sobre a cte de tempo (Q15)
//		 	 	   int  dt_ov_p_h;      /* Par�metro: Parte baixa do tempo de amostragem sobre a cte de tempo (Q15)
//		 	 	   int  x_out;          /* Sa�da: Sinal de sa�da (Q15) 
//				   long int x_out_long; /* Vari�vel Interna: Sa�da em 32 bits
//				   long int accum;      /* Vari�vel Interna 
//                 int  freeze;         /* Entrada: sinal de habilita��o do filtro
//				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o 
//				 } POLE;	              
//
*/

#include "..\include\polep.h"

void polep_update(POLE *p)
{
    int aux;
    
    if (p->freeze == 0)
    {
       p->accum = p->dt_ov_p_h*(p->x_in - p->x_out);
       aux = ((long)p->dt_ov_p_l * (long)(p->x_in - p->x_out))>>15;
       p->accum = p->accum + (unsigned long)aux;

       p->x_out_long += p->accum;
       p->x_out = p->x_out_long >> 16;
    }
}         
