/* =================================================================================
File name:        detsag1f.h                     
                    
Autor: Rodrigo Campana

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo DetSag1F (detec��o de voltage sag monof�sico).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __DETSAG1F_H__
#define __DETSAG1F_H__

  typedef struct { int  v_in;       	/* Entrada: Tens�o da rede (Q15) */
				   int  delta_v;       	/* Parametro: Variacao da tensao de entrada permitida */
			 	   int  flag;     	    /* Sa�da: Flag indicativo da presen�a de dist�rbio */
			 	   int  min_time;       /* Parametro: Tempo minimo para indicacao de sag */
			 	   int  v_out;          /* Sa�da: Tens�o de saida */
			 	   int  begin;          /* Vari�vel Interna: Contador */
                   int  end;            /* Vari�vel Interna: Contador */
                   int  enable;         /* Entrada: Enable da gera��o de refer�ncias */
                   int  cont;           /* Vari�vel Interna: Contador */
                   int  data[84];       /* Vari�vel Interna: Vetor de dados */
                   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } DET_SAG_1F;	    

/*-----------------------------------------------------------------------------
Default initalizer for the INTEGRAL object.
-----------------------------------------------------------------------------*/                     
#define DET_SAG_1F_DEFAULTS {  0x0000, \
                        	   0x7333, \
                        	   0x0000, \
                        	   0x0100, \
                          	   0x0000, \
                          	   0x0000, \
                          	   0x0000, \
                          	   0x0000, \
                          	   0x0011, \
                          	   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
							   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
				           	   (int (*)(int))detsag1f_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in PoleP.C
------------------------------------------------------------------------------*/
void detsag1f_update(DET_SAG_1F *); 

extern int qsine();
 
#endif /* __DETSAG1F_H__ */
