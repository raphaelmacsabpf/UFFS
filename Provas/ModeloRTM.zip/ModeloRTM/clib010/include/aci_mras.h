/* =================================================================================
File name:        ACI_MRAS.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing constants, data type definitions, and 
function prototypes for the ACI_MRAS module.                                  
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __ACI_MRAS_H__
#define __ACI_MRAS_H__

typedef struct 	{ int  ualfa_mras; 		/* Input: alfa-axis phase voltage at k (Q15) */
				  int  ubeta_mras;		/* Input: beta-axis phase voltage at k (Q15) */
				  int  ialfa_mras;		/* Input: alfa-axis line current at k (Q15) */			
				  int  ibeta_mras;		/* Input: beta-axis line current at k (Q15) */
				  int  ialfa_old; 		/* History: alfa-axis line current at k-1 (Q15) */		
				  int  ibeta_old;		/* History: beta-axis line current at k-1 (Q15) */					  
			      int  imalfa_old_high; /* History: alfa-axis magnetizing current at k-1 (Q31) */
			      int  imalfa_old_low;  /* History: alfa-axis magnetizing current at k-1 (Q31) */
			      int  imbeta_old_high; /* History: beta-axis magnetizing current at k-1 (Q31) */
			      int  imbeta_old_low;  /* History: beta-axis magnetizing current at k-1 (Q31) */
			      int  imalfa_high;     /* Variable: alfa-axis magnetizing current at k (Q31) */
			      int  imalfa_low;      /* Variable: alfa-axis magnetizing current at k (Q31) */
			      int  imbeta_high;     /* Variable: beta-axis magnetizing current at k (Q31) */
			      int  imbeta_low;      /* Variable: beta-axis magnetizing current at k (Q31) */
			      int  ealfa;			/* Variable: alfa-axis back emf at k (Q15) */
			      int  ebeta;			/* Variable: beta-axis back emf at k (Q15) */
			      int  q;				/* Variable: reactive power in reference model (Q15) */
			      int  q_hat;			/* Variable: reactive power in adaptive model  (Q15) */
			      int  error;			/* Variable: reactive power error (Q15) */			      
			      int  K1;				/* Parameter: constant using in reference model (Q10) */
			      int  K2;				/* Parameter: constant using in adaptive model (Q15) */
			      int  K3;				/* Parameter: constant using in adaptive model (Q8) */
			      int  K4;				/* Parameter: constant using in adaptive model (Q15) */
			      int  K5;				/* Parameter: constant using in adaptive model (Q15) */
			      int  K6;				/* Parameter: constant using in adaptive model (Q15) */
			      int  K7;				/* Parameter: constant using in adaptive model (Q15) */
			      int  Kp;				/* Parameter: proportioanl gain  (Q15) */
			      int  Ki_high;			/* Parameter: integral gain (Q31) */
			      int  Ki_low;			/* Parameter: integral gain (Q31) */
			      int  base_rpm;		/* Parameter: base motor speed in rpm (Q3) */	  			      
				  int  wr_hat_mras;		/* Output: estimated (per-unit) motor speed (Q15) */
				  int  wr_hat_rpm_mras; /* Output: estimated (rpm) motor speed (Q0) */
		  	  	  int  (*calc)();	    /* Pointer to calculation function */ 
				} ACIMRAS;	                   

/*-----------------------------------------------------------------------------
Default initalizer for the ACIMRAS object.
-----------------------------------------------------------------------------*/                     
#define ACIMRAS_DEFAULTS { 0x0000,0x0000,0x0000,0x0000, \
                           0x0000,0x0000,0x0000,0x0000,0x0000,0x0000, \
 		          		   0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000, \
 		          		   0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000, \
 		          		   0x0000,0x0000,0x0000,0x0000, \
                  		   0x0000,0x0000, \
                  		   (int (*)(int))aci_mras_calc }

/*------------------------------------------------------------------------------
Prototypes for the functions in ACI_MRAS.ASM
------------------------------------------------------------------------------*/
void aci_mras_calc(ACIMRAS *);

#endif /* __ACI_MRAS_H__ */
