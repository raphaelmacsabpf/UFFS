/* =================================================================================
File name:        RMP2.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines handy constants for object initializations
contains prototypes for the functions in RMP2CNTL.ASM.
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __RMP2CNT__
#define __RMP2CNT__


/*-----------------------------------------------------------------------------
Define the structure of the RMP2CNTL
(Implements a implements a ramp up and ramp down function)
-----------------------------------------------------------------------------*/

typedef struct {

   int max;         /*  Maximum  value of Ramp2                              */
   int min;         /*  Minimum  value of Ramp2                              */
   int dly;         /*  Ramp 2 step delay in number of sampling cycles       */
   int delay_cntr;  /*  Counter for ramp 2 step delay                        */
   int desired;     /*  Desired value of ramp2                               */
   int out;         /*  Ramp2 output                                         */
   int (*calc)();   /*  Pointer to the calculation function                  */

} RMP2;
  typedef RMP2 *RMP2_handle;
/*----------------------------------------------------------------------------
 Object Initalizers
 ----------------------------------------------------------------------------*/

#define RMP2_DEFAULTS { 0x7ff0,\
                        0x0f,  \
                        0x50,  \
                        0x0,  \
                        0x0,  \
                        0x0,  \
                        (int (*) (int))rmp2_calc \
                      }

/*----------------------------------------------------------------------------
  Function prototypes
 -----------------------------------------------------------------------------*/

void rmp2_calc(RMP2_handle);

#endif    /* __RMP2CNT__ */
