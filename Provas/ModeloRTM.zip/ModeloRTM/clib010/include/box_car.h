/* =================================================================================
File name:        BOX_CAR.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing constants, data type definitions, and 
function prototypes for the BOXCAR module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __BOX_CAR_H__
#define __BOX_CAR_H__

#define BC_SIZE 2
/* if BC_SIZE here is changed, the BC_SIZE_ in prototype for the function 
in BOX_CAR.ASM must be accordingly changed. */

 typedef struct { int  BC_IN; 			    /* Input: Box-Car input (Q15) */
				  int  BC_PTR;			    /* Variable: Box-car buffer pointer */			
		 	 	  int  BC_BUFFER[BC_SIZE];	/* Variable: Box-car buffer (Q15) */
				  int  BC_OUT;			    /* Output: Box-car output (Q15) */
				  int  bc_scaler;		    /* Parameter: Box-car scaler (Q15) */
		  	  	  int  (*calc)();	  	    /* Pointer to calculation function */ 
				 } BOXCAR;	            

/*-----------------------------------------------------------------------------
Default initalizer for the BOXCAR object.
-----------------------------------------------------------------------------*/                     
#define BOXCAR_DEFAULTS { 0x0000, \
                          0x0000, \
                          0,0, \
                          0x0000, \
                          0x7FFF, \
               			  (int (*)(int))bc_calc }

/*
#define BOXCAR_DEFAULTS { 0x0000, \
                          0x0000, \
                          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, \
                          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, \
                          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, \
                          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, \
                          0x0000, \
                          0x7FFF, \
               			  (int (*)(int))bc_calc }

*/

/* Note that the default BC_BUFFER is added accoringly to the BC_SIZE 

/*------------------------------------------------------------------------------
Prototypes for the functions in BOX_CAR.ASM
------------------------------------------------------------------------------*/
void bc_calc(BOXCAR *);

#endif /* __BOX_CAR_H__ */
