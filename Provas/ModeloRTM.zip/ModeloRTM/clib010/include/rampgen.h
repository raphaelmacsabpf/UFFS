/* =================================================================================
File name:        RAMPGEN.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file contains type definitions, constants and initializers for
the ramp generation functions contained in RAMPGEN.ASM
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef     __RAMPGEN_H__
#define     __RAMPGEN_H__
/*-----------------------------------------------------------------------------
Define the structure of the RAMPGEN
RAMP Function Generator
-----------------------------------------------------------------------------*/
typedef struct  {   
                    int freq;      /* Frequency setting        Q15 Input     */ 
                    int freq_max;  /* Frequency setting        Q0  Input     */ 
                    int alpha;     /* Internal var - Phase angle history     */
                    int gain;      /* Waveform amplitude       Q15 Input     */
                    int offset;    /* Offset setting           Q15 Input     */ 
                    int out;       /* Ramp generator output    Q15 Output    */
                    int (*calc)(); /* Pointer to calculation function        */ 
                } RAMPGEN;

typedef RAMPGEN *RAMPGEN_handle;
               
/*------------------------------------------------------------------------------
      Object Initializers
------------------------------------------------------------------------------*/                       
#define RAMPGEN_DEFAULTS {0x3fff, 1000, 0x0, 0x0fff, 0x6fff, 0x0, \
                         (int (*)(int))rampgen_calc }

/*------------------------------------------------------------------------------
      Funtion prototypes
------------------------------------------------------------------------------*/                       
                          
void rampgen_calc(RAMPGEN_handle);

#endif


