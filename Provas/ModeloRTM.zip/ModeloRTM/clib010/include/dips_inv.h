/* =================================================================================
File name:        DIPS_INV.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo DIPS_INV (Comando do inversor do DDiPS monof�sico).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __DIPS_INV_H__
#define __DIPS_INV_H__

#include "..\include\polep.h"
#include "..\include\pllmono.h"
#include "..\include\integ.h"
#include "..\include\detsag1f.h"

  typedef struct { int  v_in;             /* Entrada: Sinal de entrada (Q15) */
			 	   int  enable;           /* Entrada: Sinal de enable da compensa��o */
			 	   int  v_out;            /* Sa�da: Tens�o de refer�ncia para compensa��o (Q15) */
		 	 	   int  sag_flag;         /* Sa�da: Sinaliza��o da presen�a de dist�rbios */
                   PLL1F pll;             /* Objeto  PLL monof�sico */
                   POLE polo;             /* Objeto filtro de primeira ordem */
                   INTEGRAL integ1;       /* Objeto integral (freq -> �ngulo) */
                   DET_SAG_1F detecta;    /* Objeto detec��o de voltage sags */  
				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } DIPSINV;	              

/*-----------------------------------------------------------------------------
Default initalizer for the DIPSINV object.
-----------------------------------------------------------------------------*/                     
#define DIPSINV_DEFAULTS { 0x0000, \
                           0x0000, \
                           0x0000, \
                           0x0000, \
                           PLL1F_DEFAULTS, \
                           POLE_DEFAULTS,  \
                           INTEGRAL_DEFAULTS, \
                           DET_SAG_1F_DEFAULTS, \
                           (int (*)(int))dips_inv_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in DiPSInv.C
------------------------------------------------------------------------------*/
void dips_inv_update(DIPSINV *); 
 
#endif /* __DIPS_INV_H__ */
