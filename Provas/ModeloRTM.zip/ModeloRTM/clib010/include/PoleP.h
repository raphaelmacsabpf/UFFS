/* =================================================================================
File name:        PoleP.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo PoleP (p�lo P).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __POLEP_H__
#define __POLEP_H__

  typedef struct { int  x_in;         /* Entrada: Sinal de entrada (Q15) */
			 	   int  dt_ov_p_l;      /* Par�metro: Parte alta do tempo de amostragem sobre a cte de tempo (Q15) */
		 	 	   int  dt_ov_p_h;      /* Par�metro: Parte baixa do tempo de amostragem sobre a cte de tempo (Q15) */
		 	 	   int  x_out;          /* Sa�da: Sinal de sa�da (Q15) */ 
				   long int x_out_long; /* Vari�vel Interna: Sa�da em 32 bits */
				   long int accum;      /* Vari�vel Interna */
                   int  freeze;         /* Entrada: sinal de habilita��o do filtro */				   
				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } POLE;	              

/*-----------------------------------------------------------------------------
Default initalizer for the POLE object.
-----------------------------------------------------------------------------*/                     
#define POLE_DEFAULTS {  0x0000, \
                         0x0000, \
                         0x0002, \
                         0x0000, \
                         0x00000000, \
                         0x00000000, \
                         0x0000, \
                         (int (*)(int))polep_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in PoleP.C
------------------------------------------------------------------------------*/
void polep_update(POLE *); 
 
#endif /* __POLEP_H__ */
