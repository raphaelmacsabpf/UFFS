/* =================================================================================
File name:        RMP3.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines handy constants for object initializations
contains prototypes for the functions in  RMP3CNTL.ASM
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __RMP3CNT__
#define __RMP3CNT__

/*------------------------------------------------------------------------------
Define the structure of the RMP3CNTL
( This module implements a ramp down function )
-------------------------------------------------------------------------------*/


typedef struct{

   int desired;                        /* Desired value of ramp3 */
   int dly;                            /* ramp3 step delay */
   int dly_cntr;                       /* counter for ramp3 step delay  */
   int min;                            /* minimun value of ramp3 */
   int out;                            /* ramp3 output */
   int done_flg;                       /* flag output for indicating ramp3 status */
   int (*calc)();                      /* pointer to calculation function */

}RMP3;

typedef RMP3 *RMP3_handle;

/*------------------------------------------------------------------------------
      Object Initializers
------------------------------------------------------------------------------*/


#define RMP3_DEFAULTS { 0x0, \
                        0x0, \
                        0x0, \
                        0x50,\
                        0x0, \
                        0x0, \
                        (int (*) (int))rmp3_calc \
                      }

/*------------------------------------------------------------------------------
      Function prototypes
------------------------------------------------------------------------------*/

void rmp3_calc(RMP3_handle);


#endif    /*  __RMP3CNT__ */
