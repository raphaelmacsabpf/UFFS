/* =================================================================================
File name:        MOD6.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines handy constants for object initializations
contains prototypes for the functions in MOD6_CNT.asm
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __MOD6CNT__
#define __MOD6CNT__
/*-----------------------------------------------------------------------------
Define the structure of the MOD6_CNT
(Modulo 6 Counter)
-----------------------------------------------------------------------------*/

typedef struct {

   int trig_in;         /*      Modulo 6 counter trigger input               */
   int cntr;            /*      Modulo 6 counter output                      */

   int  (*calc)();      /*      Pointer to the Calculation Function          */
} MOD6CNT;

typedef MOD6CNT *MOD6CNT_handle;

/*----------------------------------------------------------------------------
 Object Initalizers
 ----------------------------------------------------------------------------*/

#define MOD6CNT_DEFAULTS {0x0,\
                          0x0,\
                          (int (*) (int))mod6cnt_calc\
                         }


/*----------------------------------------------------------------------------
 Function Prototypes
 ----------------------------------------------------------------------------*/

void mod6cnt_calc(MOD6CNT_handle);


#endif  /* __MOD6CNT__ */
