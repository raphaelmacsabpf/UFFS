/* =================================================================================
File name:        IMPL.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines handy constants for object initializations
contains prototypes for the functions in IMPULSE.ASM.
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __IMPULSE__
#define __IMPULSE__

/*-----------------------------------------------------------------------------
Define the structure of the IMPULSE
(Implements a periodic impulse function.This is the impulse generator module)
-----------------------------------------------------------------------------*/

typedef struct   {
   int period;     /* Period of output impulses in number of sampling cycles */
   int out;        /* Impulse generator output                               */
   int skpcnt;

   int (*calc)();  /* Pointer to the Calculation function                    */
   }IMPULSE;

 typedef IMPULSE *IMPULSE_handle;
/*----------------------------------------------------------------------------
 Object Initalizers
 ----------------------------------------------------------------------------*/

#define IMPULSE_DEFAULTS  { 0x1000, \
                            0x0,    \
                            0x0,    \
                            (int (*) (int))impulse_calc \
                           }

/*----------------------------------------------------------------------------
 Function prototypes
 ----------------------------------------------------------------------------*/

void impulse_calc (IMPULSE_handle);

#endif     /*__IMPULSE__ */