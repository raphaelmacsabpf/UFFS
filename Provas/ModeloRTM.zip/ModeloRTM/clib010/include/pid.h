/* =================================================================================
File name:        PID.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing 
	1. Data types and constants specific to the PID Module.
	2. Function prototypes for the functions in PID.ASM
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef	__PID__
#define	__PID__
/*-----------------------------------------------------------------------------
Define the structure of the PID object.
-----------------------------------------------------------------------------*/
typedef struct  { int un_H;  /* Accumulated sum bits 31-16 of Q31 sum HISTORY*/
                  int un_L;  /* Accumulated sum bits 15-00 of Q31 sum HISTORY*/
                  int en;    /* Error: Q15 Input                             */
                  int en_1;  /* Previous error - History                     */
                  int en_2;  /* Previous error - History                     */
                  int K0;    /* PID Coeffiecient Input Q15                   */
                  int K1;    /* PID Coeffiecient Input Q15                   */
                  int K2;    /* PID Coeffiecient Input Q15                   */
                  int Kx;    /* PID Coeffiecient Input Q15                   */
                  int Kf;    /* PID Coeffiecient Input Q15                   */
                  int rn;    /* PID Reference    Input Q15                   */
                  int psat;  /* PID Coeffiecient Input Q15                   */
                  int nsat;  /* PID Coeffiecient Input Q15                   */
                  int output;    /* PID Output Q15                           */
                  int (*calc)(); /* Pointer to the PID calculation function  */
               } PID;

/*-----------------------------------------------------------------------------
Default initalizer for the PID object.
-----------------------------------------------------------------------------*/
#define PID_DEFAULTS {0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                      0x7fff, 0x8001, 0x0000, 0x0001, 0x0000, \
                      0x0000, 0x7fff, 0x8001, 0x0000,         \
                      (int (*)(int))pid_ff                    \
                     }

/*-----------------------------------------------------------------------------
Function prototype for the function in PID.ASM.
-----------------------------------------------------------------------------*/
int pid_ff(PID *);


#endif
