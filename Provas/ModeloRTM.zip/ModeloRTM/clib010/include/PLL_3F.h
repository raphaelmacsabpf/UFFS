/* ==============================================================================
System Name:  DVR_LAI

File Name:	PLL_3F.H

Description:  	Header file for target independent/application configurable
				object implementation of a three-phase PLL.

Originator:		Laborat�rio de Aplica��es Industriais - UFMG

Target dependency:	x2407/x2812
To Select the target device see target.h file.
		
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 10-04-2003	Release	Rev 1.0
=================================================================================*/ 

#ifndef __PLL_3F_H__
#define __PLL_3F_H__

#include "integrator.h"
#include "pid_reg1.h"
/*#include "park.h"*/
#include "clarke.h"         

/*-------------------------------------------------------------------------------
    Miscellaneous Items.                                     		       
-------------------------------------------------------------------------------*/
typedef struct TRIAD_PLL {
			int a;
			int b;
			int c;
}TRIAD_PLL;

#define TRIAD_DEFAULTS { 0x0000,	\
						 	 0x0000,	\
						 	 0x0000	}

/*------------------------------------------------------------------------------
 Define the structure of the PLL_3F Object. 
------------------------------------------------------------------------------*/
typedef struct PLL_3F {
		int va;					/* phase A input voltage - Q.15 	*/
		int vb;					/* phase B input voltage - Q.15 	*/
		int vc;					/* phase C input voltage - Q.15 	*/
		int vd;					/* d-axis voltage - Q.15			*/
		int vq;					/* q-axis voltage - Q.15			*/
		int vd_ref;				/* reference d-axis voltage - Q.15	*/
		int w_ref;				/* reference radian frequency - Q.15*/
		int	theta;				/* input voltage vector angle - Q.15 output		*/
		int w;					/* input voltage vector frequency - Q.15 output	*/
		INTEGRATOR 	integ;		/* integrator block 				*/
		CLARKE 	clarke_obj;		/* Clarke transformation block 		*/
		TRIAD_PLL stationery_cmds;
		TRIAD_PLL rotating_cmds;
		PIDREG1	pid;			/* PID compensator block 			*/
		int	(*update)();		/* pointer to update function		*/
} PLL_3F;
/*------------------------------------------------------------------------------
 Define the defaults of the PLL_3F Object. 
------------------------------------------------------------------------------*/
#define PLL_3F_DEFAULTS {	0x7fff,	\
        					0x7fff,	\
        					0x7fff,	\
        					0x0000,	\
        					0x0000,	\
        					0x0000,	\
        					16384,	\
        					0x0000,	\
        					0x0000,	\
        					INTEGRATOR_DEFAULTS, \
        					CLARKE_DEFAULTS,	\
        					TRIAD_DEFAULTS, \
        					TRIAD_DEFAULTS, \
        					PIDREG1_DEFAULTS,\
        					(int (*)(int))PLL_3F_Update }
		
typedef PLL_3F * PLL_3F_HANDLE;


void PLL_3F_Update(PLL_3F *);


#endif	/* end __PLL_3F_H__ */		