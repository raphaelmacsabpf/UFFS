/* ==================================================================================
File name:        IOPORT.H                     
                    
Author:	Sidelmo M. Silva

Description:  


This file defines handy constants for object initializations and
contains prototypes for DSP IO ports.

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 18-06-2004	Release	Rev 1.0                                                  
---------------------------------------------------------------------------------- */

#ifndef __IOPORT__
#define __IOPORT__

#include "..\include\F2407BMSK.H"

#ifndef NULL
#define NULL 0
#endif

/*-----------------------------------------------------------------------------
Define the structure of the ADC_16CH
-----------------------------------------------------------------------------*/

typedef struct { 
				int PortA;					/* Variavel de Entrada: Valor dos Bits da portA */
				int PortB;					/* Variavel de Entrada: Valor dos Bits da portB */                  
				int PortC;					/* Variavel de Entrada: Valor dos Bits da portC */
				int PortD;					/* Variavel de Entrada: Valor dos Bits da portD */
				int PortE;					/* Variavel de Entrada: Valor dos Bits da portE */
				int (*init)();              /* Initialization func pointer  */
                int (*update)();            /* Update function              */
               } IOPORT;


/*------------------------------------------------------------------------------
Default Initializers for the ADC16CH Object
------------------------------------------------------------------------------*/

#define IOPORT_DEFAULTS { 0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            0x0,\
                            (int (*)(int))IOPORT_Init, \
                            (int (*)(int))IOPORT_Update \
                           }



/*----------------------------------------------------------------------------
 Function prototypes
 ----------------------------------------------------------------------------*/

void IOPORT_Init(IOPORT *p);
void IOPORT_Update(IOPORT *p);


#endif     /*__IOPORT__ */


