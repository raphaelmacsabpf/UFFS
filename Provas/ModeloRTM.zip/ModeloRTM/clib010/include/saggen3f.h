/* =================================================================================
File name:        SagGen3F.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo SagGen3F.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __SAGGEN3F_H__
#define __SAGGEN3F_H__

#include "..\include\saggen1f.h"

  typedef struct { SAG1F  sag_a;        /* Instancia do gerador de sag monof�sico para fase A */	
			 	   SAG1F  sag_b;        /* Instancia do gerador de sag monof�sico para fase B */	
		 	 	   SAG1F  sag_c;        /* Instancia do gerador de sag monof�sico para fase C */	
		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */ 
				 } SAG3F;	              

/*-----------------------------------------------------------------------------
Default initalizer for the SAG1F object.
-----------------------------------------------------------------------------*/                     
#define SAG3F_DEFAULTS {  SAG1F_DEFAULTS_A, \
                          SAG1F_DEFAULTS_B, \
                          SAG1F_DEFAULTS_C, \
                          (int (*)(int))saggen3f_update}



/*------------------------------------------------------------------------------
Prototypes for the functions in SagGen1F.C
------------------------------------------------------------------------------*/
void saggen3f_update(SAG3F *); 
 
#endif /* __SAGGEN3F_H__ */
