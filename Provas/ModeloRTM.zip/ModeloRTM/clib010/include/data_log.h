/* =================================================================================
File name:        DATA_LOG.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing constants, data type definitions, and 
function prototypes for the DATALOG module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __DATA_LOG_H__
#define __DATA_LOG_H__

  typedef struct { int  *dlog_iptr1; 	/* Input: First input pointer (Q15) */	
			 	   int  *dlog_iptr2;	/* Input: Second input pointer (Q15) */		
		 	 	   int  trig_value;		/* Input: Trigger point (Q15) */		
				   int  graph_ptr1;		/* Variable: First graph address pointer */
				   int  graph_ptr2;  	/* Variable: Second graph address pointer */	
				   int  dlog_skip_cntr;	/* Variable: Data log skip counter */				 
				   int  dlog_cntr;		/* Variable: Data log counter */
		  	  	   int  task_ptr;		/* Variable: Task address pointer */
		  	  	   int  dlog_prescale;  /* Parameter: Data log prescale */
		  	  	   int  dlog_cntr_max;  /* Parameter: Maximum data buffer */
		  	  	   int  dl_buffer1_adr; /* Parameter: Buffer starting address 1 */
		  	  	   int  dl_buffer2_adr; /* Parameter: Buffer starting address 2 */   		  	  	   
		  	  	   int  (*init)();      /* Pointer to init function */
		  	  	   int  (*update)();	/* Pointer to update function */ 
				 } DATALOG;	              

/* dlog_presacle = 1 will give 50uS log rate  */
/*-----------------------------------------------------------------------------
Default initalizer for the DATALOG object.
-----------------------------------------------------------------------------*/                     
#define DATALOG_DEFAULTS {  (int *)0x0300, \
                            (int *)0x0300, \
                          	0x0000, \
                          	0x8000, \
                          	0x8400, \
                          	0x0000, \
                          	0x0000, \
                          	0x0000, \
                          	0x0001, \
                          	   400, \
                          	0x8000, \
                          	0x8400, \
                          	(int (*)(int))data_log_init, \
                          	(int (*)(int))data_log_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in DATA_LOG1.C
------------------------------------------------------------------------------*/
void data_log_init(DATALOG *); 
/*------------------------------------------------------------------------------
Prototypes for the functions in DATA_LOG2.ASM
------------------------------------------------------------------------------*/
void data_log_update(DATALOG *); 

#endif /* __DATA_LOG_H__ */
