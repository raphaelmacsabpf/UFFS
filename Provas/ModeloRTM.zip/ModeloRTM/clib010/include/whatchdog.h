/* =================================================================================
File name:        Whatchdog.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo WhatchDog.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 29-09-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __WHATCHDOG_H__
#define __WHATCHDOG_H__


  typedef struct {int x_in;            /* Entrada: Tens�o da rede */
    	 	 	  int  reset;          /* Sa�da: Sinal de reset para o PID do PLL */
                  int  cont;           /* Par�metro: contador */
				  int  (*update)();	   /* Ponteiro para fun��o de atualiza��o */
				  } WTCHDOG;	    



/*-----------------------------------------------------------------------------
Default initalizer for the WTCHDOG object.
-----------------------------------------------------------------------------*/                     
#define WTCHDOG_DEFAULTS {0x0000, \
                          0x0000, \
                          0x0000, \
                          (int (*)(int))whatchdog_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in WhatchDog.C
------------------------------------------------------------------------------*/
void whatchdog_update(WTCHDOG *); 
 
#endif /* __WHATCHDOG_H__ */
