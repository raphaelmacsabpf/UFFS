/* =================================================================================
File name:        SINCOSPH.H                      
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing constants, data type definitions, and 
function prototypes for the SINCOSPH module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __SINCOSPH_H__
#define __SINCOSPH_H__

  typedef struct { int  phase_cs;		/* Input: Phase shift in degree (Q0) */	
			 	   int  freq_cs;		/* Input: Frequency (Q15) */		
		 	 	   int  gain_cs;		/* Input: Magnitude (Q15) */					  
				   int  sg2_freq_max;	/* Parameter: Maximum step angle (Q0) */
				   int  ALPHA_a1;  	 	/* Variable: Incremental angle (Q0) */	
				   int  sine_a1;		/* Output: Sinusoidal output 1 (Q15) */				 
				   int  sine_a2;		/* Output: Sinusoidal output 2 (Q15) */
		  	  	   int  (*calc)();	  	/* Pointer to calculation function */ 
				 } SINCOSPH;	              
 
/* Note that the default sg2_freq_max = 393 = 0x0189 refers to 
   the base frequency = 120 Hz with the sampling period of 20 kHz*/ 
/*-----------------------------------------------------------------------------
Default initalizer for the SINCOSPH object.
-----------------------------------------------------------------------------*/                     
#define SINCOSPH_DEFAULTS { 0x0090, \
                           	   0x4000, \
                          	   0x7FFF, \
                          	   0x0189, \
                          	   0x0000, \
                          	   0x0000, \
                          	   0x0000, \
                   	        (int (*)(int))sincosph_calc }

/*------------------------------------------------------------------------------
Prototypes for the functions in SINCOSPH.ASM
------------------------------------------------------------------------------*/
void sincosph_calc(SINCOSPH *);

#endif /* __SINCOSPH_H__ */
