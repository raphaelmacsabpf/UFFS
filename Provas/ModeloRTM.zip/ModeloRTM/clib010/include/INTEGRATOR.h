/* =====================================================================================================================
File name:      INTEG.H                     
                    
Originator:		Laborat�rio de Aplica��es Industriais	
				Universidade Federal de Minas Gerais

Description:
Front end header file for Integrator block. The integrator is implemented 
from a pid block where the proportional and derivative gains are taken as 
zero.

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 11-04-2003	Release	Rev 1.0                                                   
----------------------------------------------------------------------------------- */
        
#ifndef __INTEGRATOR_H__
#define __INTEGRATOR_H__  


#include "pid_reg1.h"


/*-------------------------------------------------------------------------------------
 The next defined constant makes the proportional and derivative gain of the 
 PIDREG1 structure equal 0 ,i.e. , it makes possible to convert a pid 
 block into an integrator.

 The original pid structure is shown here for convenience:

typedef struct 	{ int  pid_ref_reg1; 	/* Input: Reference input (Q15) 
				  int  pid_fb_reg1;	 	/* Input: Feedback input (Q15) 
				  int  Kp_reg1;			/* Parameter: Proportional gain (Q15) 
				  int  Ki_high_reg1;	/* Parameter: Integral gain (Q31) 
				  int  Ki_low_reg1; 	/* Parameter: Integral gain (Q31) 		
				  int  Kd_reg1;			/* Parameter: Derivative gain (Q15) 					  
				  int  pid_out_max;		/* Parameter: Maximum PID output (Q15) 
				  int  pid_out_min;		/* Parameter: Minimum PID output (Q15) 				 
				  int  pid_e1_reg1;		/* History: Previous error at time = k-1 (Q15) 
				  int  pid_e2_reg1;		/* History: Previous error at time = k-2 (Q15) 
				  int  pid_out_reg1;	/* Output: PID output (Q15) 
		  	  	  int  (*calc)();	/* Pointer to calculation function  
				} PIDREG1;	                   
----------------------------------------------------------------------------------- */

#define CONVERT_PIDREG1_TO_INTEGRATOR {	0x0000,	\
										0x0000,	\
										0x0001,	\
										0x0001,	\
										0x0000,	\
										0x0000,	\
										0x7FFF,	\
										0x8000,	\
										0x0000,	\
										0x0000,	\
										0x0000,	\
										(int (*)(int))pid_reg1_calc }
				

typedef struct INTEGRATOR 
{
		int	in;	/* integrator input - Q.15	*/
		int out;	/* integrator output - Q.15	*/ 			
		int dt;
		int (*calc)();
} INTEGRATOR;

    
#define INTEGRATOR_DEFAULTS {	0x0000,	\
								0x0000,	\
								786,	\
								(int (*)(int))integrator_calc }

void integrator_calc(INTEGRATOR *);


#endif	/* end __INTEGRATOR_H__ */
