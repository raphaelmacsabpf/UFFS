/* =================================================================================
File name:        SVGEN.H                      
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines the interface for the SVGENMF and SVGENDQ modules.
Contains prototypes for the functions in SVGENDQ.ASM, SVGENMF.ASM.
and has definitions of constants, structs etc.                             
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef     __SVGEN__
#define     __SVGEN__

/*-----------------------------------------------------------------------------
Define the structure of the SVGENMF
(Magnitude and angular velocity based Space Vector Waveform Generator)
-----------------------------------------------------------------------------*/

typedef struct     {   int gain;      /* Waveform amplitude Q15 Input        */
                       int freq;      /* Frequency setting Q15 Input         */ 
                       int freq_max;  /* Frequency setting Q0  Input         */ 
                       int alpha;     /* Internal var - Sector angle history */
                       int sector;    /* Internal var - Sector number history*/
                       int va;        /* Phase A output Q15                  */
                       int vb;        /* Phase B output Q15                  */
                       int vc;        /* Phase C output Q15                  */
                       int (*calc)(); /* Pointer to calculation function     */ 
                   } SVGENMF;
typedef SVGENMF *SVGENMF_handle;  
                       
typedef struct     {   int d;         /* Phase d input Q15                   */
                       int q;         /* Phase q input Q15                   */
                       int va;        /* Phase A output Q15                  */
                       int vb;        /* Phase B output Q15                  */
                       int vc;        /* Phase C output Q15                  */
                       int (*calc)(); /* Pointer to calculation function     */ 
                   } SVGENDQ;        
                   
typedef SVGENDQ *SVGENDQ_handle;
                
/*------------------------------------------------------------------------------
      Object Initializers
------------------------------------------------------------------------------*/                       
#define SVGENDQ_DEFAULTS {0x0, 0x0, 0x0, 0x0, 0x0, (int (*)(int))svgendq_calc }
#define SVGENMF_DEFAULTS {0x7fff, 0x7fff, 2000, 0x0, \
                          0x0 , 0x0,0x0,0x0, (int (*)(int))svgenmf_calc }
                          
/*------------------------------------------------------------------------------
      Funtion prototypes
------------------------------------------------------------------------------*/                       
                          
void svgenmf_calc(SVGENMF *);
void svgendq_calc(SVGENDQ *);

#endif
