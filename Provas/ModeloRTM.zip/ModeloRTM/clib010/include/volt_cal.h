/* =================================================================================
File name:        VOLT_CAL.H                       
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
         Header file containing constants, data type definitions, and 
         function prototypes for the VOLT_CAL module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __VOLT_CAL_H__
#define __VOLT_CAL_H__

typedef struct 	{ int  DC_bus;		/* Input: DC-bus voltage (Q15) */ 
			  	  int  Mfunc_V1;  	/* Input: Modulation voltage phase A (Q15) */ 
		  	  	  int  Mfunc_V2;	/* Input: Modulation voltage phase B (Q15) */ 	
		   	  	  int  Mfunc_V3;	/* Input: Modulation voltage phase C (Q15) */ 
	  	  	  	  int  Vphase_A;	/* Output: Phase voltage phase A (Q15) */ 
		   	  	  int  Vphase_B;	/* Output: Phase voltage phase B (Q15) */ 
		  	  	  int  Vphase_C;	/* Output: Phase voltage phase C (Q15) */ 
		  	  	  int  Vdirect;		/* Output: Stationary d-axis phase voltage (Q15) */ 
		  	  	  int  Vquadra;  	/* Output: Stationary q-axis phase voltage (Q15) */
		  	  	  int  (*calc)();	/* Pointer to calculation function */ 
				} PHASEVOLTAGE;	                   

/*-----------------------------------------------------------------------------
Default initalizer for the PHASE_VOLTAGE object.
-----------------------------------------------------------------------------*/                     
#define PHASEVOLTAGE_DEFAULTS { 0x0000, \
                          		0x0000, \
                          		0x0000, \
                          		0x0000, \
                          		0x0000, \
                          		0x0000, \
                          		0x0000, \
		         				0x0000, \
 		          				0x0000, \
                  				(int (*)(int))phase_voltage_calc }

/*------------------------------------------------------------------------------
Prototypes for the functions in VOLT_CAL.ASM
------------------------------------------------------------------------------*/
void phase_voltage_calc(PHASEVOLTAGE *);

#endif /* __VOLT_CAL_H__ */
