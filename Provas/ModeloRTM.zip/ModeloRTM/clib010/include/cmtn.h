/* =================================================================================
File name:        CMTN.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines handy constants for object initializations
contains prototypes for the functions in COM_TRIG.ASM.
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __CMTN__
#define __CMTN__

/*-----------------------------------------------------------------------------
Define the structure of the CMTN:
Generator of the commutation trigger points for
the 3-ph power inverter switches.
-----------------------------------------------------------------------------*/

typedef  struct {
  int trig;             /* Commutation trig output                 */
  int va;               /* Motor phase voltage to GND  for phase A */
  int vb;               /* Motor phase voltage to GND  for phase B */
  int vc ;              /* Motor phase voltage to GND  for phase C */
  int zc_trig;
  int ptr_ct;           /* Commutation state pointer input         */
  int debug_Bemf;
  int noise_windowCntr;
  int d30_doneFlg;
  int time_stampNew;
  int time_stampOld;
  int v_timer;          /* Virtual timer used for commmutaion delay angle calculation */
  int delay;
  int dt_taskFlg ;
  int noise_windowMax;
  int delay_cntr;
  int cdnw_delta;
  int nw_dynThold;

  int (*calc) (); /* Function pointer */

} CMTN;

 typedef CMTN  *CMTN_handle;
/*------------------------------------------------------------------------------
      Object Initializers
------------------------------------------------------------------------------*/

#define CMTN_DEFAULTS {0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       0x0, \
                       (int(*)(int))cmtn_trig_calc \
                       }

/*------------------------------------------------------------------------------
      Function prototypes
------------------------------------------------------------------------------*/

int cmtn_trig_calc(CMTN_handle);

#endif     /*__CMTN__*/