/* =================================================================================
File name:        TransDly.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo transdly (Atraso de transporte).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __TRANSDLY_H__
#define __TRANSDLY_H__

  typedef struct { int  x_in;           /* Entrada: Sinal de entrada */
			 	   int  i_in;           /* Vari�vel interna: �ndice para o vetor relativo ao sinal de entrada */
		 	 	   int  i_out;          /* Vari�vel interna: �ndice para o vetor relativo ao sinal de sa�da */ 		
				   int  x_out;          /* Sa�da: Sinal de sa�da */
				   int  vet[42];        /* Vari�vel Interna: Vetor de armazenamento */
		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } ATRASO;	              

/*-----------------------------------------------------------------------------
Default initalizer for the ATRASO object.
-----------------------------------------------------------------------------*/                     
#define ATRASO_DEFAULTS {  0x0000, \
                          	0x0000, \
                          	0x0000, \
                          	0x0000, \
                          	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          	(int (*)(int))transdly_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in TransDly.C
------------------------------------------------------------------------------*/
void transdly_update(ATRASO *); 
 
#endif /* __TRANSDLY_H__ */
