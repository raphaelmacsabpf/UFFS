/* =================================================================================
File name:        Media2.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo media2 (M�dia entre um sinal de entrada e seu valor anterior).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 02-06-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __MEDIA2_H__
#define __MEDIA2_H__

  typedef struct { int  x_in;           /* Entrada: Sinal de entrada */
			 	   int  x_anterior;     /* Vari�vel interna: N�mero de pontos a serem utilizados */
				   int  x_out;          /* Sa�da: Sinal de sa�da */
		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } MEDIA2;	              

/*-----------------------------------------------------------------------------
Default initalizer for the MEDIA2 object.
-----------------------------------------------------------------------------*/                     
#define MEDIA2_DEFAULTS { 0x0000, \
                          0x0000, \
                          0x0000, \
                          (int (*)(int))media2_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in Media2.C
------------------------------------------------------------------------------*/
void media2_update(MEDIA2 *); 
 
#endif /* __MEDIA2_H__ */
