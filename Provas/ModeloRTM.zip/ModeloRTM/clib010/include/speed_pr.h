/* =================================================================================
File name:        SPEED_PR.H                      
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
    Header file containing the data types, constants for the period based
    speed measurement function. Also contains the prototypes for the 
    functions implemented in SPEED_PR.ASM
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __SPEED_PR_H__
#define __SPEED_PR_H__

 typedef struct {
       int time_stamp_new;  /* Variable : New 'Timestamp' corresponding to a capture event  */
       int time_stamp_old;  /* Variable : Old 'Timestamp' corresponding to a capture event  */
       int time_stamp; 		/* Input : Current 'Timestamp' corresponding to a capture event  */
       int shift;  		  	/* Parameter : For maximum accuracy of 32bit/16bit division */
       int speed_scaler;  	/* Parameter :  Scaler converting 1/N cycles to a Q15 speed  */
       int speed_prd;     	/* Output :  speed in per-unit                            */
       int rpm_max;       	/* Parameter : Scaler converting Q15 speed to rpm (Q0)speed */
       int speed_rpm;       /* Output : speed in r.p.m.                            */
       int (*calc)();  	  	/* Pointer to the calulation function                   */
       } SPEED_MEAS;   	  	/* Data type created      */

/*-----------------------------------------------------------------------------
Default initalizer for the SPEED_MEAS object.
-----------------------------------------------------------------------------*/                     
#define SPEED_PR_MEAS_DEFAULTS   { 0x0001, \
                                   0x0001, \
                                   0x0000, \
                                   6, \
                                   11621,  \
                                   0x7fff, \
                                   4174,   \
                                   0x0000, \
                                   (int (*)(int))speed_prd }

/*------------------------------------------------------------------------------
Prototypes for the functions in SPEED_PR.ASM
------------------------------------------------------------------------------*/
void speed_prd(SPEED_MEAS *); 

#endif /*  __SPEED_PR_H__ */


