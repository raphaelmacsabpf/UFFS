/* =================================================================================
File name:        RMP_CNTL.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing constants, data type definitions, and 
function prototypes for the RMPCNTL module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __RMP_CNTL_H__
#define __RMP_CNTL_H__

 typedef struct { int  target_value; 	/* Input: Target input (Q15) */
				  int  rmp_dly_max;		/* Parameter: Maximum delay rate */			
		 	 	  int  rmp_lo_limit;	/* Parameter: Minimum limit (Q15) */					  
				  int  rmp_hi_limit;	/* Parameter: Maximum limit (Q15) */
				  int  rmp_delay_cntl;  /* Variable: Incremental delay  */	
				  int  setpt_value;		/* Output: Target output (Q15) */				 
				  int  s_eq_t_flg;		/* Output: Flag output */
		  	  	  int  (*calc)();	  	/* Pointer to calculation function */ 
				 } RMPCNTL;	            

/*-----------------------------------------------------------------------------
Default initalizer for the RMPCNTL object.
-----------------------------------------------------------------------------*/                     
#define RMPCNTL_DEFAULTS { 0x0000, \
                           0x0028, \
                          	0x0300, \
                          	0x7500, \
                          	0x0000, \
                          	0x0000, \
                          	0x0000, \
                   			(int (*)(int))rmp_cntl_calc }

/*------------------------------------------------------------------------------
Prototypes for the functions in RMP_CNTL.ASM
------------------------------------------------------------------------------*/
void rmp_cntl_calc(RMPCNTL *);

#endif /* __RMP_CNTL_H__ */
