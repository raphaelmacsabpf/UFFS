/* =================================================================================
File name:        VHZPROF.H                       
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
         Header file containing constants, data type definitions, and 
         function prototypes for the VHPROFILE module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __VHZPROF_H__
#define __VHZPROF_H__

typedef struct { int freq;        /* Frequency input Q15                     */
                 int fl;          /* Freq below which vout=vmin : Q15 Input  */
                 int fh;          /* Freq above which vout=vmax : Q15 Input  */
                 int slope;      /* Slope of the Vhz profile   : Q15 Input   */
                 int vmax;       /* Voltage output above fmax  : Q15 Input   */
                 int vmin;       /* Voltage output below fmin  : Q15 Input   */
                 int vout;       /* Computed output voltage    : Q15 Output  */
                 int (*calc)();  /* Pointer to the calculation function      */
               } VHZPROFILE;
                   
                     
#define DEFAULT_PROFILE { 0x0000, \
                          0x0000, \
                          0x7fff, \
                          0x0000, \
                          0x0000, \
                          0x0000, \
                          0x0000, \
                          (int (*)(int))Vhz_Profile_Calculate }

/*------------------------------------------------------------------------------
Prototypes for the functions in VHZPROF.ASM
------------------------------------------------------------------------------*/
int Vhz_Profile_Calculate(VHZPROFILE *);

#endif /* __VHZPROF_H__ */
