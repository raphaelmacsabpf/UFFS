/* =================================================================================
File name:        PLLMONO.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo PLLMONO.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __PLLMONO_H__
#define __PLLMONO_H__

#include "..\include\transdly.h"
#include "..\include\pid_reg1.h"
#include "..\include\integ.h"

typedef struct {int a,b,th ;} park_in; 
typedef struct {int d,q ;} park_out; 

int park(void *in, void *out);

#define DEFAULT_PARK_IN		{0,0,0}
#define DEFAULT_PARK_OUT	{0,0}




  typedef struct { int  v_alpha;          /* Entrada: Sinal de entrada (Q15) */
			 	   int  theta;            /* Sa�da: �ngulo de sa�da (Q15) (-PI <-> PI = 0x8000h <-> 0x7FFFh) */
		 	 	   int  wff;              /* Par�metro: Comando de freq��ncia de feedforward (Q15). fn = 754rad/s */
                   int  watchdog;         /* Vari�vel interna: contador para o reset do PI para possibilitar ressincronismo automatico */
                   ATRASO atraso1;        /* Objeto atraso de transporte */
                   park_in girante;       /* Estrutura de entrada para transformada de Park */
                   park_out estacionario; /* Estrutura de sa�da para transformada de Park */
                   PIDREG1 pid;           /* Objeto PID */  
                   INTEGRAL integ;        /* Objeto Integrador (para �ngulo) */
				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } PLL1F;	              

/*-----------------------------------------------------------------------------
Default initalizer for the PLL1F object.
-----------------------------------------------------------------------------*/                     
#define PLL1F_DEFAULTS { 0x0000, \
                         0x0000, \
                         0x4000, \
                         0x00A7, \
                         ATRASO_DEFAULTS, \
                         DEFAULT_PARK_IN, \
                         DEFAULT_PARK_OUT, \
                         PIDREG1_DEFAULTS, \
                         INTEGRAL_DEFAULTS, \
                         (int (*)(int))pllmono_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in PLLMono.C
------------------------------------------------------------------------------*/
void pllmono_update(PLL1F *); 
 
#endif /* __PLLMONO_H__ */
