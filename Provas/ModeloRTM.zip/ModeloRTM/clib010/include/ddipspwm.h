/* =================================================================================
File name:        DDiPSPWM.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo DDiPSIPWM (modulador PWM para DDiPS monof�sico).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __DDIPSPWM_H__
#define __DDIPSPWM_H__ 

  typedef struct { int  v_ref;          /* Entrada: Sinal de entrada (Q15) */
			 	   int  v_dc2;          /* Entrada: Tens�o da metade superior do barramento CC (Q15) */
		 	 	   int  v_dc1;          /* Entrada: Tens�o da metade inferior do barramento CC (Q15) */
		 	 	   int  duty;           /* Sa�da: Ciclo de trabalho do PWM como fra��o do periodo do registrador (Q15) */
				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } DIPSPWM;	    

/*-----------------------------------------------------------------------------
Default initalizer for the DIPSPWM object.
-----------------------------------------------------------------------------*/                     
#define DIPSPWM_DEFAULTS {  0x0000, \
                        	0x3FFF, \
                            0x3FFF, \
                            0x2000, \
                          	(int (*)(int))ddipspwm_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in DDiPSPWM.C
------------------------------------------------------------------------------*/
void ddipspwm_update(DIPSPWM *);    
 
#endif /* __DDIPSPWM_H__ */
