/* =================================================================================
File name:        Integ.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo Integ (integrador).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __INTEG_H__
#define __INTEG_H__

  typedef struct { int  x_in;         /* Entrada: Sinal de entrada (Frequ�ncia) (Q15) fn = 754rad/s */
			 	   int  dt;             /* Par�metro: Tempo de amostragem (Q15) */
		 	 	   int  x_out;          /* Sa�da: Sinal de sa�da (�ngulo) (Q15) (-PI <-> PI = 8000h <-> 7FFFh) */
				   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } INTEGRAL;	    

/*-----------------------------------------------------------------------------
Default initalizer for the INTEGRAL object.
-----------------------------------------------------------------------------*/                     
#define INTEGRAL_DEFAULTS {  0x0000, \
                        	0x0312, \
                          	0x0000, \
                          	(int (*)(int))integ_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in PoleP.C
------------------------------------------------------------------------------*/
void integ_update(INTEGRAL *); 
 
#endif /* __INTEG_H__ */
