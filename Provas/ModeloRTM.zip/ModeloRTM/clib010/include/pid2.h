/* =================================================================================
File name:        PID2.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
This file defines handy constants for object initializations
contains prototypes for the functions in PID_REG2.ASM
and has definitions of structs etc.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __PID2__
#define __PID2__

/*-----------------------------------------------------------------------------
 Define the structure of the PID_REG2
 (pid regulator2)
-----------------------------------------------------------------------------*/

typedef struct {

    int fb_reg2;    /* Feedback signal for PI regulator Q15 Input  */
    int ref_reg2;   /* Reference signal for PI regulator Q15 Input */
    int k0_reg2;    /* PI parameter - proportional gain Q9 */
    int k1_reg2;    /* PI parameter - integral time * sample time Q13 */
    int kc_reg2;    /* PI parameter - sampling time / integral time Q13 */
    int un_reg2;    /* Integral component of PI Q15 */
    int en0_reg2;   /* reference signal - feedback signal Q15 */
    int upi_reg2;   /* actual PI output without taking into account saturation Q15 */
                    /* i.e. if output is not saturated out_reg2 = upi_reg2 */
    int epi_reg2;   /* out_reg2 - upi_reg2 Q15 */
    int max_reg2;   /* PI parameter - upper cut off saturation limit of PI regulator output Q15 */
    int min_reg2;   /* PI parameter - lower cut off saturation limit of PI regulator output Q15 */
    int out_reg2;   /* final PI regulator output Q15 */

    int (*calc)();  /* Pointer to the calculation function */

  } PID2;

typedef PID2 *PID2_handle;

/*----------------------------------------------------------------------------
      Object Initializers
 ----------------------------------------------------------------------------*/

#define PID2_DEFAULTS { 0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        0x0,\
                        (int (*) (int))pid2_calc \
                        }

/*------------------------------------------------------------------------------
      Function prototypes
------------------------------------------------------------------------------*/

void pid2_calc(PID2_handle);

#endif     /* __PID2__ */
