/* ==============================================================================
System Name:  	DVR_LAI

File Name:		CLARKE.H

Description:  	Header file for a Clarke Transformation Block.

Originator:		Laborat�rio de Aplica��es Industriais
				Universidade Federal de Minas Gerais

Target dependency:	x2407/x2812
To Select the target device see target.h file.
		
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 14-04-2003	Release	Rev 1.0
=================================================================================*/ 

#ifndef __CLARKE_H__
#define __CLARKE_H__


typedef struct CLARKE { 	
		int a;			/* "phase a" sinusoidal input - Q15 		*/
		int b;			/* "phase b" sinusoidal input - Q15 		*/
		int c;			/* "phase c" sinusoidal input - Q15 		*/
		int d_stat;		/* stationary d-axis component - Q15 output	*/
		int q_stat;		/* stationary q-axis component - Q15 output	*/
		int (*calc)();	/* Pointer to calculation function 			*/
} CLARKE;

#define CLARKE_DEFAULTS { 	0x0000,	\
							0x0000,	\
							0x0000,	\
							0x0000,	\
							0x0000,	\
							(int (*)(int))clarke_calc }

void clarke_calc(CLARKE *);


#endif	/* end __CLARKE_H__ */