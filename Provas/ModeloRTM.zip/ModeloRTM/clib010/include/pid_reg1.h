/* =================================================================================
File name:        PID_REG1.H                     
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Header file containing constants, data type definitions, and 
function prototypes for the PID_REG1 module.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __PID_REG1_H__
#define __PID_REG1_H__

typedef struct 	{ int  pid_ref_reg1; 	/* Input: Reference input (Q15) */
				  int  pid_fb_reg1;	 	/* Input: Feedback input (Q15) */
				  int  Kp_reg1;			/* Parameter: Proportional gain (Q15) */			
				  int  Ki_high_reg1;	/* Parameter: Integral gain (Q31) */
				  int  Ki_low_reg1; 	/* Parameter: Integral gain (Q31) */		
				  int  Kd_reg1;			/* Parameter: Derivative gain (Q15) */					  
				  int  pid_out_max;		/* Parameter: Maximum PID output (Q15) */
				  int  pid_out_min;		/* Parameter: Minimum PID output (Q15) */				 
				  int  pid_e1_reg1;		/* History: Previous error at time = k-1 (Q15) */
				  int  pid_e2_reg1;		/* History: Previous error at time = k-2 (Q15) */
				  int  pid_out_reg1;	/* Output: PID output (Q15) */
		  	  	  int  (*calc)();	/* Pointer to calculation function */ 
				} PIDREG1;	                   

/*-----------------------------------------------------------------------------
Default initalizer for the PIDREG1 object.
-----------------------------------------------------------------------------*/                     
#define PIDREG1_DEFAULTS { 0x0000, \
                          	0x0000, \
                          	0x2200, \
                          	0x0030, \
                          	0xDEAD, \
                          	0x0000, \
                          	0x7FFF, \
		          		  	0x8000, \
 		          		  	0x0000, \
                  		  	0x0000, \
 		          		  	0x0000, \
                  			(int (*)(int))pid_reg1_calc }

/*------------------------------------------------------------------------------
Prototypes for the functions in PID_REG1.ASM
------------------------------------------------------------------------------*/
void pid_reg1_calc(PIDREG1 *);

#endif /* __PID_REG1_H__ */
