/* =================================================================================
File name:        SagGen1F.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo SagGen1F.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 21-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __SAGGEN1F_H__
#define __SAGGEN1F_H__

  typedef struct { int  amplitude;      /* Par�metro: Amplitude da tens�o de sa�da (Q15) */	
			 	   int  freq;           /* Par�metro: Freq��ncia fundamental de sa�da fn = fpwm (Q15) */		
		 	 	   int  duracao;        /* Par�metro: Dura��o do dist�rbio. Nominal = 3.27s (Q15) */		
				   int  vsag;           /* Par�metro: Tens�o residual durante o sag (Q15) */
				   int  delta_teta;     /* Par�metro: Salto de fase durante o sag */		
				   int  teta;           /* Vari�vel Interna: �ngulo da tens�o da sa�da (Q15) (0 - 2PI = 0 - 2^15) */	
				   int  tempo;          /* Vari�vel Interna: Tempo transcorrido do in�cio do Sag (Q15) */
				   int  v_out;          /* Sa�da: tens�o com sag  */
		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */ 
				 } SAG1F;	              

/*-----------------------------------------------------------------------------
Default initalizer for the SAG1F object.
-----------------------------------------------------------------------------*/                     
#define SAG1F_DEFAULTS {  0x4000, \
                          	0x00C5, \
                          	0x0000, \
                          	0x3FFF, \
                          	0x0AAB, \
                          	0x0000, \
                          	0x0000, \
                          	0x0000, \
                          	(int (*)(int))saggen1f_update }

#define SAG1F_DEFAULTS_A {  0x4000, \
                          	0x00C5, \
                          	0x7FFE, \
                          	0x3FFF, \
                          	0x0AAB, \
                          	0x0000, \
                          	0x7FFF, \
                          	0x0000, \
                          	(int (*)(int))saggen1f_update }

#define SAG1F_DEFAULTS_B {  0x4000, \
                          	0x00C5, \
                          	0x7FFE, \
                          	0x3FFF, \
                          	0x0AAB, \
                          	0x2AAB, \
                          	0x7FFF, \
                          	0x0000, \
                          	(int (*)(int))saggen1f_update }

#define SAG1F_DEFAULTS_C {  0x4000, \
                          	0x00C5, \
                          	0x7FFE, \
                          	0x3FFF, \
                          	0x0AAB, \
                          	0x5555, \
                          	0x7FFF, \
                          	0x0000, \
                          	(int (*)(int))saggen1f_update }


/*------------------------------------------------------------------------------
Prototypes for the functions in SagGen1F.C
------------------------------------------------------------------------------*/
void saggen1f_update(SAG1F *); 
 
extern int qsine();
 
#endif /* __SAGGEN1F_H__ */