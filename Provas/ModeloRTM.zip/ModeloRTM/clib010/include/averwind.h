/* =================================================================================
File name:        AverWind.H                     
                    
Autor: Sidelmo M. Silva

Description: 

Arquivo de cabe�alho contendo defini��es de constantes, tipos de dados e prot�tipo de 
fun��es para o m�dulo averwind (M�dia M�vel).
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 02-06-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef __AVERWIND_H__
#define __AVERWIND_H__

  typedef struct { int  x_in;           /* Entrada: Sinal de entrada */
			 	   int  n;              /* Vari�vel interna: N�mero de pontos a serem utilizados */
			 	   int  i_x;            /* Vari�vel interna: �ndice para o ponto atual */
				   int  x_out;          /* Sa�da: Sinal de sa�da */
				   int  vet[16];         /* Vari�vel Interna: Vetor de armazenamento */
		  	  	   int  (*update)();	/* Ponteiro para fun��o de atualiza��o */
				 } MEDIA;	              

/*-----------------------------------------------------------------------------
Default initalizer for the ATRASO object.
-----------------------------------------------------------------------------*/                     
#define MEDIA_DEFAULTS {  0x0000, \
                          0x0002, \
                          0x0000, \
                          0x0000, \
                          0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, \
                          0x0000, 0x0000, \
                          (int (*)(int))averwind_update }

/*------------------------------------------------------------------------------
Prototypes for the functions in AverWind.C
------------------------------------------------------------------------------*/
void averwind_update(MEDIA *); 
 
#endif /* __AVERWIND_H__ */
