/* ==============================================================================
System Name:  DVR_LAI

File Name:	LPF_1ORDER.H

Description:  	Header file for target independent/application configurable
				implementation of a lowpass first-order filter.

Originator:		Laborat�rio de Aplica��es Industriais - UFMG

Target dependency:	x2407/x2812
To Select the target device see target.h file.
		
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 01-05-2003	Release	Rev 1.0
=================================================================================*/ 

#ifndef __LPF_1ORDER_H__
#define __LPF_1ORDER_H__


typedef struct LPF_1ORDER {
		long int accumulator;
		long int outLong;
		int aux;
		int in;	/* Filter input - Q15 */
		int out;/* Filter output - Q15 */
		int tal;	/* Filter time constant - Q15 */
		int T;		/* Sampling period	- Q15 */ 
		int PeriodOverTimeCteHigh;	/* T/tal - Q15 */
		int PeriodOverTimeCteLow;
		int (*init)();	/* Pointer to initialization function */
		int (*calc)();	/* Pointer to calculation function */ 
} LPF_1ORDER;

#define LPF_1ORDER_DEFAULTS {0x00000000,	\
							0x00000000, \
							0x0000,	\
							0x0000,	\
							0x0000,	\
							10000,	\
							2, \
							0x0003, \
							0x46DC, \
							(int (*)(int))lpf_1order_init, \
							(int (*)(int))lpf_1order_calc }
							
/*#define LPF_1ORDER_DEFAULTS { 	0x00000000, \                                
                                0x00000000, \
                                0x0000, \
								0x0000,	\
								0x0000, \
								10000,  \
								2, \
								0x0003, \
								0x46DC, \
								(int (*)(int))lpf_1order_init, \
								(int (*)(int))lpf_1order_calc }*/
		
typedef LPF_1ORDER * LPF_1ORDER_HANDLE;

void lpf_1order_init(LPF_1ORDER *);

void lpf_1order_calc(LPF_1ORDER *);

#endif  /* __LPF_1ORDER_H__  */  