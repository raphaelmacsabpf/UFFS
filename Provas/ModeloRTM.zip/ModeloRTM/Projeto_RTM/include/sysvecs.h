/************************* RESET AND INTERRUPT VECTORS **************************/
/* NOTE:Though this file will support multiple inclusion in the same
        source file, it must NOT be included in multiple separately linked source
        files. This will cause the linker to generate an error.
        This file is intended for only the framework file to include.
*/


/*------------------------------------------------------------------------------*/
#ifndef __SYSVECS_H__
#define __SYSVECS_H__




asm(" 		 .include \"..\\rtmon\\c200mnrt.i\"				");
asm(" 		 .include \"..\\include\\x24x.h\"					");
asm("       	 .sect   \"vectors\"                              		");
asm("       	 .ref    _c_int0                                  		");
asm("       	 B       _c_int0         ;00h reset               		");
asm("       	 B       _phantom        ;02h INT1                		");
asm("       	 B       _c_int02        ;04h INT2                		");
asm("       	 B       _phantom        ;06h INT3                		");
asm("       	 B       _phantom        ;08h INT4                		");
asm("       	 B       _phantom        ;0Ah INT5                		");
asm("       	 B       _phantom        ;0Ch INT6                		");
asm("      .if ( 1 ) ; macro occupies fourteen words in the vector table.	");
asm("											");
asm("MON_EINTR   mon_eintr_vecs       ; 0E					");
asm("                                 ; 10					");
asm("                                 ; 12					");
asm("                                 ; 14					");
asm("                                 ; 16					");
asm("                                 ; 18					");
asm("                                 ; 1A					");
asm("            .else ; macro not in vector table.				");
asm("MON_EINTR_B B     MON_EINTR      ; 0E					");
asm("HUNG10      B     HUNG10         ; 10					");
asm("HUNG12      B     HUNG12         ; 12					");
asm("HUNG14      B     HUNG14         ; 14					");
asm("HUNG16      B     HUNG16         ; 16					");
asm("HUNG18      B     HUNG18         ; 18					");
asm("HUNG1A      B     HUNG1A         ; 1A					");
asm("            .endif								");
asm("HUNG1C      B     HUNG1C         ; 1C					");
asm("HUNG1E      B     HUNG1E         ; 1E					");
asm("HUNG20      B     HUNG20         ; 20					");
asm("TRAP        B     TRAP           ; 22					");
asm("NMI         B     _phantom        ; 24					");
asm("            .if ( 1 ) ; macro occupies eight words in the vector table.	");
asm("MON_ETRAP   mon_etrap_vecs       ; 26					");
asm("                                 ; 28					");
asm("                                 ; 2A					");
asm("                                 ; 2C					");
asm("            .else ; macro not in vector table.				");
asm("MON_ETRAP_B B     MON_ETRAP      ; 26					");
asm("HUNG28      B     _phantom         ; 28					");
asm("HUNG2A      B     _phantom         ; 2A					");
asm("HUNG2C      B     _phantom         ; 2C					");
asm("            .endif								");
asm("HUNG2E      B     _phantom         ; 2E					");
asm("HUNG30      B     _phantom         ; 30					");
asm("HUNG32      B     _phantom         ; 32					");
asm("HUNG34      B     _phantom         ; 34					");
asm("HUNG36      B     _phantom         ; 36					");
asm("HUNG38      B     _phantom         ; 38					");
asm("HUNG3A      B     _phantom         ; 3A					");
asm("HUNG3C      B     _phantom         ; 3C					");
asm("HUNG3E      B     _phantom         ; 3E					");


#endif  /* __SYSVECS_H__ */

