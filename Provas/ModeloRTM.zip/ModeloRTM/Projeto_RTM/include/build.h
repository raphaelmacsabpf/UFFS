/* =================================================================================
File name:        BUILD.H                     
                    
Autor:	Rodrigo P. C. Benedito ; rpcampana@yahoo.com.br

Descri��o:
 
Arquivo de controle incremental de Build.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 23-04-2003	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/


#ifndef BUILDLEVEL 


/*------------------------------------------------------------------------------
Following is the list of the Build Level choices.
Remember buildlevels are continously updated.
------------------------------------------------------------------------------*/
#define LEVEL1  1   /* SCI Communication Block Test, PWM interrupt test 	*/
#define LEVEL2  2   /* DetSag1F Block Test, ADC Block test					*/
#define LEVEL3  3   
#define LEVEL4  4   
#define LEVEL5  5   
#define ALWAYS_RUN


/*------------------------------------------------------------------------------
This line sets the BUILDLEVEL to one of the available choices.
------------------------------------------------------------------------------*/
#define   BUILDLEVEL LEVEL1


#ifndef BUILDLEVEL    
#error  Critical: BUILDLEVEL must be defined !!
#endif  /* BUILDLEVEL */



#endif  /*BUILDLEVEL */

