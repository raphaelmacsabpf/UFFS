/* ==============================================================================
System Name:  Projeto Gera�ao Distribuida 

File Name:  CemigFC.h

Description:	Arquivo cabe�alho prim�rio do Gera��o Distribuida.

Authors:		Renato Lyra
				Rodrigo Pereira Campana Benedito
             
Target dependency:	x2407  
      
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 24-04-2003	Release	Rev 1.0
=================================================================================  */

/*-----------------------------------------------------------------------------*/
/* Get target information.                                                     */
/*-----------------------------------------------------------------------------*/
#include <TARGET.H>

#if (TARGET==F243)
#include <regs24x.h> 
#endif


#if (TARGET==F2407)                      
#include <regs240x.h> 
#endif

/*-------------------------------------------------------------------------------
    Get buildlevel information.
-------------------------------------------------------------------------------*/
#include <build.h>

/*------------------------------------------------------------------------------
    Include file containing the system vectors.
    These must be set up correctly for the interrupt mechanisms to work
------------------------------------------------------------------------------*/
#include <sysvecs.h>

/*-------------------------------------------------------------------------------
Next, Include project specific include files.
-------------------------------------------------------------------------------*/
#include <DATA_LOG.H>           /* Get Constants etc for Data_Log               */
#include <WATCHDOG.H>           /* Get the watchdog driver interface            */
#include <PWMGEN.H>             /* Get Constants etc for the PWM Generators     */
#include <ADC_16CH.H>			/* Get the ADC converter 					    */

/*-------------------------------------------------------------------------------
    Function Prototypes for the functions implemented in DVR500FRM.C
-------------------------------------------------------------------------------*/
void RstSystem(void);
void rtmon_init(void);
void interrupt c_int02();
void interrupt phantom(void);


/*-------------------------------------------------------------------------------
    Constants Definitions
-------------------------------------------------------------------------------*/
 
#ifndef TRUE
#define FALSE ((Bool)0)
#define TRUE  ((Bool)1)
#endif

#ifndef TRUE
#define FALSE 0
#define TRUE  1
#endif

