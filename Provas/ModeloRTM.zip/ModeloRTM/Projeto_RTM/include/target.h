/* =================================================================================
File name:        TARGET.H                    
                    
Originator:	Digital Control Systems Group
			Texas Instruments

Description: 
Target device selection file.
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 9-15-2000	Release	Rev 1.0                                                   
------------------------------------------------------------------------------*/

#ifndef TARGET 


/*------------------------------------------------------------------------------
Following is the selection list of the target choices.
Note that the F241 is represented by the F243 and the 
LF2407 represents the LF2406 and the LF2402.
------------------------------------------------------------------------------*/
#define F240   1
#define F243   2
#define F2407  4
#define UNKNOWN 8

/*------------------------------------------------------------------------------
This line sets the target to one of the available choices.
------------------------------------------------------------------------------*/
#define TARGET  F2407



#ifndef TARGET    
#error  Critical: A target must be defined !!
#endif  


/*
#warn NOTE: This system assumes a CLKIN of 7.5 MHz for the 
#warn TMS320F240x and a CLKIN of 5MHz for the TMS320F24x

#error Remove this line upon verifying your board CLKIN
*/

/* This system was written assuming a CLKIN of 7.5 MHz for the LF240x parts. If your 
    system uses a different CLKIN requiring a change in the PLL multiplication factor,
    then it must be changed in the system file.
    
    The PLL multiplication factor is set in the SCSR1 register and this is written in the
    function
                    void RstSystem(void)
                    {
                     
                     
                     #if (TARGET==F2407)
                      
                       SCSR1=0xc;    
                             
                     #endif
                    
 
                    }
 
    If for your EVM board the CLKIN is 15MHz then update the line to read
         
                     #if (TARGET==F2407)
                      
                       SCSR1=0x20c;    
                             
                     #endif
 
*/
 

#endif  /*TARGET */

