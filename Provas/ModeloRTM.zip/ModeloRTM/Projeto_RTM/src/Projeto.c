/* ==============================================================================
System Name:  Projeto Modelo RTM 

File Name:  Projeto.c

Description:

Authors:		
             
Target dependency:	x2407  
      
=====================================================================================
 History:
-------------------------------------------------------------------------------------
 24-04-2003	Release	Rev 1.0
=================================================================================  */
/*-----------------------------------------------------------------------------
    Get the compilation target setting.
    This target is defined by TARGET.H. To change the target, or to find out
    the present target, see that file.
-----------------------------------------------------------------------------*/ 
#include <TARGET.H>

/*-----------------------------------------------------------------------------
    Include header information for this file.
----------------------------------------------------------------------------*/
#include <Projeto.h>


/*-----------------------------------------------------------------------------
    System settings
-----------------------------------------------------------------------------*/
#define WAIT_STATES     0x40  

#define REALTIME	0    /* Nao esta desabilitando o RTM quando colocado em 0 */ 

/*-----------------------------------------------------------------------------
    Global Declarations 

    Instance the PWM Generator (Driver) Interface.
    Also initalize the PWMGEN object.
    This pre-initializer takes on the nature depending on the TARGET device.
    

    An IMPORTANT NOTE : 
        This pre-initalization initializes the PWMGEN data structure in
        memory. This WILL NOT initialize the PWM Generator timers and
        so on. This is accomplished by calling the init method in the 
        PWMGEN object. This applies to most drivers that supply an init 
        method.

-----------------------------------------------------------------------------*/
        PWMGEN pwm = PWMGEN_DEFAULTS;


/*-----------------------------------------------------------------------------
    Instance the WATCHDOG Interface.
-----------------------------------------------------------------------------*/
        WATCHDOG wdog = WATCHDOG_DEFAULTS;

/*-----------------------------------------------------------------------------
    Instance the DATA_LOG Interface.
-----------------------------------------------------------------------------*/
     	DATALOG dlog1 = DATALOG_DEFAULTS;                   
     	     	                                      
/*-----------------------------------------------------------------------------
    Instance a ADC16CH object.
-----------------------------------------------------------------------------*/
        ADC16CH adc = ADC_16CH_DEFAULTS;

/*-----------------------------------------------------------------------------
    Global Variables.
-----------------------------------------------------------------------------*/

		/* Constants */

                           
		/* Auxiliary Variables */
        
void main()   
{

/*-----------------------------------------------------------------------------
    Return system to a sane condition
-----------------------------------------------------------------------------*/
        RstSystem();
		                      
                      
#if (BUILDLEVEL == LEVEL1)
/* Enable the DSP peripherals: CAN, SCI, ADC, SPI */
        SCSR1 = 0x00FD | SCSR1;    
                       
		SCSR2 = (SCSR2 | 0x000B) & 0x000F;

/*-----------------------------------------------------------------------------
    Set the pwm period to 500 cycles,(F243) [ or 750 cycles, LF240x ].
    This assumes a CPU CLKIN of 5MHz for the F243 and CLKIN of 7.5 MHz
    for the LF240x.
    Defaults for pwm are set in F243_PWM.H
    Note that this will ONLY change runtime configurable parameters.
    For changing settings like timer modes or PWM Polarity, once the 
    constants like PWM_INIT_STATE, or ACTR_INIT_STATE are changed, the
    driver file must be re-compiled.

    To do this change, the constant and then run the batch file 
    ..\..\drv010\build\f243drv.bat or f2407drv.bat

    This will re-build the driver, with the new timer mode or PWM polarity,
    and then run the (re)build for this project. This will update the 
    setting.
-----------------------------------------------------------------------------*/

        pwm.period_max = 1500;    /* This is based on 10kHz PWM frequency */     
		    	
/*-----------------------------------------------------------------------------
    Initialize the real time monitor
-----------------------------------------------------------------------------*/
       	rtmon_init();            /* Call the monitor init function           */
        enable_ints();           /* Set off the system running.              */

/*-----------------------------------------------------------------------------
    Initialize the data_log function for dlog1
-----------------------------------------------------------------------------*/
        dlog1.dlog_prescale = 2;
        dlog1.init(&dlog1); 

        pwm.init(&pwm);

        EVAIFRA=0x0ffff;          /* Clear all EV1 Group A EV interrupt flags*/
		                                                                                     
#endif /* (BUILDLEVEL==LEVEL1) */  

/*---------------------------------------------------------------------------*/
	while (1)
	{

	}		

/*---------------------------------------------------------------------------*/

} /* End: main() */

 
void interrupt c_int02()
{       


/*-----------------------------------------------------------------------------*/
     asm("      CLRC     XF ");    
/*-----------------------------------------------------------------------------*/


#if (BUILDLEVEL==LEVEL1)
/*---------------------------------------------------------------------------*/
        EVAIFRA=0x0ffff;          /* Clear all EV1 Group A EV interrupt flags*/
		
		
/*------------------------------------------------------------------------------
    Call update function for adc
------------------------------------------------------------------------------*/
		
		adc.update(&adc);


/*------------------------------------------------------------------------------
    Call update function for dlog
------------------------------------------------------------------------------*/
		dlog1.update(&dlog1);
		
		
		
/*----------------------------------------------------------------------------*/
#endif /* BUILDLEVEL==LEVEL1*/


/*-----------------------------------------------------------------------------*/

 	asm("    SETC     XF ");   

/*-----------------------------------------------------------------------------*/

}    /* c_int02() */            


void RstSystem(void)
{ 
/*-----------------------------------------------------------------------------
    First execute the initialization for the Wait Stage Genrator, 
    Global interrupt disable, Shut off the Watchdog, 
    and set up the Interupt Mask Register
-----------------------------------------------------------------------------*/
        WSGR = WAIT_STATES;       /* Initialize Wait State Generator         */
        disable_ints();           /* Make sure the interrupts are disabled   */
        wdog.disable();           /* Vccp/Wddis pin/bit must be high         */
        IMR = 0x0003;
/*        IMR = 0x02;               /* Set up interrupt mask to enable INT2    
                                     until an explicit enable.               */


/*-----------------------------------------------------------------------------
    Next we do the code for setting up the SCSR register, which is dependent 
    on the exact device the code is being compiled for (F243 / F2407).
-----------------------------------------------------------------------------*/

#if (TARGET == F2407)
        SCSR1 = 0xC;                /* Init SCSR */
/*        SCSR1 = 0x60C;                /* Init SCSR */
        
        EVAIMRA = 0x0200;           /* Enable the timer underflow interrupt    */
#endif

}   /* RstSystem(void) */
                          

void interrupt phantom(void)
{   
                          \
	static int phantom_count;
	phantom_count ++;
	
/*  Empty function: Used to handle any unwanted interrupts or events.
    All unused interrupt vectors are pointed to this function so that
    if any un-handled interrupts do get enabled, they are handled in a 
    benign manner, preventing un-intended branches, calls or execution
    into garbage.  
    Note that this function is an ISR, not a ordinary function.
*/
} /* phantom() */

/*------------------------------------------------------------------------------
    This function just provides a c-interface to the asm RTMON init function.
------------------------------------------------------------------------------*/
 
void rtmon_init(void)
{
    asm("       CALL    MON_RT_CNFG ");
}  /* rtmon_init() */

    
